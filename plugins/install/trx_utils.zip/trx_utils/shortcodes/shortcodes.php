<?php
/**
 * Cars4Rent Framework: shortcodes manipulations
 *
 * @package	cars4rent
 * @since	cars4rent 1.0
 */

// Disable direct call
if ( ! defined( 'ABSPATH' ) ) { exit; }

// Theme init
if (!function_exists('cars4rent_sc_theme_setup')) {
	add_action( 'cars4rent_action_init_theme', 'cars4rent_sc_theme_setup', 1 );
	function cars4rent_sc_theme_setup() {
		// Add sc stylesheets
		add_action('cars4rent_action_add_styles', 'cars4rent_sc_add_styles', 1);
	}
}

if (!function_exists('cars4rent_sc_theme_setup2')) {
	add_action( 'cars4rent_action_before_init_theme', 'cars4rent_sc_theme_setup2' );
	function cars4rent_sc_theme_setup2() {

		if ( !is_admin() || isset($_POST['action']) ) {
			// Enable/disable shortcodes in excerpt
			add_filter('the_excerpt', 					'cars4rent_sc_excerpt_shortcodes');
	
			// Prepare shortcodes in the content
			if (function_exists('cars4rent_sc_prepare_content')) cars4rent_sc_prepare_content();
		}

		// Add init script into shortcodes output in VC frontend editor
		add_filter('cars4rent_shortcode_output', 'cars4rent_sc_add_scripts', 10, 4);

		// AJAX: Send contact form data
		add_action('wp_ajax_send_form',			'cars4rent_sc_form_send');
		add_action('wp_ajax_nopriv_send_form',	'cars4rent_sc_form_send');

		// Show shortcodes list in admin editor
		add_action('media_buttons',				'cars4rent_sc_selector_add_in_toolbar', 11);

        // Register shortcodes [trx_cars] and [trx_cars_item]
        add_action('cars4rent_action_shortcodes_list',		'cars4rent_cars_reg_shortcodes');
        if (function_exists('cars4rent_exists_visual_composer') && cars4rent_exists_visual_composer())
            add_action('cars4rent_action_shortcodes_list_vc','cars4rent_cars_reg_shortcodes_vc');

        // Registar shortcodes [trx_clients] and [trx_clients_item] in the shortcodes list
        add_action('cars4rent_action_shortcodes_list',		'cars4rent_clients_reg_shortcodes');
        if (function_exists('cars4rent_exists_visual_composer') && cars4rent_exists_visual_composer())
            add_action('cars4rent_action_shortcodes_list_vc','cars4rent_clients_reg_shortcodes_vc');

        // Register shortcodes [trx_services] and [trx_services_item]
        add_action('cars4rent_action_shortcodes_list',		'cars4rent_services_reg_shortcodes');
        if (function_exists('cars4rent_exists_visual_composer') && cars4rent_exists_visual_composer())
            add_action('cars4rent_action_shortcodes_list_vc','cars4rent_services_reg_shortcodes_vc');

        // Register shortcodes [trx_testimonials] and [trx_testimonials_item]
        add_action('cars4rent_action_shortcodes_list',		'cars4rent_testimonials_reg_shortcodes');
        if (function_exists('cars4rent_exists_visual_composer') && cars4rent_exists_visual_composer())
            add_action('cars4rent_action_shortcodes_list_vc','cars4rent_testimonials_reg_shortcodes_vc');

        if (cars4rent_exists_booked()) {
            add_action('cars4rent_action_shortcodes_list',				'cars4rent_booked_reg_shortcodes');
            if (function_exists('cars4rent_exists_visual_composer') && cars4rent_exists_visual_composer())
                add_action('cars4rent_action_shortcodes_list_vc',		'cars4rent_booked_reg_shortcodes_vc');
        }

        if (cars4rent_exists_html5_jquery_audio_player()) {
            add_action('cars4rent_action_shortcodes_list',				'cars4rent_html5_jquery_audio_player_reg_shortcodes');
            if (function_exists('cars4rent_exists_visual_composer') && cars4rent_exists_visual_composer())
                add_action('cars4rent_action_shortcodes_list_vc',		'cars4rent_html5_jquery_audio_player_reg_shortcodes_vc');
        }

        if (cars4rent_exists_revslider()) {
            add_filter( 'cars4rent_filter_shortcodes_params',			'cars4rent_revslider_shortcodes_params' );
        }

        if (cars4rent_exists_woocommerce()) {
            add_action('cars4rent_action_shortcodes_list', 			'cars4rent_woocommerce_reg_shortcodes', 20);
            if (function_exists('cars4rent_exists_visual_composer') && cars4rent_exists_visual_composer())
                add_action('cars4rent_action_shortcodes_list_vc',	'cars4rent_woocommerce_reg_shortcodes_vc', 20);
        }
	}
}


// Register shortcodes styles
if ( !function_exists( 'cars4rent_sc_add_styles' ) ) {
	function cars4rent_sc_add_styles() {
		// Shortcodes
		wp_enqueue_style( 'cars4rent-shortcodes-style',	trx_utils_get_file_url('shortcodes/theme.shortcodes.css'), array(), null );
	}
}


// Register shortcodes init scripts
if ( !function_exists( 'cars4rent_sc_add_scripts' ) ) {
	function cars4rent_sc_add_scripts($output, $tag='', $atts=array(), $content='') {

		if (cars4rent_storage_empty('shortcodes_scripts_added')) {
			cars4rent_storage_set('shortcodes_scripts_added', true);
			wp_enqueue_script( 'cars4rent-shortcodes-script', trx_utils_get_file_url('shortcodes/theme.shortcodes.js'), array('jquery'), null, true );
		}
		
		return $output;
	}
}


/* Prepare text for shortcodes
-------------------------------------------------------------------------------- */

// Prepare shortcodes in content
if (!function_exists('cars4rent_sc_prepare_content')) {
	function cars4rent_sc_prepare_content() {
		if (function_exists('cars4rent_sc_clear_around')) {
			$filters = array(
				array('trx_utils', 'sc', 'clear', 'around'),
				array('widget', 'text'),
				array('the', 'excerpt'),
				array('the', 'content')
			);
			if (function_exists('cars4rent_exists_woocommerce') && cars4rent_exists_woocommerce()) {
				$filters[] = array('woocommerce', 'template', 'single', 'excerpt');
				$filters[] = array('woocommerce', 'short', 'description');
			}
			if (is_array($filters) && count($filters) > 0) {
				foreach ($filters as $flt)
					add_filter(join('_', $flt), 'cars4rent_sc_clear_around', 1);	// Priority 1 to clear spaces before do_shortcodes()
			}
		}
	}
}

// Enable/Disable shortcodes in the excerpt
if (!function_exists('cars4rent_sc_excerpt_shortcodes')) {
	function cars4rent_sc_excerpt_shortcodes($content) {
		if (!empty($content)) {
			$content = do_shortcode($content);
		}
		return $content;
	}
}



/*
// Remove spaces and line breaks between close and open shortcode brackets ][:
[trx_columns]
	[trx_column_item]Column text ...[/trx_column_item]
	[trx_column_item]Column text ...[/trx_column_item]
	[trx_column_item]Column text ...[/trx_column_item]
[/trx_columns]

convert to

[trx_columns][trx_column_item]Column text ...[/trx_column_item][trx_column_item]Column text ...[/trx_column_item][trx_column_item]Column text ...[/trx_column_item][/trx_columns]
*/
if (!function_exists('cars4rent_sc_clear_around')) {
	function cars4rent_sc_clear_around($content) {
		if (!empty($content)) $content = preg_replace("/\](\s|\n|\r)*\[/", "][", $content);
		return $content;
	}
}






/* Shortcodes support utils
---------------------------------------------------------------------- */

// Cars4Rent shortcodes load scripts
if (!function_exists('cars4rent_sc_load_scripts')) {
	function cars4rent_sc_load_scripts() {
		static $loaded = false;
		if (!$loaded) {
			wp_enqueue_script( 'cars4rent-shortcodes-admin-script', trx_utils_get_file_url('shortcodes_admin.js'), array('jquery'), null, true );
			wp_enqueue_script( 'cars4rent-selection-script',  cars4rent_get_file_url('js/jquery.selection.js'), array('jquery'), null, true );
			wp_localize_script( 'cars4rent-shortcodes-admin-script', 'CARS4RENT_SHORTCODES_DATA', cars4rent_storage_get('shortcodes') );
			$loaded = true;
		}
	}
}

// Cars4Rent shortcodes prepare scripts
if (!function_exists('cars4rent_sc_prepare_scripts')) {
	function cars4rent_sc_prepare_scripts() {
		static $prepared = false;
		if (!$prepared) {
			cars4rent_storage_set_array('js_vars', 'shortcodes_cp', is_admin() ? (!cars4rent_storage_empty('to_colorpicker') ? cars4rent_storage_get('to_colorpicker') : 'wp') : 'custom');	// wp | tiny | custom
			$prepared = true;
		}
	}
}

// Show shortcodes list in admin editor
if (!function_exists('cars4rent_sc_selector_add_in_toolbar')) {
	function cars4rent_sc_selector_add_in_toolbar(){

		if ( !cars4rent_options_is_used() ) return;

		cars4rent_sc_load_scripts();
		cars4rent_sc_prepare_scripts();

		$shortcodes = cars4rent_storage_get('shortcodes');
		$shortcodes_list = '<select class="sc_selector"><option value="">&nbsp;'.esc_html__('- Select Shortcode -', 'trx_utils').'&nbsp;</option>';

		if (is_array($shortcodes) && count($shortcodes) > 0) {
			foreach ($shortcodes as $idx => $sc) {
				$shortcodes_list .= '<option value="'.esc_attr($idx).'" title="'.esc_attr($sc['desc']).'">'.esc_html($sc['title']).'</option>';
			}
		}

		$shortcodes_list .= '</select>';

		cars4rent_show_layout($shortcodes_list);
	}
}


// ---------------------------------- [trx_cars] ---------------------------------------

if ( !function_exists( 'cars4rent_sc_cars' ) ) {
    function cars4rent_sc_cars($atts, $content=null){
        if (cars4rent_in_shortcode_blogger()) return '';
        extract(cars4rent_html_decode(shortcode_atts(array(
            // Individual params
            "style" => "cars-1",
            "slider" => "no",
            "controls" => "no",
            "slides_space" => 0,
            "interval" => "",
            "autoheight" => "no",
            "align" => "",
            "custom" => "no",
            "ids" => "",
            "cat" => "",
            "count" => 3,
            "columns" => 3,
            "offset" => "",
            "orderby" => "title",
            "order" => "asc",
            "title" => "",
            "subtitle" => "",
            "description" => "",
            "link_caption" => esc_html__('Learn more', 'trx_utils'),
            "link" => '',
            "scheme" => '',
            // Common params
            "id" => "",
            "class" => "",
            "animation" => "",
            "css" => "",
            "width" => "",
            "height" => "",
            "top" => "",
            "bottom" => "",
            "left" => "",
            "right" => ""
        ), $atts)));

        if (empty($id)) $id = "sc_cars_".str_replace('.', '', mt_rand());
        if (empty($width)) $width = "100%";
        if (!empty($height) && cars4rent_param_is_on($autoheight)) $autoheight = "no";
        if (empty($interval)) $interval = mt_rand(5000, 10000);

        $class .= ($class ? ' ' : '') . cars4rent_get_css_position_as_classes($top, $right, $bottom, $left);

        $ws = cars4rent_get_css_dimensions_from_values($width);
        $hs = cars4rent_get_css_dimensions_from_values('', $height);
        $css .= ($hs) . ($ws);

        $count = max(1, (int) $count);
        $columns = max(1, min(12, (int) $columns));
        if (cars4rent_param_is_off($custom) && $count < $columns) $columns = $count;

        cars4rent_storage_set('sc_cars_data', array(
                'id' => $id,
                'style' => $style,
                'columns' => $columns,
                'counter' => 0,
                'slider' => $slider,
                'css_wh' => $ws . $hs
            )
        );

        if (cars4rent_param_is_on($slider)) cars4rent_enqueue_slider('swiper');

        $output = '<div' . ($id ? ' id="'.esc_attr($id).'_wrap"' : '')
            . ' class="sc_cars_wrap'
            . ($scheme && !cars4rent_param_is_off($scheme) && !cars4rent_param_is_inherit($scheme) ? ' scheme_'.esc_attr($scheme) : '')
            .'">'
            . '<div' . ($id ? ' id="'.esc_attr($id).'"' : '')
            . ' class="sc_cars sc_cars_style_'.esc_attr($style)
            . ' ' . esc_attr(cars4rent_get_template_property($style, 'container_classes'))
            . (!empty($class) ? ' '.esc_attr($class) : '')
            . ($align!='' && $align!='none' ? ' align'.esc_attr($align) : '')
            .'"'
            . ($css!='' ? ' style="'.esc_attr($css).'"' : '')
            . (!cars4rent_param_is_off($animation) ? ' data-animation="'.esc_attr(cars4rent_get_animation_classes($animation)).'"' : '')
            . '>'
            . (!empty($subtitle) ? '<h6 class="sc_cars_subtitle sc_item_subtitle">' . trim(cars4rent_strmacros($subtitle)) . '</h6>' : '')
            . (!empty($title) ? '<h2 class="sc_cars_title sc_item_title' . (empty($description) ? ' sc_item_title_without_descr' : ' sc_item_title_without_descr') . '">' . trim(cars4rent_strmacros($title)) . '</h2>' : '')
            . (!empty($description) ? '<div class="sc_cars_descr sc_item_descr">' . trim(cars4rent_strmacros($description)) . '</div>' : '')
            . (cars4rent_param_is_on($slider)
                ? ('<div class="sc_slider_swiper swiper-slider-container'
                    . ' ' . esc_attr(cars4rent_get_slider_controls_classes($controls))
                    . (cars4rent_param_is_on($autoheight) ? ' sc_slider_height_auto' : '')
                    . ($hs ? ' sc_slider_height_fixed' : '')
                    . '"'
                    . (!empty($width) && cars4rent_strpos($width, '%')===false ? ' data-old-width="' . esc_attr($width) . '"' : '')
                    . (!empty($height) && cars4rent_strpos($height, '%')===false ? ' data-old-height="' . esc_attr($height) . '"' : '')
                    . ((int) $interval > 0 ? ' data-interval="'.esc_attr($interval).'"' : '')
                    . ($slides_space > 0 ? ' data-slides-space="' . esc_attr($slides_space) . '"' : '')
                    . ($columns > 1 ? ' data-slides-per-view="' . esc_attr($columns) . '"' : '')
                    . ' data-slides-min-width="250"'
                    . '>'
                    . '<div class="slides swiper-wrapper">')
                : ($columns > 1
                    ? '<div class="sc_columns columns_wrap">'
                    : '')
            );

        if (cars4rent_param_is_on($custom) && $content) {
            $output .= do_shortcode($content);
        } else {
            global $post;

            if (!empty($ids)) {
                $posts = explode(',', $ids);
                $count = count($posts);
            }

            $args = array(
                'post_type' => 'cars',
                'post_status' => 'publish',
                'posts_per_page' => $count,
                'ignore_sticky_posts' => true,
                'order' => $order=='asc' ? 'asc' : 'desc',
            );

            if ($offset > 0 && empty($ids)) {
                $args['offset'] = $offset;
            }

            $args = cars4rent_query_add_sort_order($args, $orderby, $order);
            $args = cars4rent_query_add_posts_and_cats($args, $ids, 'cars', $cat, 'cars_group');
            $query = new WP_Query( $args );

            $post_number = 0;

            while ( $query->have_posts() ) {
                $query->the_post();
                $post_number++;
                $args = array(
                    'layout' => $style,
                    'show' => false,
                    'number' => $post_number,
                    'posts_on_page' => ($count > 0 ? $count : $query->found_posts),
                    "descr" => cars4rent_get_custom_option('post_excerpt_maxlength'.($columns > 1 ? '_masonry' : '')),
                    "orderby" => $orderby,
                    'content' => false,
                    'terms_list' => false,
                    "columns_count" => $columns,
                    'slider' => $slider,
                    'tag_id' => $id ? $id . '_' . $post_number : '',
                    'tag_class' => '',
                    'tag_animation' => '',
                    'tag_css' => '',
                    'tag_css_wh' => $ws . $hs
                );
                $post_data = cars4rent_get_post_data($args);
                $post_meta = get_post_meta($post_data['post_id'], cars4rent_storage_get('options_prefix').'_cars_data', true);
                $thumb_sizes = cars4rent_get_thumb_sizes(array('layout' => $style));
                $args['link'] = !empty($post_meta['cars_member_link']) ? $post_meta['cars_member_link'] : $post_data['post_link'];
                $args['photo'] = $post_data['post_thumb'];
                $mult = cars4rent_get_retina_multiplier();
                if (empty($args['photo']) && !empty($args['email'])) $args['photo'] = get_avatar($args['email'], $thumb_sizes['w']*$mult);
                $output .= cars4rent_show_post_layout($args, $post_data);
            }
            wp_reset_postdata();
        }

        if (cars4rent_param_is_on($slider)) {
            $output .= '</div>'
                . '<div class="sc_slider_controls_wrap"><a class="sc_slider_prev" href="#"></a><a class="sc_slider_next" href="#"></a></div>'
                . '<div class="sc_slider_pagination_wrap"></div>'
                . '</div>';
        } else if ($columns > 1) {
            $output .= '</div>';
        }

        $output .= (!empty($link) ? '<div class="sc_cars_button sc_item_button">'.cars4rent_do_shortcode('[trx_button link="'.esc_url($link).'" icon="icon-right"]'.esc_html($link_caption).'[/trx_button]').'</div>' : '')
            . '</div><!-- /.sc_cars -->'
            . '</div><!-- /.sc_cars_wrap -->';

        // Add template specific scripts and styles
        do_action('cars4rent_action_blog_scripts', $style);

        return apply_filters('cars4rent_shortcode_output', $output, 'trx_cars', $atts, $content);
    }
    cars4rent_require_shortcode('trx_cars', 'cars4rent_sc_cars');
}


if ( !function_exists( 'cars4rent_sc_cars_item' ) ) {
    function cars4rent_sc_cars_item($atts, $content=null) {
        if (cars4rent_in_shortcode_blogger()) return '';
        extract(cars4rent_html_decode(shortcode_atts( array(
            // Individual params
            "user" => "",
            "member" => "",
            "name" => "",
            "position" => "",
            "photo" => "",
            "email" => "",
            "link" => "",
            "socials" => "",
            // Common params
            "id" => "",
            "class" => "",
            "animation" => "",
            "css" => ""
        ), $atts)));

        cars4rent_storage_inc_array('sc_cars_data', 'counter');

        $id = $id ? $id : (cars4rent_storage_get_array('sc_cars_data', 'id') ? cars4rent_storage_get_array('sc_cars_data', 'id') . '_' . cars4rent_storage_get_array('sc_cars_data', 'counter') : '');

        $descr = trim(chop(do_shortcode($content)));

        $thumb_sizes = cars4rent_get_thumb_sizes(array('layout' => cars4rent_storage_get_array('sc_cars_data', 'style')));

        if (!empty($socials)) $socials = cars4rent_do_shortcode('[trx_socials size="tiny" shape="round" socials="'.esc_attr($socials).'"][/trx_socials]');

        if (!empty($user) && $user!='none' && ($user_obj = get_user_by('login', $user)) != false) {
            $meta = get_user_meta($user_obj->ID);
            if (empty($email))		$email = $user_obj->data->user_email;
            if (empty($name))		$name = $user_obj->data->display_name;
            if (empty($position))	$position = isset($meta['user_position'][0]) ? $meta['user_position'][0] : '';
            if (empty($descr))		$descr = isset($meta['description'][0]) ? $meta['description'][0] : '';
            if (empty($socials))	$socials = cars4rent_show_user_socials(array('author_id'=>$user_obj->ID, 'echo'=>false));
        }

        if (!empty($member) && $member!='none' && ($member_obj = (intval($member) > 0 ? get_post($member, OBJECT) : get_page_by_title($member, OBJECT, 'cars'))) != null) {
            if (empty($name))		$name = $member_obj->post_title;
            if (empty($descr))		$descr = $member_obj->post_excerpt;
            $post_meta = get_post_meta($member_obj->ID, cars4rent_storage_get('options_prefix').'_cars_data', true);
            if (empty($position))	$position = $post_meta['cars_member_position'];
            if (empty($link))		$link = !empty($post_meta['cars_member_link']) ? $post_meta['cars_member_link'] : get_permalink($member_obj->ID);
            if (empty($email))		$email = $post_meta['cars_member_email'];
            if (empty($photo)) 		$photo = wp_get_attachment_url(get_post_thumbnail_id($member_obj->ID));
            if (empty($socials)) {
                $socials = '';
                $soc_list = $post_meta['cars_member_socials'];
                if (is_array($soc_list) && count($soc_list)>0) {
                    $soc_str = '';
                    foreach ($soc_list as $sn=>$sl) {
                        if (!empty($sl))
                            $soc_str .= (!empty($soc_str) ? '|' : '') . ($sn) . '=' . ($sl);
                    }
                    if (!empty($soc_str))
                        $socials = cars4rent_do_shortcode('[trx_socials size="tiny" shape="round" socials="'.esc_attr($soc_str).'"][/trx_socials]');
                }
            }
        }
        if (empty($photo)) {
            $mult = cars4rent_get_retina_multiplier();
            if (!empty($email)) $photo = get_avatar($email, $thumb_sizes['w']*$mult);
        } else {
            if ($photo > 0) {
                $attach = wp_get_attachment_image_src( $photo, 'full' );
                if (isset($attach[0]) && $attach[0]!='')
                    $photo = $attach[0];
            }
            $photo = cars4rent_get_resized_image_tag($photo, $thumb_sizes['w'], $thumb_sizes['h']);
        }
        $post_data = array(
            'post_title' => $name,
            'post_excerpt' => $descr
        );
        $args = array(
            'layout' => cars4rent_storage_get_array('sc_cars_data', 'style'),
            'number' => cars4rent_storage_get_array('sc_cars_data', 'counter'),
            'columns_count' => cars4rent_storage_get_array('sc_cars_data', 'columns'),
            'slider' => cars4rent_storage_get_array('sc_cars_data', 'slider'),
            'show' => false,
            'descr'  => 0,
            'tag_id' => $id,
            'tag_class' => $class,
            'tag_animation' => $animation,
            'tag_css' => $css,
            'tag_css_wh' => cars4rent_storage_get_array('sc_cars_data', 'css_wh'),
            'position' => $position,
            'link' => $link,
            'email' => $email,
            'photo' => $photo,
            'socials' => $socials
        );
        $output = cars4rent_show_post_layout($args, $post_data);

        return apply_filters('cars4rent_shortcode_output', $output, 'trx_cars_item', $atts, $content);
    }
    cars4rent_require_shortcode('trx_cars_item', 'cars4rent_sc_cars_item');
}
// ---------------------------------- [/trx_cars] ---------------------------------------



// Add [trx_cars] and [trx_cars_item] in the shortcodes list
if (!function_exists('cars4rent_cars_reg_shortcodes')) {
    function cars4rent_cars_reg_shortcodes() {
        if (cars4rent_storage_isset('shortcodes')) {

            $users = cars4rent_get_list_users();
            $members = cars4rent_get_list_posts(false, array(
                    'post_type'=>'cars',
                    'orderby'=>'title',
                    'order'=>'asc',
                    'return'=>'title'
                )
            );
            $cars_groups = cars4rent_get_list_terms(false, 'cars_group');
            $cars_styles = cars4rent_get_list_templates('cars');
            $controls	 = cars4rent_get_list_slider_controls();

            cars4rent_sc_map_after('trx_tabs', array(

                // Cars
                "trx_cars" => array(
                    "title" => esc_html__("Cars", 'trx_utils'),
                    "desc" => wp_kses_data( __("Insert cars in your page (post)", 'trx_utils') ),
                    "decorate" => true,
                    "container" => false,
                    "params" => array(
                        "title" => array(
                            "title" => esc_html__("Title", 'trx_utils'),
                            "desc" => wp_kses_data( __("Title for the block", 'trx_utils') ),
                            "value" => "",
                            "type" => "text"
                        ),
                        "subtitle" => array(
                            "title" => esc_html__("Subtitle", 'trx_utils'),
                            "desc" => wp_kses_data( __("Subtitle for the block", 'trx_utils') ),
                            "value" => "",
                            "type" => "text"
                        ),
                        "description" => array(
                            "title" => esc_html__("Description", 'trx_utils'),
                            "desc" => wp_kses_data( __("Short description for the block", 'trx_utils') ),
                            "value" => "",
                            "type" => "textarea"
                        ),
                        "style" => array(
                            "title" => esc_html__("Cars style", 'trx_utils'),
                            "desc" => wp_kses_data( __("Select style to display cars members", 'trx_utils') ),
                            "value" => "cars-1",
                            "type" => "select",
                            "options" => $cars_styles
                        ),
                        "columns" => array(
                            "title" => esc_html__("Columns", 'trx_utils'),
                            "desc" => wp_kses_data( __("How many columns use to show cars members", 'trx_utils') ),
                            "value" => 3,
                            "min" => 2,
                            "max" => 5,
                            "step" => 1,
                            "type" => "spinner"
                        ),
                        "scheme" => array(
                            "title" => esc_html__("Color scheme", 'trx_utils'),
                            "desc" => wp_kses_data( __("Select color scheme for this block", 'trx_utils') ),
                            "value" => "",
                            "type" => "checklist",
                            "options" => cars4rent_get_sc_param('schemes')
                        ),
                        "slider" => array(
                            "title" => esc_html__("Slider", 'trx_utils'),
                            "desc" => wp_kses_data( __("Use slider to show cars members", 'trx_utils') ),
                            "value" => "no",
                            "type" => "switch",
                            "options" => cars4rent_get_sc_param('yes_no')
                        ),
                        "controls" => array(
                            "title" => esc_html__("Controls", 'trx_utils'),
                            "desc" => wp_kses_data( __("Slider controls style and position", 'trx_utils') ),
                            "dependency" => array(
                                'slider' => array('yes')
                            ),
                            "divider" => true,
                            "value" => "",
                            "type" => "checklist",
                            "dir" => "horizontal",
                            "options" => $controls
                        ),
                        "slides_space" => array(
                            "title" => esc_html__("Space between slides", 'trx_utils'),
                            "desc" => wp_kses_data( __("Size of space (in px) between slides", 'trx_utils') ),
                            "dependency" => array(
                                'slider' => array('yes')
                            ),
                            "value" => 0,
                            "min" => 0,
                            "max" => 100,
                            "step" => 10,
                            "type" => "spinner"
                        ),
                        "interval" => array(
                            "title" => esc_html__("Slides change interval", 'trx_utils'),
                            "desc" => wp_kses_data( __("Slides change interval (in milliseconds: 1000ms = 1s)", 'trx_utils') ),
                            "dependency" => array(
                                'slider' => array('yes')
                            ),
                            "value" => 7000,
                            "step" => 500,
                            "min" => 0,
                            "type" => "spinner"
                        ),
                        "autoheight" => array(
                            "title" => esc_html__("Autoheight", 'trx_utils'),
                            "desc" => wp_kses_data( __("Change whole slider's height (make it equal current slide's height)", 'trx_utils') ),
                            "dependency" => array(
                                'slider' => array('yes')
                            ),
                            "value" => "yes",
                            "type" => "switch",
                            "options" => cars4rent_get_sc_param('yes_no')
                        ),
                        "align" => array(
                            "title" => esc_html__("Alignment", 'trx_utils'),
                            "desc" => wp_kses_data( __("Alignment of the cars block", 'trx_utils') ),
                            "divider" => true,
                            "value" => "",
                            "type" => "checklist",
                            "dir" => "horizontal",
                            "options" => cars4rent_get_sc_param('align')
                        ),
                        "custom" => array(
                            "title" => esc_html__("Custom", 'trx_utils'),
                            "desc" => wp_kses_data( __("Allow get cars members from inner shortcodes (custom) or get it from specified group (cat)", 'trx_utils') ),
                            "divider" => true,
                            "value" => "no",
                            "type" => "switch",
                            "options" => cars4rent_get_sc_param('yes_no')
                        ),
                        "cat" => array(
                            "title" => esc_html__("Categories", 'trx_utils'),
                            "desc" => wp_kses_data( __("Select categories (groups) to show cars members. If empty - select cars members from any category (group) or from IDs list", 'trx_utils') ),
                            "dependency" => array(
                                'custom' => array('no')
                            ),
                            "divider" => true,
                            "value" => "",
                            "type" => "select",
                            "style" => "list",
                            "multiple" => true,
                            "options" => cars4rent_array_merge(array(0 => esc_html__('- Select category -', 'trx_utils')), $cars_groups)
                        ),
                        "count" => array(
                            "title" => esc_html__("Number of posts", 'trx_utils'),
                            "desc" => wp_kses_data( __("How many posts will be displayed? If used IDs - this parameter ignored.", 'trx_utils') ),
                            "dependency" => array(
                                'custom' => array('no')
                            ),
                            "value" => 3,
                            "min" => 1,
                            "max" => 100,
                            "type" => "spinner"
                        ),
                        "offset" => array(
                            "title" => esc_html__("Offset before select posts", 'trx_utils'),
                            "desc" => wp_kses_data( __("Skip posts before select next part.", 'trx_utils') ),
                            "dependency" => array(
                                'custom' => array('no')
                            ),
                            "value" => 0,
                            "min" => 0,
                            "type" => "spinner"
                        ),
                        "orderby" => array(
                            "title" => esc_html__("Post order by", 'trx_utils'),
                            "desc" => wp_kses_data( __("Select desired posts sorting method", 'trx_utils') ),
                            "dependency" => array(
                                'custom' => array('no')
                            ),
                            "value" => "title",
                            "type" => "select",
                            "options" => cars4rent_get_sc_param('sorting')
                        ),
                        "order" => array(
                            "title" => esc_html__("Post order", 'trx_utils'),
                            "desc" => wp_kses_data( __("Select desired posts order", 'trx_utils') ),
                            "dependency" => array(
                                'custom' => array('no')
                            ),
                            "value" => "asc",
                            "type" => "switch",
                            "size" => "big",
                            "options" => cars4rent_get_sc_param('ordering')
                        ),
                        "ids" => array(
                            "title" => esc_html__("Post IDs list", 'trx_utils'),
                            "desc" => wp_kses_data( __("Comma separated list of posts ID. If set - parameters above are ignored!", 'trx_utils') ),
                            "dependency" => array(
                                'custom' => array('no')
                            ),
                            "value" => "",
                            "type" => "text"
                        ),
                        "link" => array(
                            "title" => esc_html__("Button URL", 'trx_utils'),
                            "desc" => wp_kses_data( __("Link URL for the button at the bottom of the block", 'trx_utils') ),
                            "value" => "",
                            "type" => "text"
                        ),
                        "link_caption" => array(
                            "title" => esc_html__("Button caption", 'trx_utils'),
                            "desc" => wp_kses_data( __("Caption for the button at the bottom of the block", 'trx_utils') ),
                            "value" => "",
                            "type" => "text"
                        ),
                        "width" => cars4rent_shortcodes_width(),
                        "height" => cars4rent_shortcodes_height(),
                        "top" => cars4rent_get_sc_param('top'),
                        "bottom" => cars4rent_get_sc_param('bottom'),
                        "left" => cars4rent_get_sc_param('left'),
                        "right" => cars4rent_get_sc_param('right'),
                        "id" => cars4rent_get_sc_param('id'),
                        "class" => cars4rent_get_sc_param('class'),
                        "animation" => cars4rent_get_sc_param('animation'),
                        "css" => cars4rent_get_sc_param('css')
                    ),
                    "children" => array(
                        "name" => "trx_cars_item",
                        "title" => esc_html__("Member", 'trx_utils'),
                        "desc" => wp_kses_data( __("Cars member", 'trx_utils') ),
                        "container" => true,
                        "params" => array(
                            "user" => array(
                                "title" => esc_html__("Registerd user", 'trx_utils'),
                                "desc" => wp_kses_data( __("Select one of registered users (if present) or put name, position, etc. in fields below", 'trx_utils') ),
                                "value" => "",
                                "type" => "select",
                                "options" => $users
                            ),
                            "member" => array(
                                "title" => esc_html__("Cars member", 'trx_utils'),
                                "desc" => wp_kses_data( __("Select one of cars members (if present) or put name, position, etc. in fields below", 'trx_utils') ),
                                "value" => "",
                                "type" => "select",
                                "options" => $members
                            ),
                            "link" => array(
                                "title" => esc_html__("Link", 'trx_utils'),
                                "desc" => wp_kses_data( __("Link on cars member's personal page", 'trx_utils') ),
                                "divider" => true,
                                "value" => "",
                                "type" => "text"
                            ),
                            "name" => array(
                                "title" => esc_html__("Name", 'trx_utils'),
                                "desc" => wp_kses_data( __("Cars member's name", 'trx_utils') ),
                                "divider" => true,
                                "dependency" => array(
                                    'user' => array('is_empty', 'none'),
                                    'member' => array('is_empty', 'none')
                                ),
                                "value" => "",
                                "type" => "text"
                            ),
                            "position" => array(
                                "title" => esc_html__("Position", 'trx_utils'),
                                "desc" => wp_kses_data( __("Cars member's position", 'trx_utils') ),
                                "dependency" => array(
                                    'user' => array('is_empty', 'none'),
                                    'member' => array('is_empty', 'none')
                                ),
                                "value" => "",
                                "type" => "text"
                            ),
                            "email" => array(
                                "title" => esc_html__("E-mail", 'trx_utils'),
                                "desc" => wp_kses_data( __("Cars member's e-mail", 'trx_utils') ),
                                "dependency" => array(
                                    'user' => array('is_empty', 'none'),
                                    'member' => array('is_empty', 'none')
                                ),
                                "value" => "",
                                "type" => "text"
                            ),
                            "photo" => array(
                                "title" => esc_html__("Photo", 'trx_utils'),
                                "desc" => wp_kses_data( __("Cars member's photo (avatar)", 'trx_utils') ),
                                "dependency" => array(
                                    'user' => array('is_empty', 'none'),
                                    'member' => array('is_empty', 'none')
                                ),
                                "value" => "",
                                "readonly" => false,
                                "type" => "media"
                            ),
                            "socials" => array(
                                "title" => esc_html__("Socials", 'trx_utils'),
                                "desc" => wp_kses_data( __("Cars member's socials icons: name=url|name=url... For example: facebook=http://facebook.com/myaccount|twitter=http://twitter.com/myaccount", 'trx_utils') ),
                                "dependency" => array(
                                    'user' => array('is_empty', 'none'),
                                    'member' => array('is_empty', 'none')
                                ),
                                "value" => "",
                                "type" => "text"
                            ),
                            "_content_" => array(
                                "title" => esc_html__("Description", 'trx_utils'),
                                "desc" => wp_kses_data( __("Cars member's short description", 'trx_utils') ),
                                "divider" => true,
                                "rows" => 4,
                                "value" => "",
                                "type" => "textarea"
                            ),
                            "id" => cars4rent_get_sc_param('id'),
                            "class" => cars4rent_get_sc_param('class'),
                            "animation" => cars4rent_get_sc_param('animation'),
                            "css" => cars4rent_get_sc_param('css')
                        )
                    )
                )

            ));
        }
    }
}


// Add [trx_cars] and [trx_cars_item] in the VC shortcodes list
if (!function_exists('cars4rent_cars_reg_shortcodes_vc')) {
    function cars4rent_cars_reg_shortcodes_vc() {

        $users = cars4rent_get_list_users();
        $members = cars4rent_get_list_posts(false, array(
                'post_type'=>'cars',
                'orderby'=>'title',
                'order'=>'asc',
                'return'=>'title'
            )
        );
        $cars_groups = cars4rent_get_list_terms(false, 'cars_group');
        $cars_styles = cars4rent_get_list_templates('cars');
        $controls	 = cars4rent_get_list_slider_controls();

        // Cars
        vc_map( array(
            "base" => "trx_cars",
            "name" => esc_html__("Cars", 'trx_utils'),
            "description" => wp_kses_data( __("Insert cars members", 'trx_utils') ),
            "category" => esc_html__('Content', 'trx_utils'),
            'icon' => 'icon_trx_cars',
            "class" => "trx_sc_columns trx_sc_cars",
            "content_element" => true,
            "is_container" => true,
            "show_settings_on_create" => true,
            "as_parent" => array('only' => 'trx_cars_item'),
            "params" => array(
                array(
                    "param_name" => "style",
                    "heading" => esc_html__("Cars style", 'trx_utils'),
                    "description" => wp_kses_data( __("Select style to display cars members", 'trx_utils') ),
                    "class" => "",
                    "admin_label" => true,
                    "value" => array_flip($cars_styles),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "scheme",
                    "heading" => esc_html__("Color scheme", 'trx_utils'),
                    "description" => wp_kses_data( __("Select color scheme for this block", 'trx_utils') ),
                    "class" => "",
                    "value" => array_flip(cars4rent_get_sc_param('schemes')),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "slider",
                    "heading" => esc_html__("Slider", 'trx_utils'),
                    "description" => wp_kses_data( __("Use slider to show cars members", 'trx_utils') ),
                    "admin_label" => true,
                    "group" => esc_html__('Slider', 'trx_utils'),
                    "class" => "",
                    "std" => "no",
                    "value" => array_flip(cars4rent_get_sc_param('yes_no')),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "controls",
                    "heading" => esc_html__("Controls", 'trx_utils'),
                    "description" => wp_kses_data( __("Slider controls style and position", 'trx_utils') ),
                    "admin_label" => true,
                    "group" => esc_html__('Slider', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'slider',
                        'value' => 'yes'
                    ),
                    "class" => "",
                    "std" => "no",
                    "value" => array_flip($controls),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "slides_space",
                    "heading" => esc_html__("Space between slides", 'trx_utils'),
                    "description" => wp_kses_data( __("Size of space (in px) between slides", 'trx_utils') ),
                    "admin_label" => true,
                    "group" => esc_html__('Slider', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'slider',
                        'value' => 'yes'
                    ),
                    "class" => "",
                    "value" => "0",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "interval",
                    "heading" => esc_html__("Slides change interval", 'trx_utils'),
                    "description" => wp_kses_data( __("Slides change interval (in milliseconds: 1000ms = 1s)", 'trx_utils') ),
                    "group" => esc_html__('Slider', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'slider',
                        'value' => 'yes'
                    ),
                    "class" => "",
                    "value" => "7000",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "autoheight",
                    "heading" => esc_html__("Autoheight", 'trx_utils'),
                    "description" => wp_kses_data( __("Change whole slider's height (make it equal current slide's height)", 'trx_utils') ),
                    "group" => esc_html__('Slider', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'slider',
                        'value' => 'yes'
                    ),
                    "class" => "",
                    "value" => array("Autoheight" => "yes" ),
                    "type" => "checkbox"
                ),
                array(
                    "param_name" => "align",
                    "heading" => esc_html__("Alignment", 'trx_utils'),
                    "description" => wp_kses_data( __("Alignment of the cars block", 'trx_utils') ),
                    "class" => "",
                    "value" => array_flip(cars4rent_get_sc_param('align')),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "custom",
                    "heading" => esc_html__("Custom", 'trx_utils'),
                    "description" => wp_kses_data( __("Allow get cars members from inner shortcodes (custom) or get it from specified group (cat)", 'trx_utils') ),
                    "class" => "",
                    "value" => array("Custom members" => "yes" ),
                    "type" => "checkbox"
                ),
                array(
                    "param_name" => "title",
                    "heading" => esc_html__("Title", 'trx_utils'),
                    "description" => wp_kses_data( __("Title for the block", 'trx_utils') ),
                    "admin_label" => true,
                    "group" => esc_html__('Captions', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "subtitle",
                    "heading" => esc_html__("Subtitle", 'trx_utils'),
                    "description" => wp_kses_data( __("Subtitle for the block", 'trx_utils') ),
                    "group" => esc_html__('Captions', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "description",
                    "heading" => esc_html__("Description", 'trx_utils'),
                    "description" => wp_kses_data( __("Description for the block", 'trx_utils') ),
                    "group" => esc_html__('Captions', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "textarea"
                ),
                array(
                    "param_name" => "cat",
                    "heading" => esc_html__("Categories", 'trx_utils'),
                    "description" => wp_kses_data( __("Select category to show cars members. If empty - select cars members from any category (group) or from IDs list", 'trx_utils') ),
                    "group" => esc_html__('Query', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'custom',
                        'is_empty' => true
                    ),
                    "class" => "",
                    "value" => array_flip(cars4rent_array_merge(array(0 => esc_html__('- Select category -', 'trx_utils')), $cars_groups)),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "columns",
                    "heading" => esc_html__("Columns", 'trx_utils'),
                    "description" => wp_kses_data( __("How many columns use to show cars members", 'trx_utils') ),
                    "group" => esc_html__('Query', 'trx_utils'),
                    "admin_label" => true,
                    "class" => "",
                    "value" => "3",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "count",
                    "heading" => esc_html__("Number of posts", 'trx_utils'),
                    "description" => wp_kses_data( __("How many posts will be displayed? If used IDs - this parameter ignored.", 'trx_utils') ),
                    "group" => esc_html__('Query', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'custom',
                        'is_empty' => true
                    ),
                    "class" => "",
                    "value" => "3",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "offset",
                    "heading" => esc_html__("Offset before select posts", 'trx_utils'),
                    "description" => wp_kses_data( __("Skip posts before select next part.", 'trx_utils') ),
                    "group" => esc_html__('Query', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'custom',
                        'is_empty' => true
                    ),
                    "class" => "",
                    "value" => "0",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "orderby",
                    "heading" => esc_html__("Post sorting", 'trx_utils'),
                    "description" => wp_kses_data( __("Select desired posts sorting method", 'trx_utils') ),
                    "group" => esc_html__('Query', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'custom',
                        'is_empty' => true
                    ),
                    "std" => "title",
                    "class" => "",
                    "value" => array_flip(cars4rent_get_sc_param('sorting')),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "order",
                    "heading" => esc_html__("Post order", 'trx_utils'),
                    "description" => wp_kses_data( __("Select desired posts order", 'trx_utils') ),
                    "group" => esc_html__('Query', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'custom',
                        'is_empty' => true
                    ),
                    "std" => "asc",
                    "class" => "",
                    "value" => array_flip(cars4rent_get_sc_param('ordering')),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "ids",
                    "heading" => esc_html__("Cars member's IDs list", 'trx_utils'),
                    "description" => wp_kses_data( __("Comma separated list of cars members's ID. If set - parameters above (category, count, order, etc.)  are ignored!", 'trx_utils') ),
                    "group" => esc_html__('Query', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'custom',
                        'is_empty' => true
                    ),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "link",
                    "heading" => esc_html__("Button URL", 'trx_utils'),
                    "description" => wp_kses_data( __("Link URL for the button at the bottom of the block", 'trx_utils') ),
                    "group" => esc_html__('Captions', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "link_caption",
                    "heading" => esc_html__("Button caption", 'trx_utils'),
                    "description" => wp_kses_data( __("Caption for the button at the bottom of the block", 'trx_utils') ),
                    "group" => esc_html__('Captions', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                cars4rent_vc_width(),
                cars4rent_vc_height(),
                cars4rent_get_vc_param('margin_top'),
                cars4rent_get_vc_param('margin_bottom'),
                cars4rent_get_vc_param('margin_left'),
                cars4rent_get_vc_param('margin_right'),
                cars4rent_get_vc_param('id'),
                cars4rent_get_vc_param('class'),
                cars4rent_get_vc_param('animation'),
                cars4rent_get_vc_param('css')
            ),
            'default_content' => '
					[trx_cars_item user="' . esc_html__( 'Member 1', 'trx_utils' ) . '"][/trx_cars_item]
					[trx_cars_item user="' . esc_html__( 'Member 2', 'trx_utils' ) . '"][/trx_cars_item]
					[trx_cars_item user="' . esc_html__( 'Member 4', 'trx_utils' ) . '"][/trx_cars_item]
				',
            'js_view' => 'VcTrxColumnsView'
        ) );


        vc_map( array(
            "base" => "trx_cars_item",
            "name" => esc_html__("Cars member", 'trx_utils'),
            "description" => wp_kses_data( __("Cars member - all data pull out from it account on your site", 'trx_utils') ),
            "show_settings_on_create" => true,
            "class" => "trx_sc_collection trx_sc_column_item trx_sc_cars_item",
            "content_element" => true,
            "is_container" => true,
            'icon' => 'icon_trx_cars_item',
            "as_child" => array('only' => 'trx_cars'),
            "as_parent" => array('except' => 'trx_cars'),
            "params" => array(
                array(
                    "param_name" => "user",
                    "heading" => esc_html__("Registered user", 'trx_utils'),
                    "description" => wp_kses_data( __("Select one of registered users (if present) or put name, position, etc. in fields below", 'trx_utils') ),
                    "admin_label" => true,
                    "class" => "",
                    "value" => array_flip($users),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "member",
                    "heading" => esc_html__("Cars member", 'trx_utils'),
                    "description" => wp_kses_data( __("Select one of cars members (if present) or put name, position, etc. in fields below", 'trx_utils') ),
                    "admin_label" => true,
                    "class" => "",
                    "value" => array_flip($members),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "link",
                    "heading" => esc_html__("Link", 'trx_utils'),
                    "description" => wp_kses_data( __("Link on cars member's personal page", 'trx_utils') ),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "name",
                    "heading" => esc_html__("Name", 'trx_utils'),
                    "description" => wp_kses_data( __("Cars member's name", 'trx_utils') ),
                    "admin_label" => true,
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "position",
                    "heading" => esc_html__("Position", 'trx_utils'),
                    "description" => wp_kses_data( __("Cars member's position", 'trx_utils') ),
                    "admin_label" => true,
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "email",
                    "heading" => esc_html__("E-mail", 'trx_utils'),
                    "description" => wp_kses_data( __("Cars member's e-mail", 'trx_utils') ),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "photo",
                    "heading" => esc_html__("Member's Photo", 'trx_utils'),
                    "description" => wp_kses_data( __("Cars member's photo (avatar)", 'trx_utils') ),
                    "class" => "",
                    "value" => "",
                    "type" => "attach_image"
                ),
                array(
                    "param_name" => "socials",
                    "heading" => esc_html__("Socials", 'trx_utils'),
                    "description" => wp_kses_data( __("Cars member's socials icons: name=url|name=url... For example: facebook=http://facebook.com/myaccount|twitter=http://twitter.com/myaccount", 'trx_utils') ),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                cars4rent_get_vc_param('id'),
                cars4rent_get_vc_param('class'),
                cars4rent_get_vc_param('animation'),
                cars4rent_get_vc_param('css')
            ),
            'js_view' => 'VcTrxColumnItemView'
        ) );

        class WPBakeryShortCode_Trx_Cars extends Cars4Rent_Vc_ShortCodeColumns {}
        class WPBakeryShortCode_Trx_Cars_Item extends Cars4Rent_Vc_ShortCodeCollection {}

    }
}


// ---------------------------------- [trx_clients] ---------------------------------------

if ( !function_exists( 'cars4rent_sc_clients' ) ) {
    function cars4rent_sc_clients($atts, $content=null){
        if (cars4rent_in_shortcode_blogger()) return '';
        extract(cars4rent_html_decode(shortcode_atts(array(
            // Individual params
            "style" => "clients-1",
            "columns" => 4,
            "slider" => "no",
            "slides_space" => 0,
            "controls" => "no",
            "interval" => "",
            "autoheight" => "no",
            "custom" => "no",
            "ids" => "",
            "cat" => "",
            "count" => 4,
            "offset" => "",
            "orderby" => "title",
            "order" => "asc",
            "title" => "",
            "subtitle" => "",
            "description" => "",
            "link_caption" => esc_html__('Learn more', 'trx_utils'),
            "link" => '',
            "scheme" => '',
            // Common params
            "id" => "",
            "class" => "",
            "animation" => "",
            "css" => "",
            "width" => "",
            "height" => "",
            "top" => "",
            "bottom" => "",
            "left" => "",
            "right" => ""
        ), $atts)));

        if (empty($id)) $id = "sc_clients_".str_replace('.', '', mt_rand());
        if (empty($width)) $width = "100%";
        if (!empty($height) && cars4rent_param_is_on($autoheight)) $autoheight = "no";
        if (empty($interval)) $interval = mt_rand(5000, 10000);

        $class .= ($class ? ' ' : '') . cars4rent_get_css_position_as_classes($top, $right, $bottom, $left);

        $ws = cars4rent_get_css_dimensions_from_values($width);
        $hs = cars4rent_get_css_dimensions_from_values('', $height);
        $css .= ($hs) . ($ws);

        if (cars4rent_param_is_on($slider)) cars4rent_enqueue_slider('swiper');

        $columns = max(1, min(12, $columns));
        $count = max(1, (int) $count);
        if (cars4rent_param_is_off($custom) && $count < $columns) $columns = $count;
        cars4rent_storage_set('sc_clients_data', array(
                'id'=>$id,
                'style'=>$style,
                'counter'=>0,
                'columns'=>$columns,
                'slider'=>$slider,
                'css_wh'=>$ws . $hs
            )
        );

        $output = '<div' . ($id ? ' id="'.esc_attr($id).'_wrap"' : '')
            . ' class="sc_clients_wrap'
            . ($scheme && !cars4rent_param_is_off($scheme) && !cars4rent_param_is_inherit($scheme) ? ' scheme_'.esc_attr($scheme) : '')
            .'">'
            . '<div' . ($id ? ' id="'.esc_attr($id).'"' : '')
            . ' class="sc_clients sc_clients_style_'.esc_attr($style)
            . ' ' . esc_attr(cars4rent_get_template_property($style, 'container_classes'))
            . (!empty($class) ? ' '.esc_attr($class) : '')
            .'"'
            . ($css!='' ? ' style="'.esc_attr($css).'"' : '')
            . (!cars4rent_param_is_off($animation) ? ' data-animation="'.esc_attr(cars4rent_get_animation_classes($animation)).'"' : '')
            . '>'
            . (!empty($subtitle) ? '<h6 class="sc_clients_subtitle sc_item_subtitle">' . trim(cars4rent_strmacros($subtitle)) . '</h6>' : '')
            . (!empty($title) ? '<h2 class="sc_clients_title sc_item_title' . (empty($description) ? ' sc_item_title_without_descr' : ' sc_item_title_with_descr') . '">' . trim(cars4rent_strmacros($title)) . '</h2>' : '')
            . (!empty($description) ? '<div class="sc_clients_descr sc_item_descr">' . trim(cars4rent_strmacros($description)) . '</div>' : '')
            . (cars4rent_param_is_on($slider)
                ? ('<div class="sc_slider_swiper swiper-slider-container'
                    . ' ' . esc_attr(cars4rent_get_slider_controls_classes($controls))
                    . (cars4rent_param_is_on($autoheight) ? ' sc_slider_height_auto' : '')
                    . ($hs ? ' sc_slider_height_fixed' : '')
                    . '"'
                    . (!empty($width) && cars4rent_strpos($width, '%')===false ? ' data-old-width="' . esc_attr($width) . '"' : '')
                    . (!empty($height) && cars4rent_strpos($height, '%')===false ? ' data-old-height="' . esc_attr($height) . '"' : '')
                    . ((int) $interval > 0 ? ' data-interval="'.esc_attr($interval).'"' : '')
                    . ($columns > 1 ? ' data-slides-per-view="' . esc_attr($columns) . '"' : '')
                    . ($slides_space > 0 ? ' data-slides-space="' . esc_attr($slides_space) . '"' : '')
                    . ' data-slides-min-width="' . ($style=='clients-1' ? 100 : 220) . '"'
                    . '>'
                    . '<div class="slides swiper-wrapper">')
                : ($columns > 1
                    ? '<div class="sc_columns columns_wrap">'
                    : '')
            );

        if (cars4rent_param_is_on($custom) && $content) {
            $output .= do_shortcode($content);
        } else {
            global $post;

            if (!empty($ids)) {
                $posts = explode(',', $ids);
                $count = count($posts);
            }

            $args = array(
                'post_type' => 'clients',
                'post_status' => 'publish',
                'posts_per_page' => $count,
                'ignore_sticky_posts' => true,
                'order' => $order=='asc' ? 'asc' : 'desc',
            );

            if ($offset > 0 && empty($ids)) {
                $args['offset'] = $offset;
            }

            $args = cars4rent_query_add_sort_order($args, $orderby, $order);
            $args = cars4rent_query_add_posts_and_cats($args, $ids, 'clients', $cat, 'clients_group');

            $query = new WP_Query( $args );

            $post_number = 0;

            while ( $query->have_posts() ) {
                $query->the_post();
                $post_number++;
                $args = array(
                    'layout' => $style,
                    'show' => false,
                    'number' => $post_number,
                    'posts_on_page' => ($count > 0 ? $count : $query->found_posts),
                    "descr" => cars4rent_get_custom_option('post_excerpt_maxlength'.($columns > 1 ? '_masonry' : '')),
                    "orderby" => $orderby,
                    'content' => false,
                    'terms_list' => false,
                    'columns_count' => $columns,
                    'slider' => $slider,
                    'tag_id' => $id ? $id . '_' . $post_number : '',
                    'tag_class' => '',
                    'tag_animation' => '',
                    'tag_css' => '',
                    'tag_css_wh' => $ws . $hs
                );
                $post_data = cars4rent_get_post_data($args);
                $post_meta = get_post_meta($post_data['post_id'], cars4rent_storage_get('options_prefix') . '_post_options', true);
                $thumb_sizes = cars4rent_get_thumb_sizes(array('layout' => $style));
                $args['client_name'] = $post_meta['client_name'];
                $args['client_position'] = $post_meta['client_position'];
                $args['client_image'] = $post_data['post_thumb'];
                $args['client_link'] = cars4rent_param_is_on('client_show_link')
                    ? (!empty($post_meta['client_link']) ? $post_meta['client_link'] : $post_data['post_link'])
                    : '';
                $output .= cars4rent_show_post_layout($args, $post_data);
            }
            wp_reset_postdata();
        }

        if (cars4rent_param_is_on($slider)) {
            $output .= '</div>'
                . '<div class="sc_slider_controls_wrap"><a class="sc_slider_prev" href="#"></a><a class="sc_slider_next" href="#"></a></div>'
                . '<div class="sc_slider_pagination_wrap"></div>'
                . '</div>';
        } else if ($columns > 1) {
            $output .= '</div>';
        }

        $output .= (!empty($link) ? '<div class="sc_clients_button sc_item_button">'.cars4rent_do_shortcode('[trx_button link="'.esc_url($link).'" icon="icon-right"]'.esc_html($link_caption).'[/trx_button]').'</div>' : '')
            . '</div><!-- /.sc_clients -->'
            . '</div><!-- /.sc_clients_wrap -->';

        // Add template specific scripts and styles
        do_action('cars4rent_action_blog_scripts', $style);

        return apply_filters('cars4rent_shortcode_output', $output, 'trx_clients', $atts, $content);
    }
    cars4rent_require_shortcode('trx_clients', 'cars4rent_sc_clients');
}


if ( !function_exists( 'cars4rent_sc_clients_item' ) ) {
    function cars4rent_sc_clients_item($atts, $content=null) {
        if (cars4rent_in_shortcode_blogger()) return '';
        extract(cars4rent_html_decode(shortcode_atts( array(
            // Individual params
            "name" => "",
            "position" => "",
            "image" => "",
            "link" => "",
            // Common params
            "id" => "",
            "class" => "",
            "animation" => "",
            "css" => ""
        ), $atts)));

        cars4rent_storage_inc_array('sc_clients_data', 'counter');

        $id = $id ? $id : (cars4rent_storage_get_array('sc_clients_data', 'id') ? cars4rent_storage_get_array('sc_clients_data', 'id') . '_' . cars4rent_storage_get_array('sc_clients_data', 'counter') : '');

        $descr = trim(chop(do_shortcode($content)));

        $thumb_sizes = cars4rent_get_thumb_sizes(array('layout' => cars4rent_storage_get_array('sc_clients_data', 'style')));

        if ($image > 0) {
            $attach = wp_get_attachment_image_src( $image, 'full' );
            if (isset($attach[0]) && $attach[0]!='')
                $image = $attach[0];
        }
        $image = cars4rent_get_resized_image_tag($image, $thumb_sizes['w'], $thumb_sizes['h']);

        $post_data = array(
            'post_title' => $name,
            'post_excerpt' => $descr
        );
        $args = array(
            'layout' => cars4rent_storage_get_array('sc_clients_data', 'style'),
            'number' => cars4rent_storage_get_array('sc_clients_data', 'counter'),
            'columns_count' => cars4rent_storage_get_array('sc_clients_data', 'columns'),
            'slider' => cars4rent_storage_get_array('sc_clients_data', 'slider'),
            'show' => false,
            'descr'  => 0,
            'tag_id' => $id,
            'tag_class' => $class,
            'tag_animation' => $animation,
            'tag_css' => $css,
            'tag_css_wh' => cars4rent_storage_get_array('sc_clients_data', 'css_wh'),
            'client_position' => $position,
            'client_link' => $link,
            'client_image' => $image
        );
        $output = cars4rent_show_post_layout($args, $post_data);
        return apply_filters('cars4rent_shortcode_output', $output, 'trx_clients_item', $atts, $content);
    }
    cars4rent_require_shortcode('trx_clients_item', 'cars4rent_sc_clients_item');
}
// ---------------------------------- [/trx_clients] ---------------------------------------



// Add [trx_clients] and [trx_clients_item] in the shortcodes list
if (!function_exists('cars4rent_clients_reg_shortcodes')) {
    function cars4rent_clients_reg_shortcodes() {
        if (cars4rent_storage_isset('shortcodes')) {

            $users = cars4rent_get_list_users();
            $members = cars4rent_get_list_posts(false, array(
                    'post_type'=>'clients',
                    'orderby'=>'title',
                    'order'=>'asc',
                    'return'=>'title'
                )
            );
            $clients_groups = cars4rent_get_list_terms(false, 'clients_group');
            $clients_styles = cars4rent_get_list_templates('clients');
            $controls 		= cars4rent_get_list_slider_controls();

            cars4rent_sc_map_after('trx_chat', array(

                // Clients
                "trx_clients" => array(
                    "title" => esc_html__("Clients", 'trx_utils'),
                    "desc" => wp_kses_data( __("Insert clients list in your page (post)", 'trx_utils') ),
                    "decorate" => true,
                    "container" => false,
                    "params" => array(
                        "title" => array(
                            "title" => esc_html__("Title", 'trx_utils'),
                            "desc" => wp_kses_data( __("Title for the block", 'trx_utils') ),
                            "value" => "",
                            "type" => "text"
                        ),
                        "subtitle" => array(
                            "title" => esc_html__("Subtitle", 'trx_utils'),
                            "desc" => wp_kses_data( __("Subtitle for the block", 'trx_utils') ),
                            "value" => "",
                            "type" => "text"
                        ),
                        "description" => array(
                            "title" => esc_html__("Description", 'trx_utils'),
                            "desc" => wp_kses_data( __("Short description for the block", 'trx_utils') ),
                            "value" => "",
                            "type" => "textarea"
                        ),
                        "style" => array(
                            "title" => esc_html__("Clients style", 'trx_utils'),
                            "desc" => wp_kses_data( __("Select style to display clients list", 'trx_utils') ),
                            "value" => "clients-1",
                            "type" => "select",
                            "options" => $clients_styles
                        ),
                        "columns" => array(
                            "title" => esc_html__("Columns", 'trx_utils'),
                            "desc" => wp_kses_data( __("How many columns use to show clients", 'trx_utils') ),
                            "value" => 4,
                            "min" => 2,
                            "max" => 6,
                            "step" => 1,
                            "type" => "spinner"
                        ),
                        "scheme" => array(
                            "title" => esc_html__("Color scheme", 'trx_utils'),
                            "desc" => wp_kses_data( __("Select color scheme for this block", 'trx_utils') ),
                            "value" => "",
                            "type" => "checklist",
                            "options" => cars4rent_get_sc_param('schemes')
                        ),
                        "slider" => array(
                            "title" => esc_html__("Slider", 'trx_utils'),
                            "desc" => wp_kses_data( __("Use slider to show clients", 'trx_utils') ),
                            "value" => "no",
                            "type" => "switch",
                            "options" => cars4rent_get_sc_param('yes_no')
                        ),
                        "controls" => array(
                            "title" => esc_html__("Controls", 'trx_utils'),
                            "desc" => wp_kses_data( __("Slider controls style and position", 'trx_utils') ),
                            "dependency" => array(
                                'slider' => array('yes')
                            ),
                            "divider" => true,
                            "value" => "no",
                            "type" => "checklist",
                            "dir" => "horizontal",
                            "options" => $controls
                        ),
                        "slides_space" => array(
                            "title" => esc_html__("Space between slides", 'trx_utils'),
                            "desc" => wp_kses_data( __("Size of space (in px) between slides", 'trx_utils') ),
                            "dependency" => array(
                                'slider' => array('yes')
                            ),
                            "value" => 0,
                            "min" => 0,
                            "max" => 100,
                            "step" => 10,
                            "type" => "spinner"
                        ),
                        "interval" => array(
                            "title" => esc_html__("Slides change interval", 'trx_utils'),
                            "desc" => wp_kses_data( __("Slides change interval (in milliseconds: 1000ms = 1s)", 'trx_utils') ),
                            "dependency" => array(
                                'slider' => array('yes')
                            ),
                            "value" => 7000,
                            "step" => 500,
                            "min" => 0,
                            "type" => "spinner"
                        ),
                        "autoheight" => array(
                            "title" => esc_html__("Autoheight", 'trx_utils'),
                            "desc" => wp_kses_data( __("Change whole slider's height (make it equal current slide's height)", 'trx_utils') ),
                            "dependency" => array(
                                'slider' => array('yes')
                            ),
                            "value" => "no",
                            "type" => "switch",
                            "options" => cars4rent_get_sc_param('yes_no')
                        ),
                        "custom" => array(
                            "title" => esc_html__("Custom", 'trx_utils'),
                            "desc" => wp_kses_data( __("Allow get team members from inner shortcodes (custom) or get it from specified group (cat)", 'trx_utils') ),
                            "divider" => true,
                            "value" => "no",
                            "type" => "switch",
                            "options" => cars4rent_get_sc_param('yes_no')
                        ),
                        "cat" => array(
                            "title" => esc_html__("Categories", 'trx_utils'),
                            "desc" => wp_kses_data( __("Select categories (groups) to show team members. If empty - select team members from any category (group) or from IDs list", 'trx_utils') ),
                            "dependency" => array(
                                'custom' => array('no')
                            ),
                            "divider" => true,
                            "value" => "",
                            "type" => "select",
                            "style" => "list",
                            "multiple" => true,
                            "options" => cars4rent_array_merge(array(0 => esc_html__('- Select category -', 'trx_utils')), $clients_groups)
                        ),
                        "count" => array(
                            "title" => esc_html__("Number of posts", 'trx_utils'),
                            "desc" => wp_kses_data( __("How many posts will be displayed? If used IDs - this parameter ignored.", 'trx_utils') ),
                            "dependency" => array(
                                'custom' => array('no')
                            ),
                            "value" => 4,
                            "min" => 1,
                            "max" => 100,
                            "type" => "spinner"
                        ),
                        "offset" => array(
                            "title" => esc_html__("Offset before select posts", 'trx_utils'),
                            "desc" => wp_kses_data( __("Skip posts before select next part.", 'trx_utils') ),
                            "dependency" => array(
                                'custom' => array('no')
                            ),
                            "value" => 0,
                            "min" => 0,
                            "type" => "spinner"
                        ),
                        "orderby" => array(
                            "title" => esc_html__("Post order by", 'trx_utils'),
                            "desc" => wp_kses_data( __("Select desired posts sorting method", 'trx_utils') ),
                            "dependency" => array(
                                'custom' => array('no')
                            ),
                            "value" => "title",
                            "type" => "select",
                            "options" => cars4rent_get_sc_param('sorting')
                        ),
                        "order" => array(
                            "title" => esc_html__("Post order", 'trx_utils'),
                            "desc" => wp_kses_data( __("Select desired posts order", 'trx_utils') ),
                            "dependency" => array(
                                'custom' => array('no')
                            ),
                            "value" => "asc",
                            "type" => "switch",
                            "size" => "big",
                            "options" => cars4rent_get_sc_param('ordering')
                        ),
                        "ids" => array(
                            "title" => esc_html__("Post IDs list", 'trx_utils'),
                            "desc" => wp_kses_data( __("Comma separated list of posts ID. If set - parameters above are ignored!", 'trx_utils') ),
                            "dependency" => array(
                                'custom' => array('no')
                            ),
                            "value" => "",
                            "type" => "text"
                        ),
                        "link" => array(
                            "title" => esc_html__("Button URL", 'trx_utils'),
                            "desc" => wp_kses_data( __("Link URL for the button at the bottom of the block", 'trx_utils') ),
                            "value" => "",
                            "type" => "text"
                        ),
                        "link_caption" => array(
                            "title" => esc_html__("Button caption", 'trx_utils'),
                            "desc" => wp_kses_data( __("Caption for the button at the bottom of the block", 'trx_utils') ),
                            "value" => "",
                            "type" => "text"
                        ),
                        "width" => cars4rent_shortcodes_width(),
                        "height" => cars4rent_shortcodes_height(),
                        "top" => cars4rent_get_sc_param('top'),
                        "bottom" => cars4rent_get_sc_param('bottom'),
                        "left" => cars4rent_get_sc_param('left'),
                        "right" => cars4rent_get_sc_param('right'),
                        "id" => cars4rent_get_sc_param('id'),
                        "class" => cars4rent_get_sc_param('class'),
                        "animation" => cars4rent_get_sc_param('animation'),
                        "css" => cars4rent_get_sc_param('css')
                    ),
                    "children" => array(
                        "name" => "trx_clients_item",
                        "title" => esc_html__("Client", 'trx_utils'),
                        "desc" => wp_kses_data( __("Single client (custom parameters)", 'trx_utils') ),
                        "container" => true,
                        "params" => array(
                            "name" => array(
                                "title" => esc_html__("Name", 'trx_utils'),
                                "desc" => wp_kses_data( __("Client's name", 'trx_utils') ),
                                "divider" => true,
                                "value" => "",
                                "type" => "text"
                            ),
                            "position" => array(
                                "title" => esc_html__("Position", 'trx_utils'),
                                "desc" => wp_kses_data( __("Client's position", 'trx_utils') ),
                                "value" => "",
                                "type" => "text"
                            ),
                            "link" => array(
                                "title" => esc_html__("Link", 'trx_utils'),
                                "desc" => wp_kses_data( __("Link on client's personal page", 'trx_utils') ),
                                "divider" => true,
                                "value" => "",
                                "type" => "text"
                            ),
                            "image" => array(
                                "title" => esc_html__("Image", 'trx_utils'),
                                "desc" => wp_kses_data( __("Client's image", 'trx_utils') ),
                                "value" => "",
                                "readonly" => false,
                                "type" => "media"
                            ),
                            "_content_" => array(
                                "title" => esc_html__("Description", 'trx_utils'),
                                "desc" => wp_kses_data( __("Client's short description", 'trx_utils') ),
                                "divider" => true,
                                "rows" => 4,
                                "value" => "",
                                "type" => "textarea"
                            ),
                            "id" => cars4rent_get_sc_param('id'),
                            "class" => cars4rent_get_sc_param('class'),
                            "animation" => cars4rent_get_sc_param('animation'),
                            "css" => cars4rent_get_sc_param('css')
                        )
                    )
                )

            ));
        }
    }
}


// Add [trx_clients] and [trx_clients_item] in the VC shortcodes list
if (!function_exists('cars4rent_clients_reg_shortcodes_vc')) {
    function cars4rent_clients_reg_shortcodes_vc() {

        $clients_groups = cars4rent_get_list_terms(false, 'clients_group');
        $clients_styles = cars4rent_get_list_templates('clients');
        $controls		= cars4rent_get_list_slider_controls();

        // Clients
        vc_map( array(
            "base" => "trx_clients",
            "name" => esc_html__("Clients", 'trx_utils'),
            "description" => wp_kses_data( __("Insert clients list", 'trx_utils') ),
            "category" => esc_html__('Content', 'trx_utils'),
            'icon' => 'icon_trx_clients',
            "class" => "trx_sc_columns trx_sc_clients",
            "content_element" => true,
            "is_container" => true,
            "show_settings_on_create" => true,
            "as_parent" => array('only' => 'trx_clients_item'),
            "params" => array(
                array(
                    "param_name" => "style",
                    "heading" => esc_html__("Clients style", 'trx_utils'),
                    "description" => wp_kses_data( __("Select style to display clients list", 'trx_utils') ),
                    "class" => "",
                    "admin_label" => true,
                    "value" => array_flip($clients_styles),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "scheme",
                    "heading" => esc_html__("Color scheme", 'trx_utils'),
                    "description" => wp_kses_data( __("Select color scheme for this block", 'trx_utils') ),
                    "class" => "",
                    "value" => array_flip(cars4rent_get_sc_param('schemes')),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "slider",
                    "heading" => esc_html__("Slider", 'trx_utils'),
                    "description" => wp_kses_data( __("Use slider to show testimonials", 'trx_utils') ),
                    "admin_label" => true,
                    "group" => esc_html__('Slider', 'trx_utils'),
                    "class" => "",
                    "std" => "no",
                    "value" => array_flip(cars4rent_get_sc_param('yes_no')),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "controls",
                    "heading" => esc_html__("Controls", 'trx_utils'),
                    "description" => wp_kses_data( __("Slider controls style and position", 'trx_utils') ),
                    "admin_label" => true,
                    "group" => esc_html__('Slider', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'slider',
                        'value' => 'yes'
                    ),
                    "class" => "",
                    "std" => "no",
                    "value" => array_flip($controls),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "slides_space",
                    "heading" => esc_html__("Space between slides", 'trx_utils'),
                    "description" => wp_kses_data( __("Size of space (in px) between slides", 'trx_utils') ),
                    "admin_label" => true,
                    "group" => esc_html__('Slider', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'slider',
                        'value' => 'yes'
                    ),
                    "class" => "",
                    "value" => "0",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "interval",
                    "heading" => esc_html__("Slides change interval", 'trx_utils'),
                    "description" => wp_kses_data( __("Slides change interval (in milliseconds: 1000ms = 1s)", 'trx_utils') ),
                    "group" => esc_html__('Slider', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'slider',
                        'value' => 'yes'
                    ),
                    "class" => "",
                    "value" => "7000",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "autoheight",
                    "heading" => esc_html__("Autoheight", 'trx_utils'),
                    "description" => wp_kses_data( __("Change whole slider's height (make it equal current slide's height)", 'trx_utils') ),
                    "group" => esc_html__('Slider', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'slider',
                        'value' => 'yes'
                    ),
                    "class" => "",
                    "value" => array("Autoheight" => "yes" ),
                    "type" => "checkbox"
                ),
                array(
                    "param_name" => "custom",
                    "heading" => esc_html__("Custom", 'trx_utils'),
                    "description" => wp_kses_data( __("Allow get clients from inner shortcodes (custom) or get it from specified group (cat)", 'trx_utils') ),
                    "class" => "",
                    "value" => array("Custom clients" => "yes" ),
                    "type" => "checkbox"
                ),
                array(
                    "param_name" => "title",
                    "heading" => esc_html__("Title", 'trx_utils'),
                    "description" => wp_kses_data( __("Title for the block", 'trx_utils') ),
                    "admin_label" => true,
                    "group" => esc_html__('Captions', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "subtitle",
                    "heading" => esc_html__("Subtitle", 'trx_utils'),
                    "description" => wp_kses_data( __("Subtitle for the block", 'trx_utils') ),
                    "group" => esc_html__('Captions', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "description",
                    "heading" => esc_html__("Description", 'trx_utils'),
                    "description" => wp_kses_data( __("Description for the block", 'trx_utils') ),
                    "group" => esc_html__('Captions', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "textarea"
                ),
                array(
                    "param_name" => "cat",
                    "heading" => esc_html__("Categories", 'trx_utils'),
                    "description" => wp_kses_data( __("Select category to show clients. If empty - select clients from any category (group) or from IDs list", 'trx_utils') ),
                    "group" => esc_html__('Query', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'custom',
                        'is_empty' => true
                    ),
                    "class" => "",
                    "value" => array_flip(cars4rent_array_merge(array(0 => esc_html__('- Select category -', 'trx_utils')), $clients_groups)),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "columns",
                    "heading" => esc_html__("Columns", 'trx_utils'),
                    "description" => wp_kses_data( __("How many columns use to show clients", 'trx_utils') ),
                    "group" => esc_html__('Query', 'trx_utils'),
                    "admin_label" => true,
                    "class" => "",
                    "value" => "4",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "count",
                    "heading" => esc_html__("Number of posts", 'trx_utils'),
                    "description" => wp_kses_data( __("How many posts will be displayed? If used IDs - this parameter ignored.", 'trx_utils') ),
                    "group" => esc_html__('Query', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'custom',
                        'is_empty' => true
                    ),
                    "class" => "",
                    "value" => "4",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "offset",
                    "heading" => esc_html__("Offset before select posts", 'trx_utils'),
                    "description" => wp_kses_data( __("Skip posts before select next part.", 'trx_utils') ),
                    "group" => esc_html__('Query', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'custom',
                        'is_empty' => true
                    ),
                    "class" => "",
                    "value" => "0",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "orderby",
                    "heading" => esc_html__("Post sorting", 'trx_utils'),
                    "description" => wp_kses_data( __("Select desired posts sorting method", 'trx_utils') ),
                    "group" => esc_html__('Query', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'custom',
                        'is_empty' => true
                    ),
                    "std" => "title",
                    "class" => "",
                    "value" => array_flip(cars4rent_get_sc_param('sorting')),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "order",
                    "heading" => esc_html__("Post order", 'trx_utils'),
                    "description" => wp_kses_data( __("Select desired posts order", 'trx_utils') ),
                    "group" => esc_html__('Query', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'custom',
                        'is_empty' => true
                    ),
                    "std" => "asc",
                    "class" => "",
                    "value" => array_flip(cars4rent_get_sc_param('ordering')),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "ids",
                    "heading" => esc_html__("client's IDs list", 'trx_utils'),
                    "description" => wp_kses_data( __("Comma separated list of client's ID. If set - parameters above (category, count, order, etc.)  are ignored!", 'trx_utils') ),
                    "group" => esc_html__('Query', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'custom',
                        'is_empty' => true
                    ),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "link",
                    "heading" => esc_html__("Button URL", 'trx_utils'),
                    "description" => wp_kses_data( __("Link URL for the button at the bottom of the block", 'trx_utils') ),
                    "group" => esc_html__('Captions', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "link_caption",
                    "heading" => esc_html__("Button caption", 'trx_utils'),
                    "description" => wp_kses_data( __("Caption for the button at the bottom of the block", 'trx_utils') ),
                    "group" => esc_html__('Captions', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                cars4rent_vc_width(),
                cars4rent_vc_height(),
                cars4rent_get_vc_param('margin_top'),
                cars4rent_get_vc_param('margin_bottom'),
                cars4rent_get_vc_param('margin_left'),
                cars4rent_get_vc_param('margin_right'),
                cars4rent_get_vc_param('id'),
                cars4rent_get_vc_param('class'),
                cars4rent_get_vc_param('animation'),
                cars4rent_get_vc_param('css')
            ),
            'js_view' => 'VcTrxColumnsView'
        ) );


        vc_map( array(
            "base" => "trx_clients_item",
            "name" => esc_html__("Client", 'trx_utils'),
            "description" => wp_kses_data( __("Client - all data pull out from it account on your site", 'trx_utils') ),
            "show_settings_on_create" => true,
            "class" => "trx_sc_collection trx_sc_column_item trx_sc_clients_item",
            "content_element" => true,
            "is_container" => true,
            'icon' => 'icon_trx_clients_item',
            "as_child" => array('only' => 'trx_clients'),
            "as_parent" => array('except' => 'trx_clients'),
            "params" => array(
                array(
                    "param_name" => "name",
                    "heading" => esc_html__("Name", 'trx_utils'),
                    "description" => wp_kses_data( __("Client's name", 'trx_utils') ),
                    "admin_label" => true,
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "position",
                    "heading" => esc_html__("Position", 'trx_utils'),
                    "description" => wp_kses_data( __("Client's position", 'trx_utils') ),
                    "admin_label" => true,
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "link",
                    "heading" => esc_html__("Link", 'trx_utils'),
                    "description" => wp_kses_data( __("Link on client's personal page", 'trx_utils') ),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "image",
                    "heading" => esc_html__("Client's image", 'trx_utils'),
                    "description" => wp_kses_data( __("Clients's image", 'trx_utils') ),
                    "class" => "",
                    "value" => "",
                    "type" => "attach_image"
                ),
                cars4rent_get_vc_param('id'),
                cars4rent_get_vc_param('class'),
                cars4rent_get_vc_param('animation'),
                cars4rent_get_vc_param('css')
            ),
            'js_view' => 'VcTrxColumnItemView'
        ) );

        class WPBakeryShortCode_Trx_Clients extends Cars4Rent_Vc_ShortCodeColumns {}
        class WPBakeryShortCode_Trx_Clients_Item extends Cars4Rent_Vc_ShortCodeCollection {}

    }
}

// ---------------------------------- [trx_services] ---------------------------------------

if ( !function_exists( 'cars4rent_sc_services' ) ) {
    function cars4rent_sc_services($atts, $content=null){
        if (cars4rent_in_shortcode_blogger()) return '';
        extract(cars4rent_html_decode(shortcode_atts(array(
            // Individual params
            "style" => "services-1",
            "columns" => 4,
            "slider" => "no",
            "slides_space" => 0,
            "controls" => "no",
            "interval" => "",
            "autoheight" => "no",
            "equalheight" => "no",
            "align" => "",
            "custom" => "no",
            "arrows_between_columns" => "",
            "type" => "icons",	// icons | images
            "ids" => "",
            "cat" => "",
            "count" => 4,
            "offset" => "",
            "orderby" => "date",
            "order" => "desc",
            "readmore" => esc_html__('Learn more', 'trx_utils'),
            "title" => "",
            "subtitle" => "",
            "description" => "",
            "link_caption" => esc_html__('Learn more', 'trx_utils'),
            "link" => '',
            "scheme" => '',
            "image" => '',
            "image_align" => '',
            // Common params
            "id" => "",
            "class" => "",
            "animation" => "",
            "css" => "",
            "width" => "",
            "height" => "",
            "top" => "",
            "bottom" => "",
            "left" => "",
            "right" => ""
        ), $atts)));

        if (cars4rent_param_is_off($slider) && $columns > 1 && $style == 'services-5' && !empty($image)) $columns = 2;
        if (!empty($image)) {
            if ($image > 0) {
                $attach = wp_get_attachment_image_src( $image, 'full' );
                if (isset($attach[0]) && $attach[0]!='')
                    $image = $attach[0];
            }
        }

        if (empty($id)) $id = "sc_services_".str_replace('.', '', mt_rand());
        if (empty($width)) $width = "100%";
        if (!empty($height) && cars4rent_param_is_on($autoheight)) $autoheight = "no";
        if (empty($interval)) $interval = mt_rand(5000, 10000);

        $class .= ($class ? ' ' : '') . cars4rent_get_css_position_as_classes($top, $right, $bottom, $left);

        $ws = cars4rent_get_css_dimensions_from_values($width);
        $hs = cars4rent_get_css_dimensions_from_values('', $height);
        $css .= ($hs) . ($ws);

        $columns = max(1, min(12, (int) $columns));
        $count = max(1, (int) $count);
        if (cars4rent_param_is_off($custom) && $count < $columns) $columns = $count;

        if (cars4rent_param_is_on($slider)) cars4rent_enqueue_slider('swiper');

        cars4rent_storage_set('sc_services_data', array(
                'id' => $id,
                'style' => $style,
                'type' => $type,
                'columns' => $columns,
                'counter' => 0,
                'slider' => $slider,
                'css_wh' => $ws . $hs,
                'readmore' => $readmore
            )
        );

        $output = '<div' . ($id ? ' id="'.esc_attr($id).'_wrap"' : '')
            . ' class="sc_services_wrap'
            . ($scheme && !cars4rent_param_is_off($scheme) && !cars4rent_param_is_inherit($scheme) ? ' scheme_'.esc_attr($scheme) : '')
            .'">'
            . '<div' . ($id ? ' id="'.esc_attr($id).'"' : '')
            . ' class="sc_services'
            . ' sc_services_style_'.esc_attr($style)
            . ' sc_services_type_'.esc_attr($type)
            . ($arrows_between_columns == 'yes' ? ' arrows_between_columns' : '')
            . ' ' . esc_attr(cars4rent_get_template_property($style, 'container_classes'))
            . (!empty($class) ? ' '.esc_attr($class) : '')
            . ($align!='' && $align!='none' ? ' align'.esc_attr($align) : '')
            . '"'
            . ($css!='' ? ' style="'.esc_attr($css).'"' : '')
            . (!cars4rent_param_is_off($equalheight) ? ' data-equal-height=".sc_services_item"' : '')
            . (!cars4rent_param_is_off($animation) ? ' data-animation="'.esc_attr(cars4rent_get_animation_classes($animation)).'"' : '')
            . '>'
            . (!empty($subtitle) ? '<h6 class="sc_services_subtitle sc_item_subtitle">' . trim(cars4rent_strmacros($subtitle)) . '</h6>' : '')
            . (!empty($title) ? '<h2 class="sc_services_title sc_item_title' . (empty($description) ? ' sc_item_title_without_descr' : ' sc_item_title_with_descr') . '">' . trim(cars4rent_strmacros($title)) . '</h2>' : '')
            . (!empty($description) ? '<div class="sc_services_descr sc_item_descr">' . trim(cars4rent_strmacros($description)) . '</div>' : '')
            . (cars4rent_param_is_on($slider)
                ? ('<div class="sc_slider_swiper swiper-slider-container'
                    . ' ' . esc_attr(cars4rent_get_slider_controls_classes($controls))
                    . (cars4rent_param_is_on($autoheight) ? ' sc_slider_height_auto' : '')
                    . ($hs ? ' sc_slider_height_fixed' : '')
                    . '"'
                    . (!empty($width) && cars4rent_strpos($width, '%')===false ? ' data-old-width="' . esc_attr($width) . '"' : '')
                    . (!empty($height) && cars4rent_strpos($height, '%')===false ? ' data-old-height="' . esc_attr($height) . '"' : '')
                    . ((int) $interval > 0 ? ' data-interval="'.esc_attr($interval).'"' : '')
                    . ($columns > 1 ? ' data-slides-per-view="' . esc_attr($columns) . '"' : '')
                    . ($slides_space > 0 ? ' data-slides-space="' . esc_attr($slides_space) . '"' : '')
                    . ' data-slides-min-width="250"'
                    . '>'
                    . '<div class="slides swiper-wrapper">')
                : ($columns > 1
                    ? ($style == 'services-5' && !empty($image)
                        ? '<div class="sc_service_container sc_align_'.esc_attr($image_align).'">'
                        . '<div class="sc_services_image"><img src="'.esc_url($image).'" alt="'.esc_attr__('sc_services_image', 'trx_utils').'"></div>'
                        : '')
                    . '<div class="sc_columns columns_wrap">'
                    : '')
            );

        if (cars4rent_param_is_on($custom) && $content) {
            $output .= do_shortcode($content);
        } else {
            global $post;

            if (!empty($ids)) {
                $posts = explode(',', $ids);
                $count = count($posts);
            }

            $args = array(
                'post_type' => 'services',
                'post_status' => 'publish',
                'posts_per_page' => $count,
                'ignore_sticky_posts' => true,
                'order' => $order=='asc' ? 'asc' : 'desc',
                'readmore' => $readmore
            );

            if ($offset > 0 && empty($ids)) {
                $args['offset'] = $offset;
            }

            $args = cars4rent_query_add_sort_order($args, $orderby, $order);
            $args = cars4rent_query_add_posts_and_cats($args, $ids, 'services', $cat, 'services_group');

            $query = new WP_Query( $args );

            $post_number = 0;

            while ( $query->have_posts() ) {
                $query->the_post();
                $post_number++;
                $args = array(
                    'layout' => $style,
                    'show' => false,
                    'number' => $post_number,
                    'posts_on_page' => ($count > 0 ? $count : $query->found_posts),
                    "descr" => cars4rent_get_custom_option('post_excerpt_maxlength'.($columns > 1 ? '_masonry' : '')),
                    "orderby" => $orderby,
                    'content' => false,
                    'terms_list' => false,
                    'readmore' => $readmore,
                    'tag_type' => $type,
                    'columns_count' => $columns,
                    'slider' => $slider,
                    'tag_id' => $id ? $id . '_' . $post_number : '',
                    'tag_class' => '',
                    'tag_animation' => '',
                    'tag_css' => '',
                    'tag_css_wh' => $ws . $hs
                );
                $output .= cars4rent_show_post_layout($args);
            }
            wp_reset_postdata();
        }

        if (cars4rent_param_is_on($slider)) {
            $output .= '</div>'
                . '<div class="sc_slider_controls_wrap"><a class="sc_slider_prev" href="#"></a><a class="sc_slider_next" href="#"></a></div>'
                . '<div class="sc_slider_pagination_wrap"></div>'
                . '</div>';
        } else if ($columns > 1) {
            $output .= '</div>';
            if ($style == 'services-5' && !empty($image))
                $output .= '</div>';
        }

        $output .=  (!empty($link) ? '<div class="sc_services_button sc_item_button">'.cars4rent_do_shortcode('[trx_button link="'.esc_url($link).'" hover_style="dark"]'.esc_html($link_caption).'[/trx_button]').'</div>' : '')
            . '</div><!-- /.sc_services -->'
            . '</div><!-- /.sc_services_wrap -->';

        // Add template specific scripts and styles
        do_action('cars4rent_action_blog_scripts', $style);

        return apply_filters('cars4rent_shortcode_output', $output, 'trx_services', $atts, $content);
    }
    cars4rent_require_shortcode('trx_services', 'cars4rent_sc_services');
}


if ( !function_exists( 'cars4rent_sc_services_item' ) ) {
    function cars4rent_sc_services_item($atts, $content=null) {
        if (cars4rent_in_shortcode_blogger()) return '';
        extract(cars4rent_html_decode(shortcode_atts( array(
            // Individual params
            "icon" => "",
            "image" => "",
            "title" => "",
            "link" => "",
            "readmore" => "(none)",
            // Common params
            "id" => "",
            "class" => "",
            "animation" => "",
            "css" => ""
        ), $atts)));

        cars4rent_storage_inc_array('sc_services_data', 'counter');

        $id = $id ? $id : (cars4rent_storage_get_array('sc_services_data', 'id') ? cars4rent_storage_get_array('sc_services_data', 'id') . '_' . cars4rent_storage_get_array('sc_services_data', 'counter') : '');

        $descr = trim(chop(do_shortcode($content)));
        $readmore = $readmore=='(none)' ? cars4rent_storage_get_array('sc_services_data', 'readmore') : $readmore;

        $type = cars4rent_storage_get_array('sc_services_data', 'type');
        if (!empty($icon)) {
            $type = 'icons';
        } else if (!empty($image)) {
            $type = 'images';
            if ($image > 0) {
                $attach = wp_get_attachment_image_src( $image, 'full' );
                if (isset($attach[0]) && $attach[0]!='')
                    $image = $attach[0];
            }
            $thumb_sizes = cars4rent_get_thumb_sizes(array('layout' => cars4rent_storage_get_array('sc_services_data', 'style')));
            $image = cars4rent_get_resized_image_tag($image, $thumb_sizes['w'], $thumb_sizes['h']);
        }

        $post_data = array(
            'post_title' => $title,
            'post_excerpt' => $descr,
            'post_thumb' => $image,
            'post_icon' => $icon,
            'post_link' => $link,
            'post_protected' => false,
            'post_format' => 'standard'
        );
        $args = array(
            'layout' => cars4rent_storage_get_array('sc_services_data', 'style'),
            'number' => cars4rent_storage_get_array('sc_services_data', 'counter'),
            'columns_count' => cars4rent_storage_get_array('sc_services_data', 'columns'),
            'slider' => cars4rent_storage_get_array('sc_services_data', 'slider'),
            'show' => false,
            'descr'  => -1,		// -1 - don't strip tags, 0 - strip_tags, >0 - strip_tags and truncate string
            'readmore' => $readmore,
            'tag_type' => $type,
            'tag_id' => $id,
            'tag_class' => $class,
            'tag_animation' => $animation,
            'tag_css' => $css,
            'tag_css_wh' => cars4rent_storage_get_array('sc_services_data', 'css_wh')
        );
        $output = cars4rent_show_post_layout($args, $post_data);
        return apply_filters('cars4rent_shortcode_output', $output, 'trx_services_item', $atts, $content);
    }
    cars4rent_require_shortcode('trx_services_item', 'cars4rent_sc_services_item');
}
// ---------------------------------- [/trx_services] ---------------------------------------



// Add [trx_services] and [trx_services_item] in the shortcodes list
if (!function_exists('cars4rent_services_reg_shortcodes')) {
    function cars4rent_services_reg_shortcodes() {
        if (cars4rent_storage_isset('shortcodes')) {

            $services_groups = cars4rent_get_list_terms(false, 'services_group');
            $services_styles = cars4rent_get_list_templates('services');
            $controls 		 = cars4rent_get_list_slider_controls();

            cars4rent_sc_map_after('trx_section', array(

                // Services
                "trx_services" => array(
                    "title" => esc_html__("Services", 'trx_utils'),
                    "desc" => wp_kses_data( __("Insert services list in your page (post)", 'trx_utils') ),
                    "decorate" => true,
                    "container" => false,
                    "params" => array(
                        "title" => array(
                            "title" => esc_html__("Title", 'trx_utils'),
                            "desc" => wp_kses_data( __("Title for the block", 'trx_utils') ),
                            "value" => "",
                            "type" => "text"
                        ),
                        "subtitle" => array(
                            "title" => esc_html__("Subtitle", 'trx_utils'),
                            "desc" => wp_kses_data( __("Subtitle for the block", 'trx_utils') ),
                            "value" => "",
                            "type" => "text"
                        ),
                        "description" => array(
                            "title" => esc_html__("Description", 'trx_utils'),
                            "desc" => wp_kses_data( __("Short description for the block", 'trx_utils') ),
                            "value" => "",
                            "type" => "textarea"
                        ),
                        "style" => array(
                            "title" => esc_html__("Services style", 'trx_utils'),
                            "desc" => wp_kses_data( __("Select style to display services list", 'trx_utils') ),
                            "value" => "services-1",
                            "type" => "select",
                            "options" => $services_styles
                        ),
                        "image" => array(
                            "title" => esc_html__("Item's image", 'trx_utils'),
                            "desc" => wp_kses_data( __("Item's image", 'trx_utils') ),
                            "dependency" => array(
                                'style' => 'services-5'
                            ),
                            "value" => "",
                            "readonly" => false,
                            "type" => "media"
                        ),
                        "image_align" => array(
                            "title" => esc_html__("Image alignment", 'trx_utils'),
                            "desc" => wp_kses_data( __("Alignment of the image", 'trx_utils') ),
                            "divider" => true,
                            "value" => "",
                            "type" => "checklist",
                            "dir" => "horizontal",
                            "options" => cars4rent_get_sc_param('align')
                        ),
                        "type" => array(
                            "title" => esc_html__("Icon's type", 'trx_utils'),
                            "desc" => wp_kses_data( __("Select type of icons: font icon or image", 'trx_utils') ),
                            "value" => "icons",
                            "type" => "checklist",
                            "dir" => "horizontal",
                            "options" => array(
                                'icons'  => esc_html__('Icons', 'trx_utils'),
                                'images' => esc_html__('Images', 'trx_utils')
                            )
                        ),
                        "columns" => array(
                            "title" => esc_html__("Columns", 'trx_utils'),
                            "desc" => wp_kses_data( __("How many columns use to show services list", 'trx_utils') ),
                            "value" => 4,
                            "min" => 2,
                            "max" => 6,
                            "step" => 1,
                            "type" => "spinner"
                        ),
                        "scheme" => array(
                            "title" => esc_html__("Color scheme", 'trx_utils'),
                            "desc" => wp_kses_data( __("Select color scheme for this block", 'trx_utils') ),
                            "value" => "",
                            "type" => "checklist",
                            "options" => cars4rent_get_sc_param('schemes')
                        ),
                        "slider" => array(
                            "title" => esc_html__("Slider", 'trx_utils'),
                            "desc" => wp_kses_data( __("Use slider to show services", 'trx_utils') ),
                            "value" => "no",
                            "type" => "switch",
                            "options" => cars4rent_get_sc_param('yes_no')
                        ),
                        "controls" => array(
                            "title" => esc_html__("Controls", 'trx_utils'),
                            "desc" => wp_kses_data( __("Slider controls style and position", 'trx_utils') ),
                            "dependency" => array(
                                'slider' => array('yes')
                            ),
                            "divider" => true,
                            "value" => "",
                            "type" => "checklist",
                            "dir" => "horizontal",
                            "options" => $controls
                        ),
                        "slides_space" => array(
                            "title" => esc_html__("Space between slides", 'trx_utils'),
                            "desc" => wp_kses_data( __("Size of space (in px) between slides", 'trx_utils') ),
                            "dependency" => array(
                                'slider' => array('yes')
                            ),
                            "value" => 0,
                            "min" => 0,
                            "max" => 100,
                            "step" => 10,
                            "type" => "spinner"
                        ),
                        "interval" => array(
                            "title" => esc_html__("Slides change interval", 'trx_utils'),
                            "desc" => wp_kses_data( __("Slides change interval (in milliseconds: 1000ms = 1s)", 'trx_utils') ),
                            "dependency" => array(
                                'slider' => array('yes')
                            ),
                            "value" => 7000,
                            "step" => 500,
                            "min" => 0,
                            "type" => "spinner"
                        ),
                        "autoheight" => array(
                            "title" => esc_html__("Autoheight", 'trx_utils'),
                            "desc" => wp_kses_data( __("Change whole slider's height (make it equal current slide's height)", 'trx_utils') ),
                            "dependency" => array(
                                'slider' => array('yes')
                            ),
                            "value" => "yes",
                            "type" => "switch",
                            "options" => cars4rent_get_sc_param('yes_no')
                        ),
                        "align" => array(
                            "title" => esc_html__("Alignment", 'trx_utils'),
                            "desc" => wp_kses_data( __("Alignment of the services block", 'trx_utils') ),
                            "divider" => true,
                            "value" => "",
                            "type" => "checklist",
                            "dir" => "horizontal",
                            "options" => cars4rent_get_sc_param('align')
                        ),
                        "custom" => array(
                            "title" => esc_html__("Custom", 'trx_utils'),
                            "desc" => wp_kses_data( __("Allow get services items from inner shortcodes (custom) or get it from specified group (cat)", 'trx_utils') ),
                            "divider" => true,
                            "value" => "no",
                            "type" => "switch",
                            "options" => cars4rent_get_sc_param('yes_no')
                        ),
                        "cat" => array(
                            "title" => esc_html__("Categories", 'trx_utils'),
                            "desc" => wp_kses_data( __("Select categories (groups) to show services list. If empty - select services from any category (group) or from IDs list", 'trx_utils') ),
                            "dependency" => array(
                                'custom' => array('no')
                            ),
                            "divider" => true,
                            "value" => "",
                            "type" => "select",
                            "style" => "list",
                            "multiple" => true,
                            "options" => cars4rent_array_merge(array(0 => esc_html__('- Select category -', 'trx_utils')), $services_groups)
                        ),
                        "count" => array(
                            "title" => esc_html__("Number of posts", 'trx_utils'),
                            "desc" => wp_kses_data( __("How many posts will be displayed? If used IDs - this parameter ignored.", 'trx_utils') ),
                            "dependency" => array(
                                'custom' => array('no')
                            ),
                            "value" => 4,
                            "min" => 1,
                            "max" => 100,
                            "type" => "spinner"
                        ),
                        "offset" => array(
                            "title" => esc_html__("Offset before select posts", 'trx_utils'),
                            "desc" => wp_kses_data( __("Skip posts before select next part.", 'trx_utils') ),
                            "dependency" => array(
                                'custom' => array('no')
                            ),
                            "value" => 0,
                            "min" => 0,
                            "type" => "spinner"
                        ),
                        "orderby" => array(
                            "title" => esc_html__("Post order by", 'trx_utils'),
                            "desc" => wp_kses_data( __("Select desired posts sorting method", 'trx_utils') ),
                            "dependency" => array(
                                'custom' => array('no')
                            ),
                            "value" => "date",
                            "type" => "select",
                            "options" => cars4rent_get_sc_param('sorting')
                        ),
                        "order" => array(
                            "title" => esc_html__("Post order", 'trx_utils'),
                            "desc" => wp_kses_data( __("Select desired posts order", 'trx_utils') ),
                            "dependency" => array(
                                'custom' => array('no')
                            ),
                            "value" => "desc",
                            "type" => "switch",
                            "size" => "big",
                            "options" => cars4rent_get_sc_param('ordering')
                        ),
                        "ids" => array(
                            "title" => esc_html__("Post IDs list", 'trx_utils'),
                            "desc" => wp_kses_data( __("Comma separated list of posts ID. If set - parameters above are ignored!", 'trx_utils') ),
                            "dependency" => array(
                                'custom' => array('no')
                            ),
                            "value" => "",
                            "type" => "text"
                        ),
                        "readmore" => array(
                            "title" => esc_html__("Read more", 'trx_utils'),
                            "desc" => wp_kses_data( __("Caption for the Read more link (if empty - link not showed)", 'trx_utils') ),
                            "value" => "",
                            "type" => "text"
                        ),
                        "link" => array(
                            "title" => esc_html__("Button URL", 'trx_utils'),
                            "desc" => wp_kses_data( __("Link URL for the button at the bottom of the block", 'trx_utils') ),
                            "value" => "",
                            "type" => "text"
                        ),
                        "link_caption" => array(
                            "title" => esc_html__("Button caption", 'trx_utils'),
                            "desc" => wp_kses_data( __("Caption for the button at the bottom of the block", 'trx_utils') ),
                            "value" => "",
                            "type" => "text"
                        ),
                        "width" => cars4rent_shortcodes_width(),
                        "height" => cars4rent_shortcodes_height(),
                        "top" => cars4rent_get_sc_param('top'),
                        "bottom" => cars4rent_get_sc_param('bottom'),
                        "left" => cars4rent_get_sc_param('left'),
                        "right" => cars4rent_get_sc_param('right'),
                        "id" => cars4rent_get_sc_param('id'),
                        "class" => cars4rent_get_sc_param('class'),
                        "animation" => cars4rent_get_sc_param('animation'),
                        "css" => cars4rent_get_sc_param('css')
                    ),
                    "children" => array(
                        "name" => "trx_services_item",
                        "title" => esc_html__("Service item", 'trx_utils'),
                        "desc" => wp_kses_data( __("Service item", 'trx_utils') ),
                        "container" => true,
                        "params" => array(
                            "title" => array(
                                "title" => esc_html__("Title", 'trx_utils'),
                                "desc" => wp_kses_data( __("Item's title", 'trx_utils') ),
                                "divider" => true,
                                "value" => "",
                                "type" => "text"
                            ),
                            "icon" => array(
                                "title" => esc_html__("Item's icon",  'trx_utils'),
                                "desc" => wp_kses_data( __('Select icon for the item from Fontello icons set',  'trx_utils') ),
                                "value" => "",
                                "type" => "icons",
                                "options" => cars4rent_get_sc_param('icons')
                            ),
                            "image" => array(
                                "title" => esc_html__("Item's image", 'trx_utils'),
                                "desc" => wp_kses_data( __("Item's image (if icon not selected)", 'trx_utils') ),
                                "dependency" => array(
                                    'icon' => array('is_empty', 'none')
                                ),
                                "value" => "",
                                "readonly" => false,
                                "type" => "media"
                            ),
                            "link" => array(
                                "title" => esc_html__("Link", 'trx_utils'),
                                "desc" => wp_kses_data( __("Link on service's item page", 'trx_utils') ),
                                "divider" => true,
                                "value" => "",
                                "type" => "text"
                            ),
                            "readmore" => array(
                                "title" => esc_html__("Read more", 'trx_utils'),
                                "desc" => wp_kses_data( __("Caption for the Read more link (if empty - link not showed)", 'trx_utils') ),
                                "value" => "",
                                "type" => "text"
                            ),
                            "_content_" => array(
                                "title" => esc_html__("Description", 'trx_utils'),
                                "desc" => wp_kses_data( __("Item's short description", 'trx_utils') ),
                                "divider" => true,
                                "rows" => 4,
                                "value" => "",
                                "type" => "textarea"
                            ),
                            "id" => cars4rent_get_sc_param('id'),
                            "class" => cars4rent_get_sc_param('class'),
                            "animation" => cars4rent_get_sc_param('animation'),
                            "css" => cars4rent_get_sc_param('css')
                        )
                    )
                )

            ));
        }
    }
}


// Add [trx_services] and [trx_services_item] in the VC shortcodes list
if (!function_exists('cars4rent_services_reg_shortcodes_vc')) {
    function cars4rent_services_reg_shortcodes_vc() {

        $services_groups = cars4rent_get_list_terms(false, 'services_group');
        $services_styles = cars4rent_get_list_templates('services');
        $controls		 = cars4rent_get_list_slider_controls();

        // Services
        vc_map( array(
            "base" => "trx_services",
            "name" => esc_html__("Services", 'trx_utils'),
            "description" => wp_kses_data( __("Insert services list", 'trx_utils') ),
            "category" => esc_html__('Content', 'trx_utils'),
            "icon" => 'icon_trx_services',
            "class" => "trx_sc_columns trx_sc_services",
            "content_element" => true,
            "is_container" => true,
            "show_settings_on_create" => true,
            "as_parent" => array('only' => 'trx_services_item'),
            "params" => array(
                array(
                    "param_name" => "style",
                    "heading" => esc_html__("Services style", 'trx_utils'),
                    "description" => wp_kses_data( __("Select style to display services list", 'trx_utils') ),
                    "class" => "",
                    "admin_label" => true,
                    "value" => array_flip($services_styles),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "type",
                    "heading" => esc_html__("Icon's type", 'trx_utils'),
                    "description" => wp_kses_data( __("Select type of icons: font icon or image", 'trx_utils') ),
                    "class" => "",
                    "admin_label" => true,
                    "value" => array(
                        esc_html__('Icons', 'trx_utils') => 'icons',
                        esc_html__('Images', 'trx_utils') => 'images'
                    ),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "arrows_between_columns",
                    "heading" => esc_html__("Enable arrows between columns", 'trx_utils'),
                    "description" => wp_kses_data( __("Enable arrows between columns", 'trx_utils') ),
                    "value" => array("Enable arrows between columns" => "yes" ),
                    "type" => "checkbox"
                ),
                array(
                    "param_name" => "equalheight",
                    "heading" => esc_html__("Equal height", 'trx_utils'),
                    "description" => wp_kses_data( __("Make equal height for all items in the row", 'trx_utils') ),
                    "value" => array("Equal height" => "yes" ),
                    "type" => "checkbox"
                ),
                array(
                    "param_name" => "scheme",
                    "heading" => esc_html__("Color scheme", 'trx_utils'),
                    "description" => wp_kses_data( __("Select color scheme for this block", 'trx_utils') ),
                    "class" => "",
                    "value" => array_flip(cars4rent_get_sc_param('schemes')),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "image",
                    "heading" => esc_html__("Image", 'trx_utils'),
                    "description" => wp_kses_data( __("Item's image", 'trx_utils') ),
                    'dependency' => array(
                        'element' => 'style',
                        'value' => 'services-5'
                    ),
                    "class" => "",
                    "value" => "",
                    "type" => "attach_image"
                ),
                array(
                    "param_name" => "image_align",
                    "heading" => esc_html__("Image alignment", 'trx_utils'),
                    "description" => wp_kses_data( __("Alignment of the image", 'trx_utils') ),
                    "class" => "",
                    "value" => array_flip(cars4rent_get_sc_param('align')),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "slider",
                    "heading" => esc_html__("Slider", 'trx_utils'),
                    "description" => wp_kses_data( __("Use slider to show services", 'trx_utils') ),
                    "admin_label" => true,
                    "group" => esc_html__('Slider', 'trx_utils'),
                    "class" => "",
                    "std" => "no",
                    "value" => array_flip(cars4rent_get_sc_param('yes_no')),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "controls",
                    "heading" => esc_html__("Controls", 'trx_utils'),
                    "description" => wp_kses_data( __("Slider controls style and position", 'trx_utils') ),
                    "admin_label" => true,
                    "group" => esc_html__('Slider', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'slider',
                        'value' => 'yes'
                    ),
                    "class" => "",
                    "std" => "no",
                    "value" => array_flip($controls),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "slides_space",
                    "heading" => esc_html__("Space between slides", 'trx_utils'),
                    "description" => wp_kses_data( __("Size of space (in px) between slides", 'trx_utils') ),
                    "admin_label" => true,
                    "group" => esc_html__('Slider', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'slider',
                        'value' => 'yes'
                    ),
                    "class" => "",
                    "value" => "0",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "interval",
                    "heading" => esc_html__("Slides change interval", 'trx_utils'),
                    "description" => wp_kses_data( __("Slides change interval (in milliseconds: 1000ms = 1s)", 'trx_utils') ),
                    "group" => esc_html__('Slider', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'slider',
                        'value' => 'yes'
                    ),
                    "class" => "",
                    "value" => "7000",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "autoheight",
                    "heading" => esc_html__("Autoheight", 'trx_utils'),
                    "description" => wp_kses_data( __("Change whole slider's height (make it equal current slide's height)", 'trx_utils') ),
                    "group" => esc_html__('Slider', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'slider',
                        'value' => 'yes'
                    ),
                    "class" => "",
                    "value" => array("Autoheight" => "yes" ),
                    "type" => "checkbox"
                ),
                array(
                    "param_name" => "align",
                    "heading" => esc_html__("Alignment", 'trx_utils'),
                    "description" => wp_kses_data( __("Alignment of the services block", 'trx_utils') ),
                    "class" => "",
                    "value" => array_flip(cars4rent_get_sc_param('align')),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "custom",
                    "heading" => esc_html__("Custom", 'trx_utils'),
                    "description" => wp_kses_data( __("Allow get services from inner shortcodes (custom) or get it from specified group (cat)", 'trx_utils') ),
                    "class" => "",
                    "value" => array("Custom services" => "yes" ),
                    "type" => "checkbox"
                ),
                array(
                    "param_name" => "title",
                    "heading" => esc_html__("Title", 'trx_utils'),
                    "description" => wp_kses_data( __("Title for the block", 'trx_utils') ),
                    "admin_label" => true,
                    "group" => esc_html__('Captions', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "subtitle",
                    "heading" => esc_html__("Subtitle", 'trx_utils'),
                    "description" => wp_kses_data( __("Subtitle for the block", 'trx_utils') ),
                    "group" => esc_html__('Captions', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "description",
                    "heading" => esc_html__("Description", 'trx_utils'),
                    "description" => wp_kses_data( __("Description for the block", 'trx_utils') ),
                    "group" => esc_html__('Captions', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "textarea"
                ),
                array(
                    "param_name" => "cat",
                    "heading" => esc_html__("Categories", 'trx_utils'),
                    "description" => wp_kses_data( __("Select category to show services. If empty - select services from any category (group) or from IDs list", 'trx_utils') ),
                    "group" => esc_html__('Query', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'custom',
                        'is_empty' => true
                    ),
                    "class" => "",
                    "value" => array_flip(cars4rent_array_merge(array(0 => esc_html__('- Select category -', 'trx_utils')), $services_groups)),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "columns",
                    "heading" => esc_html__("Columns", 'trx_utils'),
                    "description" => wp_kses_data( __("How many columns use to show services list", 'trx_utils') ),
                    "group" => esc_html__('Query', 'trx_utils'),
                    "admin_label" => true,
                    "class" => "",
                    "value" => "4",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "count",
                    "heading" => esc_html__("Number of posts", 'trx_utils'),
                    "description" => wp_kses_data( __("How many posts will be displayed? If used IDs - this parameter ignored.", 'trx_utils') ),
                    "admin_label" => true,
                    "group" => esc_html__('Query', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'custom',
                        'is_empty' => true
                    ),
                    "class" => "",
                    "value" => "4",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "offset",
                    "heading" => esc_html__("Offset before select posts", 'trx_utils'),
                    "description" => wp_kses_data( __("Skip posts before select next part.", 'trx_utils') ),
                    "group" => esc_html__('Query', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'custom',
                        'is_empty' => true
                    ),
                    "class" => "",
                    "value" => "0",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "orderby",
                    "heading" => esc_html__("Post sorting", 'trx_utils'),
                    "description" => wp_kses_data( __("Select desired posts sorting method", 'trx_utils') ),
                    "group" => esc_html__('Query', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'custom',
                        'is_empty' => true
                    ),
                    "std" => "date",
                    "class" => "",
                    "value" => array_flip(cars4rent_get_sc_param('sorting')),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "order",
                    "heading" => esc_html__("Post order", 'trx_utils'),
                    "description" => wp_kses_data( __("Select desired posts order", 'trx_utils') ),
                    "group" => esc_html__('Query', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'custom',
                        'is_empty' => true
                    ),
                    "std" => "desc",
                    "class" => "",
                    "value" => array_flip(cars4rent_get_sc_param('ordering')),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "ids",
                    "heading" => esc_html__("Service's IDs list", 'trx_utils'),
                    "description" => wp_kses_data( __("Comma separated list of service's ID. If set - parameters above (category, count, order, etc.)  are ignored!", 'trx_utils') ),
                    "group" => esc_html__('Query', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'custom',
                        'is_empty' => true
                    ),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "readmore",
                    "heading" => esc_html__("Read more", 'trx_utils'),
                    "description" => wp_kses_data( __("Caption for the Read more link (if empty - link not showed)", 'trx_utils') ),
                    "admin_label" => true,
                    "group" => esc_html__('Captions', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "link",
                    "heading" => esc_html__("Button URL", 'trx_utils'),
                    "description" => wp_kses_data( __("Link URL for the button at the bottom of the block", 'trx_utils') ),
                    "group" => esc_html__('Captions', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "link_caption",
                    "heading" => esc_html__("Button caption", 'trx_utils'),
                    "description" => wp_kses_data( __("Caption for the button at the bottom of the block", 'trx_utils') ),
                    "group" => esc_html__('Captions', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                cars4rent_vc_width(),
                cars4rent_vc_height(),
                cars4rent_get_vc_param('margin_top'),
                cars4rent_get_vc_param('margin_bottom'),
                cars4rent_get_vc_param('margin_left'),
                cars4rent_get_vc_param('margin_right'),
                cars4rent_get_vc_param('id'),
                cars4rent_get_vc_param('class'),
                cars4rent_get_vc_param('animation'),
                cars4rent_get_vc_param('css')
            ),
            'default_content' => '
					[trx_services_item title="' . esc_html__( 'Service item 1', 'trx_utils' ) . '"][/trx_services_item]
					[trx_services_item title="' . esc_html__( 'Service item 2', 'trx_utils' ) . '"][/trx_services_item]
					[trx_services_item title="' . esc_html__( 'Service item 3', 'trx_utils' ) . '"][/trx_services_item]
					[trx_services_item title="' . esc_html__( 'Service item 4', 'trx_utils' ) . '"][/trx_services_item]
				',
            'js_view' => 'VcTrxColumnsView'
        ) );


        vc_map( array(
            "base" => "trx_services_item",
            "name" => esc_html__("Services item", 'trx_utils'),
            "description" => wp_kses_data( __("Custom services item - all data pull out from shortcode parameters", 'trx_utils') ),
            "show_settings_on_create" => true,
            "class" => "trx_sc_collection trx_sc_column_item trx_sc_services_item",
            "content_element" => true,
            "is_container" => true,
            'icon' => 'icon_trx_services_item',
            "as_child" => array('only' => 'trx_services'),
            "as_parent" => array('except' => 'trx_services'),
            "params" => array(
                array(
                    "param_name" => "title",
                    "heading" => esc_html__("Title", 'trx_utils'),
                    "description" => wp_kses_data( __("Item's title", 'trx_utils') ),
                    "admin_label" => true,
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "icon",
                    "heading" => esc_html__("Icon", 'trx_utils'),
                    "description" => wp_kses_data( __("Select icon for the item from Fontello icons set", 'trx_utils') ),
                    "admin_label" => true,
                    "class" => "",
                    "value" => cars4rent_get_sc_param('icons'),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "image",
                    "heading" => esc_html__("Image", 'trx_utils'),
                    "description" => wp_kses_data( __("Item's image (if icon is empty)", 'trx_utils') ),
                    "class" => "",
                    "value" => "",
                    "type" => "attach_image"
                ),
                array(
                    "param_name" => "link",
                    "heading" => esc_html__("Link", 'trx_utils'),
                    "description" => wp_kses_data( __("Link on item's page", 'trx_utils') ),
                    "admin_label" => true,
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "readmore",
                    "heading" => esc_html__("Read more", 'trx_utils'),
                    "description" => wp_kses_data( __("Caption for the Read more link (if empty - link not showed)", 'trx_utils') ),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                cars4rent_get_vc_param('id'),
                cars4rent_get_vc_param('class'),
                cars4rent_get_vc_param('animation'),
                cars4rent_get_vc_param('css')
            ),
            'js_view' => 'VcTrxColumnItemView'
        ) );

        class WPBakeryShortCode_Trx_Services extends Cars4Rent_Vc_ShortCodeColumns {}
        class WPBakeryShortCode_Trx_Services_Item extends Cars4Rent_Vc_ShortCodeCollection {}

    }
}

if (!function_exists('cars4rent_sc_testimonials')) {
    function cars4rent_sc_testimonials($atts, $content=null){
        if (cars4rent_in_shortcode_blogger()) return '';
        extract(cars4rent_html_decode(shortcode_atts(array(
            // Individual params
            "style" => "testimonials-1",
            "columns" => 1,
            "slider" => "yes",
            "slides_space" => 0,
            "controls" => "no",
            "interval" => "",
            "autoheight" => "no",
            "align" => "",
            "custom" => "no",
            "ids" => "",
            "cat" => "",
            "count" => "3",
            "offset" => "",
            "orderby" => "date",
            "order" => "desc",
            "scheme" => "",
            "bg_color" => "",
            "bg_image" => "",
            "bg_overlay" => "",
            "bg_texture" => "",
            "title" => "",
            "subtitle" => "",
            "description" => "",
            // Common params
            "id" => "",
            "class" => "",
            "animation" => "",
            "css" => "",
            "width" => "",
            "height" => "",
            "top" => "",
            "bottom" => "",
            "left" => "",
            "right" => ""
        ), $atts)));

        if (empty($id)) $id = "sc_testimonials_".str_replace('.', '', mt_rand());
        if (empty($width)) $width = "100%";
        if (!empty($height) && cars4rent_param_is_on($autoheight)) $autoheight = "no";
        if (empty($interval)) $interval = mt_rand(5000, 10000);

        if ($bg_image > 0) {
            $attach = wp_get_attachment_image_src( $bg_image, 'full' );
            if (isset($attach[0]) && $attach[0]!='')
                $bg_image = $attach[0];
        }

        if ($bg_overlay > 0) {
            if ($bg_color=='') $bg_color = cars4rent_get_scheme_color('bg');
            $rgb = cars4rent_hex2rgb($bg_color);
        }

        $class .= ($class ? ' ' : '') . cars4rent_get_css_position_as_classes($top, $right, $bottom, $left);

        $ws = cars4rent_get_css_dimensions_from_values($width);
        $hs = cars4rent_get_css_dimensions_from_values('', $height);
        $css .= ($hs) . ($ws);

        $count = max(1, (int) $count);
        $columns = max(1, min(12, (int) $columns));
        if (cars4rent_param_is_off($custom) && $count < $columns) $columns = $count;

        cars4rent_storage_set('sc_testimonials_data', array(
                'id' => $id,
                'style' => $style,
                'columns' => $columns,
                'counter' => 0,
                'slider' => $slider,
                'css_wh' => $ws . $hs
            )
        );

        if (cars4rent_param_is_on($slider)) cars4rent_enqueue_slider('swiper');

        $output = ($bg_color!='' || $bg_image!='' || $bg_overlay>0 || $bg_texture>0 || cars4rent_strlen($bg_texture)>2 || ($scheme && !cars4rent_param_is_off($scheme) && !cars4rent_param_is_inherit($scheme))
                ? '<div class="sc_testimonials_wrap sc_section'
                . ($scheme && !cars4rent_param_is_off($scheme) && !cars4rent_param_is_inherit($scheme) ? ' scheme_'.esc_attr($scheme) : '')
                . '"'
                .' style="'
                . ($bg_color !== '' && $bg_overlay==0 ? 'background-color:' . esc_attr($bg_color) . ';' : '')
                . ($bg_image !== '' ? 'background-image:url(' . esc_url($bg_image) . ');' : '')
                . '"'
                . (!cars4rent_param_is_off($animation) ? ' data-animation="'.esc_attr(cars4rent_get_animation_classes($animation)).'"' : '')
                . '>'
                . '<div class="sc_section_overlay'.($bg_texture>0 ? ' texture_bg_'.esc_attr($bg_texture) : '') . '"'
                . ' style="' . ($bg_overlay>0 ? 'background-color:rgba('.(int)$rgb['r'].','.(int)$rgb['g'].','.(int)$rgb['b'].','.min(1, max(0, $bg_overlay)).');' : '')
                . (cars4rent_strlen($bg_texture)>2 ? 'background-image:url('.esc_url($bg_texture).');' : '')
                . '"'
                . ($bg_overlay > 0 ? ' data-overlay="'.esc_attr($bg_overlay).'" data-bg_color="'.esc_attr($bg_color).'"' : '')
                . '>'
                : '')
            . '<div' . ($id ? ' id="'.esc_attr($id).'"' : '')
            . ' class="sc_testimonials sc_testimonials_style_'.esc_attr($style)
            . ' ' . esc_attr(cars4rent_get_template_property($style, 'container_classes'))
            . (!empty($class) ? ' '.esc_attr($class) : '')
            . ($align!='' && $align!='none' ? ' align'.esc_attr($align) : '')
            . '"'
            . ($bg_color=='' && $bg_image=='' && $bg_overlay==0 && ($bg_texture=='' || $bg_texture=='0') && !cars4rent_param_is_off($animation) ? ' data-animation="'.esc_attr(cars4rent_get_animation_classes($animation)).'"' : '')
            . ($css!='' ? ' style="'.esc_attr($css).'"' : '')
            . '>'
            . (!empty($subtitle) ? '<h6 class="sc_testimonials_subtitle sc_item_subtitle">' . trim(cars4rent_strmacros($subtitle)) . '</h6>' : '')
            . (!empty($title) ? '<h2 class="sc_testimonials_title sc_item_title' . (empty($description) ? ' sc_item_title_without_descr' : ' sc_item_title_with_descr') . '">' . trim(cars4rent_strmacros($title)) . '</h2>' : '')
            . (!empty($description) ? '<div class="sc_testimonials_descr sc_item_descr">' . trim(cars4rent_strmacros($description)) . '</div>' : '')
            . (cars4rent_param_is_on($slider)
                ? ('<div class="sc_slider_swiper swiper-slider-container'
                    . ' ' . esc_attr(cars4rent_get_slider_controls_classes($controls))
                    . (cars4rent_param_is_on($autoheight) ? ' sc_slider_height_auto' : '')
                    . ($hs ? ' sc_slider_height_fixed' : '')
                    . '"'
                    . (!empty($width) && cars4rent_strpos($width, '%')===false ? ' data-old-width="' . esc_attr($width) . '"' : '')
                    . (!empty($height) && cars4rent_strpos($height, '%')===false ? ' data-old-height="' . esc_attr($height) . '"' : '')
                    . ((int) $interval > 0 ? ' data-interval="'.esc_attr($interval).'"' : '')
                    . ($columns > 1 ? ' data-slides-per-view="' . esc_attr($columns) . '"' : '')
                    . ($slides_space > 0 ? ' data-slides-space="' . esc_attr($slides_space) . '"' : '')
                    . ' data-slides-min-width="250"'
                    . '>'
                    . '<div class="slides swiper-wrapper">')
                : ($columns > 1
                    ? '<div class="sc_columns columns_wrap">'
                    : '')
            );

        if (cars4rent_param_is_on($custom) && $content) {
            $output .= do_shortcode($content);
        } else {
            global $post;

            if (!empty($ids)) {
                $posts = explode(',', $ids);
                $count = count($posts);
            }

            $args = array(
                'post_type' => 'testimonial',
                'post_status' => 'publish',
                'posts_per_page' => $count,
                'ignore_sticky_posts' => true,
                'order' => $order=='asc' ? 'asc' : 'desc',
            );

            if ($offset > 0 && empty($ids)) {
                $args['offset'] = $offset;
            }

            $args = cars4rent_query_add_sort_order($args, $orderby, $order);
            $args = cars4rent_query_add_posts_and_cats($args, $ids, 'testimonial', $cat, 'testimonial_group');

            $query = new WP_Query( $args );

            $post_number = 0;

            while ( $query->have_posts() ) {
                $query->the_post();
                $post_number++;
                $args = array(
                    'layout' => $style,
                    'show' => false,
                    'number' => $post_number,
                    'posts_on_page' => ($count > 0 ? $count : $query->found_posts),
                    "descr" => cars4rent_get_custom_option('post_excerpt_maxlength'.($columns > 1 ? '_masonry' : '')),
                    "orderby" => $orderby,
                    'content' => false,
                    'terms_list' => false,
                    'columns_count' => $columns,
                    'slider' => $slider,
                    'tag_id' => $id ? $id . '_' . $post_number : '',
                    'tag_class' => '',
                    'tag_animation' => '',
                    'tag_css' => '',
                    'tag_css_wh' => $ws . $hs
                );
                $post_data = cars4rent_get_post_data($args);
                $post_data['post_content'] = wpautop($post_data['post_content']);	// Add <p> around text and paragraphs. Need separate call because 'content'=>false (see above)
                $post_meta = get_post_meta($post_data['post_id'], cars4rent_storage_get('options_prefix').'_testimonial_data', true);
                $thumb_sizes = cars4rent_get_thumb_sizes(array('layout' => $style));
                $args['author'] = $post_meta['testimonial_author'];
                $args['position'] = $post_meta['testimonial_position'];
                $args['link'] = !empty($post_meta['testimonial_link']) ? $post_meta['testimonial_link'] : '';
                $args['email'] = $post_meta['testimonial_email'];
                $args['photo'] = $post_data['post_thumb'];
                $mult = cars4rent_get_retina_multiplier();
                if (empty($args['photo']) && !empty($args['email'])) $args['photo'] = get_avatar($args['email'], $thumb_sizes['w']*$mult);
                $output .= cars4rent_show_post_layout($args, $post_data);
            }
            wp_reset_postdata();
        }

        if (cars4rent_param_is_on($slider)) {
            $output .= '</div>'
                . '<div class="sc_slider_controls_wrap"><a class="sc_slider_prev" href="#"></a><a class="sc_slider_next" href="#"></a></div>'
                . '<div class="sc_slider_pagination_wrap"></div>'
                . '</div>';
        } else if ($columns > 1) {
            $output .= '</div>';
        }

        $output .= '</div>'
            . ($bg_color!='' || $bg_image!='' || $bg_overlay>0 || $bg_texture>0 || cars4rent_strlen($bg_texture)>2 || ($scheme && !cars4rent_param_is_off($scheme) && !cars4rent_param_is_inherit($scheme))
                ?  '</div></div>'
                : '');

        // Add template specific scripts and styles
        do_action('cars4rent_action_blog_scripts', $style);

        return apply_filters('cars4rent_shortcode_output', $output, 'trx_testimonials', $atts, $content);
    }
    cars4rent_require_shortcode('trx_testimonials', 'cars4rent_sc_testimonials');
}


if (!function_exists('cars4rent_sc_testimonials_item')) {
    function cars4rent_sc_testimonials_item($atts, $content=null){
        if (cars4rent_in_shortcode_blogger()) return '';
        extract(cars4rent_html_decode(shortcode_atts(array(
            // Individual params
            "author" => "",
            "position" => "",
            "link" => "",
            "photo" => "",
            "email" => "",
            // Common params
            "id" => "",
            "class" => "",
            "css" => "",
        ), $atts)));

        cars4rent_storage_inc_array('sc_testimonials_data', 'counter');

        $id = $id ? $id : (cars4rent_storage_get_array('sc_testimonials_data', 'id') ? cars4rent_storage_get_array('sc_testimonials_data', 'id') . '_' . cars4rent_storage_get_array('sc_testimonials_data', 'counter') : '');

        $thumb_sizes = cars4rent_get_thumb_sizes(array('layout' => cars4rent_storage_get_array('sc_testimonials_data', 'style')));

        if (empty($photo)) {
            if (!empty($email))
                $mult = cars4rent_get_retina_multiplier();
            $photo = get_avatar($email, $thumb_sizes['w']*$mult);
        } else {
            if ($photo > 0) {
                $attach = wp_get_attachment_image_src( $photo, 'full' );
                if (isset($attach[0]) && $attach[0]!='')
                    $photo = $attach[0];
            }
            $photo = cars4rent_get_resized_image_tag($photo, $thumb_sizes['w'], $thumb_sizes['h']);
        }

        $post_data = array(
            'post_content' => do_shortcode($content)
        );
        $args = array(
            'layout' => cars4rent_storage_get_array('sc_testimonials_data', 'style'),
            'number' => cars4rent_storage_get_array('sc_testimonials_data', 'counter'),
            'columns_count' => cars4rent_storage_get_array('sc_testimonials_data', 'columns'),
            'slider' => cars4rent_storage_get_array('sc_testimonials_data', 'slider'),
            'show' => false,
            'descr'  => 0,
            'tag_id' => $id,
            'tag_class' => $class,
            'tag_animation' => '',
            'tag_css' => $css,
            'tag_css_wh' => cars4rent_storage_get_array('sc_testimonials_data', 'css_wh'),
            'author' => $author,
            'position' => $position,
            'link' => $link,
            'email' => $email,
            'photo' => $photo
        );
        $output = cars4rent_show_post_layout($args, $post_data);

        return apply_filters('cars4rent_shortcode_output', $output, 'trx_testimonials_item', $atts, $content);
    }
    cars4rent_require_shortcode('trx_testimonials_item', 'cars4rent_sc_testimonials_item');
}
// ---------------------------------- [/trx_testimonials] ---------------------------------------



// Add [trx_testimonials] and [trx_testimonials_item] in the shortcodes list
if (!function_exists('cars4rent_testimonials_reg_shortcodes')) {
    function cars4rent_testimonials_reg_shortcodes() {
        if (cars4rent_storage_isset('shortcodes')) {

            $testimonials_groups = cars4rent_get_list_terms(false, 'testimonial_group');
            $testimonials_styles = cars4rent_get_list_templates('testimonials');
            $controls = cars4rent_get_list_slider_controls();

            cars4rent_sc_map_before('trx_title', array(

                // Testimonials
                "trx_testimonials" => array(
                    "title" => esc_html__("Testimonials", 'trx_utils'),
                    "desc" => wp_kses_data( __("Insert testimonials into post (page)", 'trx_utils') ),
                    "decorate" => true,
                    "container" => false,
                    "params" => array(
                        "title" => array(
                            "title" => esc_html__("Title", 'trx_utils'),
                            "desc" => wp_kses_data( __("Title for the block", 'trx_utils') ),
                            "value" => "",
                            "type" => "text"
                        ),
                        "subtitle" => array(
                            "title" => esc_html__("Subtitle", 'trx_utils'),
                            "desc" => wp_kses_data( __("Subtitle for the block", 'trx_utils') ),
                            "value" => "",
                            "type" => "text"
                        ),
                        "description" => array(
                            "title" => esc_html__("Description", 'trx_utils'),
                            "desc" => wp_kses_data( __("Short description for the block", 'trx_utils') ),
                            "value" => "",
                            "type" => "textarea"
                        ),
                        "style" => array(
                            "title" => esc_html__("Testimonials style", 'trx_utils'),
                            "desc" => wp_kses_data( __("Select style to display testimonials", 'trx_utils') ),
                            "value" => "testimonials-1",
                            "type" => "select",
                            "options" => $testimonials_styles
                        ),
                        "columns" => array(
                            "title" => esc_html__("Columns", 'trx_utils'),
                            "desc" => wp_kses_data( __("How many columns use to show testimonials", 'trx_utils') ),
                            "value" => 1,
                            "min" => 1,
                            "max" => 6,
                            "step" => 1,
                            "type" => "spinner"
                        ),
                        "slider" => array(
                            "title" => esc_html__("Slider", 'trx_utils'),
                            "desc" => wp_kses_data( __("Use slider to show testimonials", 'trx_utils') ),
                            "value" => "yes",
                            "type" => "switch",
                            "options" => cars4rent_get_sc_param('yes_no')
                        ),
                        "controls" => array(
                            "title" => esc_html__("Controls", 'trx_utils'),
                            "desc" => wp_kses_data( __("Slider controls style and position", 'trx_utils') ),
                            "dependency" => array(
                                'slider' => array('yes')
                            ),
                            "divider" => true,
                            "value" => "",
                            "type" => "checklist",
                            "dir" => "horizontal",
                            "options" => $controls
                        ),
                        "slides_space" => array(
                            "title" => esc_html__("Space between slides", 'trx_utils'),
                            "desc" => wp_kses_data( __("Size of space (in px) between slides", 'trx_utils') ),
                            "dependency" => array(
                                'slider' => array('yes')
                            ),
                            "value" => 0,
                            "min" => 0,
                            "max" => 100,
                            "step" => 10,
                            "type" => "spinner"
                        ),
                        "interval" => array(
                            "title" => esc_html__("Slides change interval", 'trx_utils'),
                            "desc" => wp_kses_data( __("Slides change interval (in milliseconds: 1000ms = 1s)", 'trx_utils') ),
                            "dependency" => array(
                                'slider' => array('yes')
                            ),
                            "value" => 7000,
                            "step" => 500,
                            "min" => 0,
                            "type" => "spinner"
                        ),
                        "autoheight" => array(
                            "title" => esc_html__("Autoheight", 'trx_utils'),
                            "desc" => wp_kses_data( __("Change whole slider's height (make it equal current slide's height)", 'trx_utils') ),
                            "dependency" => array(
                                'slider' => array('yes')
                            ),
                            "value" => "yes",
                            "type" => "switch",
                            "options" => cars4rent_get_sc_param('yes_no')
                        ),
                        "align" => array(
                            "title" => esc_html__("Alignment", 'trx_utils'),
                            "desc" => wp_kses_data( __("Alignment of the testimonials block", 'trx_utils') ),
                            "divider" => true,
                            "value" => "",
                            "type" => "checklist",
                            "dir" => "horizontal",
                            "options" => cars4rent_get_sc_param('align')
                        ),
                        "custom" => array(
                            "title" => esc_html__("Custom", 'trx_utils'),
                            "desc" => wp_kses_data( __("Allow get testimonials from inner shortcodes (custom) or get it from specified group (cat)", 'trx_utils') ),
                            "divider" => true,
                            "value" => "no",
                            "type" => "switch",
                            "options" => cars4rent_get_sc_param('yes_no')
                        ),
                        "cat" => array(
                            "title" => esc_html__("Categories", 'trx_utils'),
                            "desc" => wp_kses_data( __("Select categories (groups) to show testimonials. If empty - select testimonials from any category (group) or from IDs list", 'trx_utils') ),
                            "dependency" => array(
                                'custom' => array('no')
                            ),
                            "divider" => true,
                            "value" => "",
                            "type" => "select",
                            "style" => "list",
                            "multiple" => true,
                            "options" => cars4rent_array_merge(array(0 => esc_html__('- Select category -', 'trx_utils')), $testimonials_groups)
                        ),
                        "count" => array(
                            "title" => esc_html__("Number of posts", 'trx_utils'),
                            "desc" => wp_kses_data( __("How many posts will be displayed? If used IDs - this parameter ignored.", 'trx_utils') ),
                            "dependency" => array(
                                'custom' => array('no')
                            ),
                            "value" => 3,
                            "min" => 1,
                            "max" => 100,
                            "type" => "spinner"
                        ),
                        "offset" => array(
                            "title" => esc_html__("Offset before select posts", 'trx_utils'),
                            "desc" => wp_kses_data( __("Skip posts before select next part.", 'trx_utils') ),
                            "dependency" => array(
                                'custom' => array('no')
                            ),
                            "value" => 0,
                            "min" => 0,
                            "type" => "spinner"
                        ),
                        "orderby" => array(
                            "title" => esc_html__("Post order by", 'trx_utils'),
                            "desc" => wp_kses_data( __("Select desired posts sorting method", 'trx_utils') ),
                            "dependency" => array(
                                'custom' => array('no')
                            ),
                            "value" => "date",
                            "type" => "select",
                            "options" => cars4rent_get_sc_param('sorting')
                        ),
                        "order" => array(
                            "title" => esc_html__("Post order", 'trx_utils'),
                            "desc" => wp_kses_data( __("Select desired posts order", 'trx_utils') ),
                            "dependency" => array(
                                'custom' => array('no')
                            ),
                            "value" => "desc",
                            "type" => "switch",
                            "size" => "big",
                            "options" => cars4rent_get_sc_param('ordering')
                        ),
                        "ids" => array(
                            "title" => esc_html__("Post IDs list", 'trx_utils'),
                            "desc" => wp_kses_data( __("Comma separated list of posts ID. If set - parameters above are ignored!", 'trx_utils') ),
                            "dependency" => array(
                                'custom' => array('no')
                            ),
                            "value" => "",
                            "type" => "text"
                        ),
                        "scheme" => array(
                            "title" => esc_html__("Color scheme", 'trx_utils'),
                            "desc" => wp_kses_data( __("Select color scheme for this block", 'trx_utils') ),
                            "value" => "",
                            "type" => "checklist",
                            "options" => cars4rent_get_sc_param('schemes')
                        ),
                        "bg_color" => array(
                            "title" => esc_html__("Background color", 'trx_utils'),
                            "desc" => wp_kses_data( __("Any background color for this section", 'trx_utils') ),
                            "value" => "",
                            "type" => "color"
                        ),
                        "bg_image" => array(
                            "title" => esc_html__("Background image URL", 'trx_utils'),
                            "desc" => wp_kses_data( __("Select or upload image or write URL from other site for the background", 'trx_utils') ),
                            "readonly" => false,
                            "value" => "",
                            "type" => "media"
                        ),
                        "bg_overlay" => array(
                            "title" => esc_html__("Overlay", 'trx_utils'),
                            "desc" => wp_kses_data( __("Overlay color opacity (from 0.0 to 1.0)", 'trx_utils') ),
                            "min" => "0",
                            "max" => "1",
                            "step" => "0.1",
                            "value" => "0",
                            "type" => "spinner"
                        ),
                        "bg_texture" => array(
                            "title" => esc_html__("Texture", 'trx_utils'),
                            "desc" => wp_kses_data( __("Predefined texture style from 1 to 11. 0 - without texture.", 'trx_utils') ),
                            "min" => "0",
                            "max" => "11",
                            "step" => "1",
                            "value" => "0",
                            "type" => "spinner"
                        ),
                        "width" => cars4rent_shortcodes_width(),
                        "height" => cars4rent_shortcodes_height(),
                        "top" => cars4rent_get_sc_param('top'),
                        "bottom" => cars4rent_get_sc_param('bottom'),
                        "left" => cars4rent_get_sc_param('left'),
                        "right" => cars4rent_get_sc_param('right'),
                        "id" => cars4rent_get_sc_param('id'),
                        "class" => cars4rent_get_sc_param('class'),
                        "animation" => cars4rent_get_sc_param('animation'),
                        "css" => cars4rent_get_sc_param('css')
                    ),
                    "children" => array(
                        "name" => "trx_testimonials_item",
                        "title" => esc_html__("Item", 'trx_utils'),
                        "desc" => wp_kses_data( __("Testimonials item (custom parameters)", 'trx_utils') ),
                        "container" => true,
                        "params" => array(
                            "author" => array(
                                "title" => esc_html__("Author", 'trx_utils'),
                                "desc" => wp_kses_data( __("Name of the testimonmials author", 'trx_utils') ),
                                "value" => "",
                                "type" => "text"
                            ),
                            "link" => array(
                                "title" => esc_html__("Link", 'trx_utils'),
                                "desc" => wp_kses_data( __("Link URL to the testimonmials author page", 'trx_utils') ),
                                "value" => "",
                                "type" => "text"
                            ),
                            "email" => array(
                                "title" => esc_html__("E-mail", 'trx_utils'),
                                "desc" => wp_kses_data( __("E-mail of the testimonmials author (to get gravatar)", 'trx_utils') ),
                                "value" => "",
                                "type" => "text"
                            ),
                            "photo" => array(
                                "title" => esc_html__("Photo", 'trx_utils'),
                                "desc" => wp_kses_data( __("Select or upload photo of testimonmials author or write URL of photo from other site", 'trx_utils') ),
                                "value" => "",
                                "type" => "media"
                            ),
                            "_content_" => array(
                                "title" => esc_html__("Testimonials text", 'trx_utils'),
                                "desc" => wp_kses_data( __("Current testimonials text", 'trx_utils') ),
                                "divider" => true,
                                "rows" => 4,
                                "value" => "",
                                "type" => "textarea"
                            ),
                            "id" => cars4rent_get_sc_param('id'),
                            "class" => cars4rent_get_sc_param('class'),
                            "css" => cars4rent_get_sc_param('css')
                        )
                    )
                )

            ));
        }
    }
}


// Add [trx_testimonials] and [trx_testimonials_item] in the VC shortcodes list
if (!function_exists('cars4rent_testimonials_reg_shortcodes_vc')) {
    function cars4rent_testimonials_reg_shortcodes_vc() {

        $testimonials_groups = cars4rent_get_list_terms(false, 'testimonial_group');
        $testimonials_styles = cars4rent_get_list_templates('testimonials');
        $controls			 = cars4rent_get_list_slider_controls();

        // Testimonials
        vc_map( array(
            "base" => "trx_testimonials",
            "name" => esc_html__("Testimonials", 'trx_utils'),
            "description" => wp_kses_data( __("Insert testimonials slider", 'trx_utils') ),
            "category" => esc_html__('Content', 'trx_utils'),
            'icon' => 'icon_trx_testimonials',
            "class" => "trx_sc_columns trx_sc_testimonials",
            "content_element" => true,
            "is_container" => true,
            "show_settings_on_create" => true,
            "as_parent" => array('only' => 'trx_testimonials_item'),
            "params" => array(
                array(
                    "param_name" => "style",
                    "heading" => esc_html__("Testimonials style", 'trx_utils'),
                    "description" => wp_kses_data( __("Select style to display testimonials", 'trx_utils') ),
                    "class" => "",
                    "admin_label" => true,
                    "value" => array_flip($testimonials_styles),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "slider",
                    "heading" => esc_html__("Slider", 'trx_utils'),
                    "description" => wp_kses_data( __("Use slider to show testimonials", 'trx_utils') ),
                    "admin_label" => true,
                    "group" => esc_html__('Slider', 'trx_utils'),
                    "class" => "",
                    "std" => "yes",
                    "value" => array_flip(cars4rent_get_sc_param('yes_no')),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "controls",
                    "heading" => esc_html__("Controls", 'trx_utils'),
                    "description" => wp_kses_data( __("Slider controls style and position", 'trx_utils') ),
                    "admin_label" => true,
                    "group" => esc_html__('Slider', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'slider',
                        'value' => 'yes'
                    ),
                    "class" => "",
                    "std" => "no",
                    "value" => array_flip($controls),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "slides_space",
                    "heading" => esc_html__("Space between slides", 'trx_utils'),
                    "description" => wp_kses_data( __("Size of space (in px) between slides", 'trx_utils') ),
                    "admin_label" => true,
                    "group" => esc_html__('Slider', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'slider',
                        'value' => 'yes'
                    ),
                    "class" => "",
                    "value" => "0",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "interval",
                    "heading" => esc_html__("Slides change interval", 'trx_utils'),
                    "description" => wp_kses_data( __("Slides change interval (in milliseconds: 1000ms = 1s)", 'trx_utils') ),
                    "group" => esc_html__('Slider', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'slider',
                        'value' => 'yes'
                    ),
                    "class" => "",
                    "value" => "7000",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "autoheight",
                    "heading" => esc_html__("Autoheight", 'trx_utils'),
                    "description" => wp_kses_data( __("Change whole slider's height (make it equal current slide's height)", 'trx_utils') ),
                    "group" => esc_html__('Slider', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'slider',
                        'value' => 'yes'
                    ),
                    "class" => "",
                    "value" => array("Autoheight" => "yes" ),
                    "type" => "checkbox"
                ),
                array(
                    "param_name" => "align",
                    "heading" => esc_html__("Alignment", 'trx_utils'),
                    "description" => wp_kses_data( __("Alignment of the testimonials block", 'trx_utils') ),
                    "class" => "",
                    "value" => array_flip(cars4rent_get_sc_param('align')),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "custom",
                    "heading" => esc_html__("Custom", 'trx_utils'),
                    "description" => wp_kses_data( __("Allow get testimonials from inner shortcodes (custom) or get it from specified group (cat)", 'trx_utils') ),
                    "class" => "",
                    "value" => array("Custom slides" => "yes" ),
                    "type" => "checkbox"
                ),
                array(
                    "param_name" => "title",
                    "heading" => esc_html__("Title", 'trx_utils'),
                    "description" => wp_kses_data( __("Title for the block", 'trx_utils') ),
                    "admin_label" => true,
                    "group" => esc_html__('Captions', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "subtitle",
                    "heading" => esc_html__("Subtitle", 'trx_utils'),
                    "description" => wp_kses_data( __("Subtitle for the block", 'trx_utils') ),
                    "group" => esc_html__('Captions', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "description",
                    "heading" => esc_html__("Description", 'trx_utils'),
                    "description" => wp_kses_data( __("Description for the block", 'trx_utils') ),
                    "group" => esc_html__('Captions', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "textarea"
                ),
                array(
                    "param_name" => "cat",
                    "heading" => esc_html__("Categories", 'trx_utils'),
                    "description" => wp_kses_data( __("Select categories (groups) to show testimonials. If empty - select testimonials from any category (group) or from IDs list", 'trx_utils') ),
                    "group" => esc_html__('Query', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'custom',
                        'is_empty' => true
                    ),
                    "class" => "",
                    "value" => array_flip(cars4rent_array_merge(array(0 => esc_html__('- Select category -', 'trx_utils')), $testimonials_groups)),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "columns",
                    "heading" => esc_html__("Columns", 'trx_utils'),
                    "description" => wp_kses_data( __("How many columns use to show testimonials", 'trx_utils') ),
                    "group" => esc_html__('Query', 'trx_utils'),
                    "admin_label" => true,
                    "class" => "",
                    "value" => "1",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "count",
                    "heading" => esc_html__("Number of posts", 'trx_utils'),
                    "description" => wp_kses_data( __("How many posts will be displayed? If used IDs - this parameter ignored.", 'trx_utils') ),
                    "group" => esc_html__('Query', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'custom',
                        'is_empty' => true
                    ),
                    "class" => "",
                    "value" => "3",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "offset",
                    "heading" => esc_html__("Offset before select posts", 'trx_utils'),
                    "description" => wp_kses_data( __("Skip posts before select next part.", 'trx_utils') ),
                    "group" => esc_html__('Query', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'custom',
                        'is_empty' => true
                    ),
                    "class" => "",
                    "value" => "0",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "orderby",
                    "heading" => esc_html__("Post sorting", 'trx_utils'),
                    "description" => wp_kses_data( __("Select desired posts sorting method", 'trx_utils') ),
                    "group" => esc_html__('Query', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'custom',
                        'is_empty' => true
                    ),
                    "std" => "date",
                    "class" => "",
                    "value" => array_flip(cars4rent_get_sc_param('sorting')),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "order",
                    "heading" => esc_html__("Post order", 'trx_utils'),
                    "description" => wp_kses_data( __("Select desired posts order", 'trx_utils') ),
                    "group" => esc_html__('Query', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'custom',
                        'is_empty' => true
                    ),
                    "std" => "desc",
                    "class" => "",
                    "value" => array_flip(cars4rent_get_sc_param('ordering')),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "ids",
                    "heading" => esc_html__("Post IDs list", 'trx_utils'),
                    "description" => wp_kses_data( __("Comma separated list of posts ID. If set - parameters above are ignored!", 'trx_utils') ),
                    "group" => esc_html__('Query', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'custom',
                        'is_empty' => true
                    ),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "scheme",
                    "heading" => esc_html__("Color scheme", 'trx_utils'),
                    "description" => wp_kses_data( __("Select color scheme for this block", 'trx_utils') ),
                    "group" => esc_html__('Colors and Images', 'trx_utils'),
                    "class" => "",
                    "value" => array_flip(cars4rent_get_sc_param('schemes')),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "bg_color",
                    "heading" => esc_html__("Background color", 'trx_utils'),
                    "description" => wp_kses_data( __("Any background color for this section", 'trx_utils') ),
                    "group" => esc_html__('Colors and Images', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "colorpicker"
                ),
                array(
                    "param_name" => "bg_image",
                    "heading" => esc_html__("Background image URL", 'trx_utils'),
                    "description" => wp_kses_data( __("Select background image from library for this section", 'trx_utils') ),
                    "group" => esc_html__('Colors and Images', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "attach_image"
                ),
                array(
                    "param_name" => "bg_overlay",
                    "heading" => esc_html__("Overlay", 'trx_utils'),
                    "description" => wp_kses_data( __("Overlay color opacity (from 0.0 to 1.0)", 'trx_utils') ),
                    "group" => esc_html__('Colors and Images', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "bg_texture",
                    "heading" => esc_html__("Texture", 'trx_utils'),
                    "description" => wp_kses_data( __("Texture style from 1 to 11. Empty or 0 - without texture.", 'trx_utils') ),
                    "group" => esc_html__('Colors and Images', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                cars4rent_vc_width(),
                cars4rent_vc_height(),
                cars4rent_get_vc_param('margin_top'),
                cars4rent_get_vc_param('margin_bottom'),
                cars4rent_get_vc_param('margin_left'),
                cars4rent_get_vc_param('margin_right'),
                cars4rent_get_vc_param('id'),
                cars4rent_get_vc_param('class'),
                cars4rent_get_vc_param('animation'),
                cars4rent_get_vc_param('css')
            ),
            'js_view' => 'VcTrxColumnsView'
        ) );


        vc_map( array(
            "base" => "trx_testimonials_item",
            "name" => esc_html__("Testimonial", 'trx_utils'),
            "description" => wp_kses_data( __("Single testimonials item", 'trx_utils') ),
            "show_settings_on_create" => true,
            "class" => "trx_sc_collection trx_sc_column_item trx_sc_testimonials_item",
            "content_element" => true,
            "is_container" => true,
            'icon' => 'icon_trx_testimonials_item',
            "as_child" => array('only' => 'trx_testimonials'),
            "as_parent" => array('except' => 'trx_testimonials'),
            "params" => array(
                array(
                    "param_name" => "author",
                    "heading" => esc_html__("Author", 'trx_utils'),
                    "description" => wp_kses_data( __("Name of the testimonmials author", 'trx_utils') ),
                    "admin_label" => true,
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "link",
                    "heading" => esc_html__("Link", 'trx_utils'),
                    "description" => wp_kses_data( __("Link URL to the testimonmials author page", 'trx_utils') ),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "email",
                    "heading" => esc_html__("E-mail", 'trx_utils'),
                    "description" => wp_kses_data( __("E-mail of the testimonmials author", 'trx_utils') ),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "photo",
                    "heading" => esc_html__("Photo", 'trx_utils'),
                    "description" => wp_kses_data( __("Select or upload photo of testimonmials author or write URL of photo from other site", 'trx_utils') ),
                    "class" => "",
                    "value" => "",
                    "type" => "attach_image"
                ),
                cars4rent_get_vc_param('id'),
                cars4rent_get_vc_param('class'),
                cars4rent_get_vc_param('css')
            ),
            'js_view' => 'VcTrxColumnItemView'
        ) );

        class WPBakeryShortCode_Trx_Testimonials extends Cars4Rent_Vc_ShortCodeColumns {}
        class WPBakeryShortCode_Trx_Testimonials_Item extends Cars4Rent_Vc_ShortCodeCollection {}

    }
}

// Register plugin's shortcodes
//------------------------------------------------------------------------

// Register shortcode in the shortcodes list
if (!function_exists('cars4rent_booked_reg_shortcodes')) {
    function cars4rent_booked_reg_shortcodes() {
        if (cars4rent_storage_isset('shortcodes') && function_exists('cars4rent_sc_map')) {

            $booked_cals = cars4rent_get_list_booked_calendars();

            cars4rent_sc_map('booked-appointments', array(
                    "title" => esc_html__("Booked Appointments", 'trx_utils'),
                    "desc" => esc_html__("Display the currently logged in user's upcoming appointments", 'trx_utils'),
                    "decorate" => true,
                    "container" => false,
                    "params" => array()
                )
            );

            cars4rent_sc_map('booked-calendar', array(
                "title" => esc_html__("Booked Calendar", 'trx_utils'),
                "desc" => esc_html__("Insert booked calendar", 'trx_utils'),
                "decorate" => true,
                "container" => false,
                "params" => array(
                    "calendar" => array(
                        "title" => esc_html__("Calendar", 'trx_utils'),
                        "desc" => esc_html__("Select booked calendar to display", 'trx_utils'),
                        "value" => "0",
                        "type" => "select",
                        "options" => cars4rent_array_merge(array(0 => esc_html__('- Select calendar -', 'trx_utils')), $booked_cals)
                    ),
                    "year" => array(
                        "title" => esc_html__("Year", 'trx_utils'),
                        "desc" => esc_html__("Year to display on calendar by default", 'trx_utils'),
                        "value" => date("Y"),
                        "min" => date("Y"),
                        "max" => date("Y")+10,
                        "type" => "spinner"
                    ),
                    "month" => array(
                        "title" => esc_html__("Month", 'trx_utils'),
                        "desc" => esc_html__("Month to display on calendar by default", 'trx_utils'),
                        "value" => date("m"),
                        "min" => 1,
                        "max" => 12,
                        "type" => "spinner"
                    )
                )
            ));
        }
    }
}


// Register shortcode in the VC shortcodes list
if (!function_exists('cars4rent_booked_reg_shortcodes_vc')) {
    function cars4rent_booked_reg_shortcodes_vc() {

        $booked_cals = cars4rent_get_list_booked_calendars();

        // Booked Appointments
        vc_map( array(
            "base" => "booked-appointments",
            "name" => esc_html__("Booked Appointments", 'trx_utils'),
            "description" => esc_html__("Display the currently logged in user's upcoming appointments", 'trx_utils'),
            "category" => esc_html__('Content', 'trx_utils'),
            'icon' => 'icon_trx_booked',
            "class" => "trx_sc_single trx_sc_booked_appointments",
            "content_element" => true,
            "is_container" => false,
            "show_settings_on_create" => false,
            "params" => array()
        ) );

        class WPBakeryShortCode_Booked_Appointments extends Cars4Rent_Vc_ShortCodeSingle {}

        // Booked Calendar
        vc_map( array(
            "base" => "booked-calendar",
            "name" => esc_html__("Booked Calendar", 'trx_utils'),
            "description" => esc_html__("Insert booked calendar", 'trx_utils'),
            "category" => esc_html__('Content', 'trx_utils'),
            'icon' => 'icon_trx_booked',
            "class" => "trx_sc_single trx_sc_booked_calendar",
            "content_element" => true,
            "is_container" => false,
            "show_settings_on_create" => true,
            "params" => array(
                array(
                    "param_name" => "calendar",
                    "heading" => esc_html__("Calendar", 'trx_utils'),
                    "description" => esc_html__("Select booked calendar to display", 'trx_utils'),
                    "admin_label" => true,
                    "class" => "",
                    "std" => "0",
                    "value" => array_flip(cars4rent_array_merge(array(0 => esc_html__('- Select calendar -', 'trx_utils')), $booked_cals)),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "year",
                    "heading" => esc_html__("Year", 'trx_utils'),
                    "description" => esc_html__("Year to display on calendar by default", 'trx_utils'),
                    "admin_label" => true,
                    "class" => "",
                    "std" => date("Y"),
                    "value" => date("Y"),
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "month",
                    "heading" => esc_html__("Month", 'trx_utils'),
                    "description" => esc_html__("Month to display on calendar by default", 'trx_utils'),
                    "admin_label" => true,
                    "class" => "",
                    "std" => date("m"),
                    "value" => date("m"),
                    "type" => "textfield"
                )
            )
        ) );

        class WPBakeryShortCode_Booked_Calendar extends Cars4Rent_Vc_ShortCodeSingle {}

    }
}

// Shortcodes
//------------------------------------------------------------------------

// Register shortcode in the shortcodes list
if (!function_exists('cars4rent_html5_jquery_audio_player_reg_shortcodes') && function_exists('cars4rent_sc_map_after')) {
    function cars4rent_html5_jquery_audio_player_reg_shortcodes() {
        if (cars4rent_storage_isset('shortcodes')) {
            cars4rent_sc_map_after('trx_audio', 'hmp_player', array(
                    "title" => esc_html__("HTML5 jQuery Audio Player", 'trx_utils'),
                    "desc" => esc_html__("Insert HTML5 jQuery Audio Player", 'trx_utils'),
                    "decorate" => true,
                    "container" => false,
                    "params" => array()
                )
            );
        }
    }
}


// Register shortcode in the VC shortcodes list
if (!function_exists('cars4rent_hmp_player_reg_shortcodes_vc')) {
    add_filter('cars4rent_action_shortcodes_list_vc',	'cars4rent_hmp_player_reg_shortcodes_vc');
    function cars4rent_hmp_player_reg_shortcodes_vc() {

        // Cars4Rent HTML5 jQuery Audio Player
        vc_map( array(
            "base" => "hmp_player",
            "name" => esc_html__("HTML5 jQuery Audio Player", 'trx_utils'),
            "description" => esc_html__("Insert HTML5 jQuery Audio Player", 'trx_utils'),
            "category" => esc_html__('Content', 'trx_utils'),
            'icon' => 'icon_trx_audio',
            "class" => "trx_sc_single trx_sc_hmp_player",
            "content_element" => true,
            "is_container" => false,
            "show_settings_on_create" => false,
            "params" => array()
        ) );

        class WPBakeryShortCode_Hmp_Player extends Cars4Rent_Vc_ShortCodeSingle {}

    }
}

// Add RevSlider in the shortcodes params
if ( !function_exists( 'cars4rent_revslider_shortcodes_params' ) ) {
    function cars4rent_revslider_shortcodes_params($list=array()) {
        $list["revo_sliders"] = cars4rent_get_list_revo_sliders();
        return $list;
    }
}

// Register shortcodes to the internal builder
//------------------------------------------------------------------------
if ( !function_exists( 'cars4rent_woocommerce_reg_shortcodes' ) && function_exists('cars4rent_sc_map')) {
    function cars4rent_woocommerce_reg_shortcodes() {

        // WooCommerce - Cart
        cars4rent_sc_map("woocommerce_cart", array(
                "title" => esc_html__("Woocommerce: Cart", 'trx_utils'),
                "desc" => wp_kses_data( __("WooCommerce shortcode: show Cart page", 'trx_utils') ),
                "decorate" => false,
                "container" => false,
                "params" => array()
            )
        );

        // WooCommerce - Checkout
        cars4rent_sc_map("woocommerce_checkout", array(
                "title" => esc_html__("Woocommerce: Checkout", 'trx_utils'),
                "desc" => wp_kses_data( __("WooCommerce shortcode: show Checkout page", 'trx_utils') ),
                "decorate" => false,
                "container" => false,
                "params" => array()
            )
        );

        // WooCommerce - My Account
        cars4rent_sc_map("woocommerce_my_account", array(
                "title" => esc_html__("Woocommerce: My Account", 'trx_utils'),
                "desc" => wp_kses_data( __("WooCommerce shortcode: show My Account page", 'trx_utils') ),
                "decorate" => false,
                "container" => false,
                "params" => array()
            )
        );

        // WooCommerce - Order Tracking
        cars4rent_sc_map("woocommerce_order_tracking", array(
                "title" => esc_html__("Woocommerce: Order Tracking", 'trx_utils'),
                "desc" => wp_kses_data( __("WooCommerce shortcode: show Order Tracking page", 'trx_utils') ),
                "decorate" => false,
                "container" => false,
                "params" => array()
            )
        );

        // WooCommerce - Shop Messages
        cars4rent_sc_map("shop_messages", array(
                "title" => esc_html__("Woocommerce: Shop Messages", 'trx_utils'),
                "desc" => wp_kses_data( __("WooCommerce shortcode: show shop messages", 'trx_utils') ),
                "decorate" => false,
                "container" => false,
                "params" => array()
            )
        );

        // WooCommerce - Product Page
        cars4rent_sc_map("product_page", array(
                "title" => esc_html__("Woocommerce: Product Page", 'trx_utils'),
                "desc" => wp_kses_data( __("WooCommerce shortcode: display single product page", 'trx_utils') ),
                "decorate" => false,
                "container" => false,
                "params" => array(
                    "sku" => array(
                        "title" => esc_html__("SKU", 'trx_utils'),
                        "desc" => wp_kses_data( __("SKU code of displayed product", 'trx_utils') ),
                        "value" => "",
                        "type" => "text"
                    ),
                    "id" => array(
                        "title" => esc_html__("ID", 'trx_utils'),
                        "desc" => wp_kses_data( __("ID of displayed product", 'trx_utils') ),
                        "value" => "",
                        "type" => "text"
                    ),
                    "posts_per_page" => array(
                        "title" => esc_html__("Number", 'trx_utils'),
                        "desc" => wp_kses_data( __("How many products showed", 'trx_utils') ),
                        "value" => "1",
                        "min" => 1,
                        "type" => "spinner"
                    ),
                    "post_type" => array(
                        "title" => esc_html__("Post type", 'trx_utils'),
                        "desc" => wp_kses_data( __("Post type for the WP query (leave 'product')", 'trx_utils') ),
                        "value" => "product",
                        "type" => "text"
                    ),
                    "post_status" => array(
                        "title" => esc_html__("Post status", 'trx_utils'),
                        "desc" => wp_kses_data( __("Display posts only with this status", 'trx_utils') ),
                        "value" => "publish",
                        "type" => "select",
                        "options" => array(
                            "publish" => esc_html__('Publish', 'trx_utils'),
                            "protected" => esc_html__('Protected', 'trx_utils'),
                            "private" => esc_html__('Private', 'trx_utils'),
                            "pending" => esc_html__('Pending', 'trx_utils'),
                            "draft" => esc_html__('Draft', 'trx_utils')
                        )
                    )
                )
            )
        );

        // WooCommerce - Product
        cars4rent_sc_map("product", array(
                "title" => esc_html__("Woocommerce: Product", 'trx_utils'),
                "desc" => wp_kses_data( __("WooCommerce shortcode: display one product", 'trx_utils') ),
                "decorate" => false,
                "container" => false,
                "params" => array(
                    "sku" => array(
                        "title" => esc_html__("SKU", 'trx_utils'),
                        "desc" => wp_kses_data( __("SKU code of displayed product", 'trx_utils') ),
                        "value" => "",
                        "type" => "text"
                    ),
                    "id" => array(
                        "title" => esc_html__("ID", 'trx_utils'),
                        "desc" => wp_kses_data( __("ID of displayed product", 'trx_utils') ),
                        "value" => "",
                        "type" => "text"
                    )
                )
            )
        );

        // WooCommerce - Best Selling Products
        cars4rent_sc_map("best_selling_products", array(
                "title" => esc_html__("Woocommerce: Best Selling Products", 'trx_utils'),
                "desc" => wp_kses_data( __("WooCommerce shortcode: show best selling products", 'trx_utils') ),
                "decorate" => false,
                "container" => false,
                "params" => array(
                    "per_page" => array(
                        "title" => esc_html__("Number", 'trx_utils'),
                        "desc" => wp_kses_data( __("How many products showed", 'trx_utils') ),
                        "value" => 4,
                        "min" => 1,
                        "type" => "spinner"
                    ),
                    "columns" => array(
                        "title" => esc_html__("Columns", 'trx_utils'),
                        "desc" => wp_kses_data( __("How many columns per row use for products output", 'trx_utils') ),
                        "value" => 4,
                        "min" => 2,
                        "max" => 4,
                        "type" => "spinner"
                    )
                )
            )
        );

        // WooCommerce - Recent Products
        cars4rent_sc_map("recent_products", array(
                "title" => esc_html__("Woocommerce: Recent Products", 'trx_utils'),
                "desc" => wp_kses_data( __("WooCommerce shortcode: show recent products", 'trx_utils') ),
                "decorate" => false,
                "container" => false,
                "params" => array(
                    "per_page" => array(
                        "title" => esc_html__("Number", 'trx_utils'),
                        "desc" => wp_kses_data( __("How many products showed", 'trx_utils') ),
                        "value" => 4,
                        "min" => 1,
                        "type" => "spinner"
                    ),
                    "columns" => array(
                        "title" => esc_html__("Columns", 'trx_utils'),
                        "desc" => wp_kses_data( __("How many columns per row use for products output", 'trx_utils') ),
                        "value" => 4,
                        "min" => 2,
                        "max" => 4,
                        "type" => "spinner"
                    ),
                    "orderby" => array(
                        "title" => esc_html__("Order by", 'trx_utils'),
                        "desc" => wp_kses_data( __("Sorting order for products output", 'trx_utils') ),
                        "value" => "date",
                        "type" => "select",
                        "options" => array(
                            "date" => esc_html__('Date', 'trx_utils'),
                            "title" => esc_html__('Title', 'trx_utils')
                        )
                    ),
                    "order" => array(
                        "title" => esc_html__("Order", 'trx_utils'),
                        "desc" => wp_kses_data( __("Sorting order for products output", 'trx_utils') ),
                        "value" => "desc",
                        "type" => "switch",
                        "size" => "big",
                        "options" => cars4rent_get_sc_param('ordering')
                    )
                )
            )
        );

        // WooCommerce - Related Products
        cars4rent_sc_map("related_products", array(
                "title" => esc_html__("Woocommerce: Related Products", 'trx_utils'),
                "desc" => wp_kses_data( __("WooCommerce shortcode: show related products", 'trx_utils') ),
                "decorate" => false,
                "container" => false,
                "params" => array(
                    "posts_per_page" => array(
                        "title" => esc_html__("Number", 'trx_utils'),
                        "desc" => wp_kses_data( __("How many products showed", 'trx_utils') ),
                        "value" => 4,
                        "min" => 1,
                        "type" => "spinner"
                    ),
                    "columns" => array(
                        "title" => esc_html__("Columns", 'trx_utils'),
                        "desc" => wp_kses_data( __("How many columns per row use for products output", 'trx_utils') ),
                        "value" => 4,
                        "min" => 2,
                        "max" => 4,
                        "type" => "spinner"
                    ),
                    "orderby" => array(
                        "title" => esc_html__("Order by", 'trx_utils'),
                        "desc" => wp_kses_data( __("Sorting order for products output", 'trx_utils') ),
                        "value" => "date",
                        "type" => "select",
                        "options" => array(
                            "date" => esc_html__('Date', 'trx_utils'),
                            "title" => esc_html__('Title', 'trx_utils')
                        )
                    )
                )
            )
        );

        // WooCommerce - Featured Products
        cars4rent_sc_map("featured_products", array(
                "title" => esc_html__("Woocommerce: Featured Products", 'trx_utils'),
                "desc" => wp_kses_data( __("WooCommerce shortcode: show featured products", 'trx_utils') ),
                "decorate" => false,
                "container" => false,
                "params" => array(
                    "per_page" => array(
                        "title" => esc_html__("Number", 'trx_utils'),
                        "desc" => wp_kses_data( __("How many products showed", 'trx_utils') ),
                        "value" => 4,
                        "min" => 1,
                        "type" => "spinner"
                    ),
                    "columns" => array(
                        "title" => esc_html__("Columns", 'trx_utils'),
                        "desc" => wp_kses_data( __("How many columns per row use for products output", 'trx_utils') ),
                        "value" => 4,
                        "min" => 2,
                        "max" => 4,
                        "type" => "spinner"
                    ),
                    "orderby" => array(
                        "title" => esc_html__("Order by", 'trx_utils'),
                        "desc" => wp_kses_data( __("Sorting order for products output", 'trx_utils') ),
                        "value" => "date",
                        "type" => "select",
                        "options" => array(
                            "date" => esc_html__('Date', 'trx_utils'),
                            "title" => esc_html__('Title', 'trx_utils')
                        )
                    ),
                    "order" => array(
                        "title" => esc_html__("Order", 'trx_utils'),
                        "desc" => wp_kses_data( __("Sorting order for products output", 'trx_utils') ),
                        "value" => "desc",
                        "type" => "switch",
                        "size" => "big",
                        "options" => cars4rent_get_sc_param('ordering')
                    )
                )
            )
        );

        // WooCommerce - Top Rated Products
        cars4rent_sc_map("featured_products", array(
                "title" => esc_html__("Woocommerce: Top Rated Products", 'trx_utils'),
                "desc" => wp_kses_data( __("WooCommerce shortcode: show top rated products", 'trx_utils') ),
                "decorate" => false,
                "container" => false,
                "params" => array(
                    "per_page" => array(
                        "title" => esc_html__("Number", 'trx_utils'),
                        "desc" => wp_kses_data( __("How many products showed", 'trx_utils') ),
                        "value" => 4,
                        "min" => 1,
                        "type" => "spinner"
                    ),
                    "columns" => array(
                        "title" => esc_html__("Columns", 'trx_utils'),
                        "desc" => wp_kses_data( __("How many columns per row use for products output", 'trx_utils') ),
                        "value" => 4,
                        "min" => 2,
                        "max" => 4,
                        "type" => "spinner"
                    ),
                    "orderby" => array(
                        "title" => esc_html__("Order by", 'trx_utils'),
                        "desc" => wp_kses_data( __("Sorting order for products output", 'trx_utils') ),
                        "value" => "date",
                        "type" => "select",
                        "options" => array(
                            "date" => esc_html__('Date', 'trx_utils'),
                            "title" => esc_html__('Title', 'trx_utils')
                        )
                    ),
                    "order" => array(
                        "title" => esc_html__("Order", 'trx_utils'),
                        "desc" => wp_kses_data( __("Sorting order for products output", 'trx_utils') ),
                        "value" => "desc",
                        "type" => "switch",
                        "size" => "big",
                        "options" => cars4rent_get_sc_param('ordering')
                    )
                )
            )
        );

        // WooCommerce - Sale Products
        cars4rent_sc_map("featured_products", array(
                "title" => esc_html__("Woocommerce: Sale Products", 'trx_utils'),
                "desc" => wp_kses_data( __("WooCommerce shortcode: list products on sale", 'trx_utils') ),
                "decorate" => false,
                "container" => false,
                "params" => array(
                    "per_page" => array(
                        "title" => esc_html__("Number", 'trx_utils'),
                        "desc" => wp_kses_data( __("How many products showed", 'trx_utils') ),
                        "value" => 4,
                        "min" => 1,
                        "type" => "spinner"
                    ),
                    "columns" => array(
                        "title" => esc_html__("Columns", 'trx_utils'),
                        "desc" => wp_kses_data( __("How many columns per row use for products output", 'trx_utils') ),
                        "value" => 4,
                        "min" => 2,
                        "max" => 4,
                        "type" => "spinner"
                    ),
                    "orderby" => array(
                        "title" => esc_html__("Order by", 'trx_utils'),
                        "desc" => wp_kses_data( __("Sorting order for products output", 'trx_utils') ),
                        "value" => "date",
                        "type" => "select",
                        "options" => array(
                            "date" => esc_html__('Date', 'trx_utils'),
                            "title" => esc_html__('Title', 'trx_utils')
                        )
                    ),
                    "order" => array(
                        "title" => esc_html__("Order", 'trx_utils'),
                        "desc" => wp_kses_data( __("Sorting order for products output", 'trx_utils') ),
                        "value" => "desc",
                        "type" => "switch",
                        "size" => "big",
                        "options" => cars4rent_get_sc_param('ordering')
                    )
                )
            )
        );

        // WooCommerce - Product Category
        cars4rent_sc_map("product_category", array(
                "title" => esc_html__("Woocommerce: Products from category", 'trx_utils'),
                "desc" => wp_kses_data( __("WooCommerce shortcode: list products in specified category(-ies)", 'trx_utils') ),
                "decorate" => false,
                "container" => false,
                "params" => array(
                    "per_page" => array(
                        "title" => esc_html__("Number", 'trx_utils'),
                        "desc" => wp_kses_data( __("How many products showed", 'trx_utils') ),
                        "value" => 4,
                        "min" => 1,
                        "type" => "spinner"
                    ),
                    "columns" => array(
                        "title" => esc_html__("Columns", 'trx_utils'),
                        "desc" => wp_kses_data( __("How many columns per row use for products output", 'trx_utils') ),
                        "value" => 4,
                        "min" => 2,
                        "max" => 4,
                        "type" => "spinner"
                    ),
                    "orderby" => array(
                        "title" => esc_html__("Order by", 'trx_utils'),
                        "desc" => wp_kses_data( __("Sorting order for products output", 'trx_utils') ),
                        "value" => "date",
                        "type" => "select",
                        "options" => array(
                            "date" => esc_html__('Date', 'trx_utils'),
                            "title" => esc_html__('Title', 'trx_utils')
                        )
                    ),
                    "order" => array(
                        "title" => esc_html__("Order", 'trx_utils'),
                        "desc" => wp_kses_data( __("Sorting order for products output", 'trx_utils') ),
                        "value" => "desc",
                        "type" => "switch",
                        "size" => "big",
                        "options" => cars4rent_get_sc_param('ordering')
                    ),
                    "category" => array(
                        "title" => esc_html__("Categories", 'trx_utils'),
                        "desc" => wp_kses_data( __("Comma separated category slugs", 'trx_utils') ),
                        "value" => '',
                        "type" => "text"
                    ),
                    "operator" => array(
                        "title" => esc_html__("Operator", 'trx_utils'),
                        "desc" => wp_kses_data( __("Categories operator", 'trx_utils') ),
                        "value" => "IN",
                        "type" => "checklist",
                        "size" => "medium",
                        "options" => array(
                            "IN" => esc_html__('IN', 'trx_utils'),
                            "NOT IN" => esc_html__('NOT IN', 'trx_utils'),
                            "AND" => esc_html__('AND', 'trx_utils')
                        )
                    )
                )
            )
        );

        // WooCommerce - Products
        cars4rent_sc_map("products", array(
                "title" => esc_html__("Woocommerce: Products", 'trx_utils'),
                "desc" => wp_kses_data( __("WooCommerce shortcode: list all products", 'trx_utils') ),
                "decorate" => false,
                "container" => false,
                "params" => array(
                    "skus" => array(
                        "title" => esc_html__("SKUs", 'trx_utils'),
                        "desc" => wp_kses_data( __("Comma separated SKU codes of products", 'trx_utils') ),
                        "value" => "",
                        "type" => "text"
                    ),
                    "ids" => array(
                        "title" => esc_html__("IDs", 'trx_utils'),
                        "desc" => wp_kses_data( __("Comma separated ID of products", 'trx_utils') ),
                        "value" => "",
                        "type" => "text"
                    ),
                    "columns" => array(
                        "title" => esc_html__("Columns", 'trx_utils'),
                        "desc" => wp_kses_data( __("How many columns per row use for products output", 'trx_utils') ),
                        "value" => 4,
                        "min" => 2,
                        "max" => 4,
                        "type" => "spinner"
                    ),
                    "orderby" => array(
                        "title" => esc_html__("Order by", 'trx_utils'),
                        "desc" => wp_kses_data( __("Sorting order for products output", 'trx_utils') ),
                        "value" => "date",
                        "type" => "select",
                        "options" => array(
                            "date" => esc_html__('Date', 'trx_utils'),
                            "title" => esc_html__('Title', 'trx_utils')
                        )
                    ),
                    "order" => array(
                        "title" => esc_html__("Order", 'trx_utils'),
                        "desc" => wp_kses_data( __("Sorting order for products output", 'trx_utils') ),
                        "value" => "desc",
                        "type" => "switch",
                        "size" => "big",
                        "options" => cars4rent_get_sc_param('ordering')
                    )
                )
            )
        );

        // WooCommerce - Product attribute
        cars4rent_sc_map("product_attribute", array(
                "title" => esc_html__("Woocommerce: Products by Attribute", 'trx_utils'),
                "desc" => wp_kses_data( __("WooCommerce shortcode: show products with specified attribute", 'trx_utils') ),
                "decorate" => false,
                "container" => false,
                "params" => array(
                    "per_page" => array(
                        "title" => esc_html__("Number", 'trx_utils'),
                        "desc" => wp_kses_data( __("How many products showed", 'trx_utils') ),
                        "value" => 4,
                        "min" => 1,
                        "type" => "spinner"
                    ),
                    "columns" => array(
                        "title" => esc_html__("Columns", 'trx_utils'),
                        "desc" => wp_kses_data( __("How many columns per row use for products output", 'trx_utils') ),
                        "value" => 4,
                        "min" => 2,
                        "max" => 4,
                        "type" => "spinner"
                    ),
                    "orderby" => array(
                        "title" => esc_html__("Order by", 'trx_utils'),
                        "desc" => wp_kses_data( __("Sorting order for products output", 'trx_utils') ),
                        "value" => "date",
                        "type" => "select",
                        "options" => array(
                            "date" => esc_html__('Date', 'trx_utils'),
                            "title" => esc_html__('Title', 'trx_utils')
                        )
                    ),
                    "order" => array(
                        "title" => esc_html__("Order", 'trx_utils'),
                        "desc" => wp_kses_data( __("Sorting order for products output", 'trx_utils') ),
                        "value" => "desc",
                        "type" => "switch",
                        "size" => "big",
                        "options" => cars4rent_get_sc_param('ordering')
                    ),
                    "attribute" => array(
                        "title" => esc_html__("Attribute", 'trx_utils'),
                        "desc" => wp_kses_data( __("Attribute name", 'trx_utils') ),
                        "value" => "",
                        "type" => "text"
                    ),
                    "filter" => array(
                        "title" => esc_html__("Filter", 'trx_utils'),
                        "desc" => wp_kses_data( __("Attribute value", 'trx_utils') ),
                        "value" => "",
                        "type" => "text"
                    )
                )
            )
        );

        // WooCommerce - Products Categories
        cars4rent_sc_map("product_categories", array(
                "title" => esc_html__("Woocommerce: Product Categories", 'trx_utils'),
                "desc" => wp_kses_data( __("WooCommerce shortcode: show categories with products", 'trx_utils') ),
                "decorate" => false,
                "container" => false,
                "params" => array(
                    "number" => array(
                        "title" => esc_html__("Number", 'trx_utils'),
                        "desc" => wp_kses_data( __("How many categories showed", 'trx_utils') ),
                        "value" => 4,
                        "min" => 1,
                        "type" => "spinner"
                    ),
                    "columns" => array(
                        "title" => esc_html__("Columns", 'trx_utils'),
                        "desc" => wp_kses_data( __("How many columns per row use for categories output", 'trx_utils') ),
                        "value" => 4,
                        "min" => 2,
                        "max" => 4,
                        "type" => "spinner"
                    ),
                    "orderby" => array(
                        "title" => esc_html__("Order by", 'trx_utils'),
                        "desc" => wp_kses_data( __("Sorting order for products output", 'trx_utils') ),
                        "value" => "date",
                        "type" => "select",
                        "options" => array(
                            "date" => esc_html__('Date', 'trx_utils'),
                            "title" => esc_html__('Title', 'trx_utils')
                        )
                    ),
                    "order" => array(
                        "title" => esc_html__("Order", 'trx_utils'),
                        "desc" => wp_kses_data( __("Sorting order for products output", 'trx_utils') ),
                        "value" => "desc",
                        "type" => "switch",
                        "size" => "big",
                        "options" => cars4rent_get_sc_param('ordering')
                    ),
                    "parent" => array(
                        "title" => esc_html__("Parent", 'trx_utils'),
                        "desc" => wp_kses_data( __("Parent category slug", 'trx_utils') ),
                        "value" => "",
                        "type" => "text"
                    ),
                    "ids" => array(
                        "title" => esc_html__("IDs", 'trx_utils'),
                        "desc" => wp_kses_data( __("Comma separated ID of products", 'trx_utils') ),
                        "value" => "",
                        "type" => "text"
                    ),
                    "hide_empty" => array(
                        "title" => esc_html__("Hide empty", 'trx_utils'),
                        "desc" => wp_kses_data( __("Hide empty categories", 'trx_utils') ),
                        "value" => "yes",
                        "type" => "switch",
                        "options" => cars4rent_get_sc_param('yes_no')
                    )
                )
            )
        );
    }
}

// Register shortcodes to the VC builder
//------------------------------------------------------------------------
if ( !function_exists( 'cars4rent_woocommerce_reg_shortcodes_vc' ) ) {
    function cars4rent_woocommerce_reg_shortcodes_vc() {

        if (false && function_exists('cars4rent_exists_woocommerce') && cars4rent_exists_woocommerce()) {

            // WooCommerce - Cart
            //-------------------------------------------------------------------------------------

            vc_map( array(
                "base" => "woocommerce_cart",
                "name" => esc_html__("Cart", 'trx_utils'),
                "description" => wp_kses_data( __("WooCommerce shortcode: show cart page", 'trx_utils') ),
                "category" => esc_html__('WooCommerce', 'trx_utils'),
                'icon' => 'icon_trx_wooc_cart',
                "class" => "trx_sc_alone trx_sc_woocommerce_cart",
                "content_element" => true,
                "is_container" => false,
                "show_settings_on_create" => false,
                "params" => array(
                    array(
                        "param_name" => "dummy",
                        "heading" => esc_html__("Dummy data", 'trx_utils'),
                        "description" => wp_kses_data( __("Dummy data - not used in shortcodes", 'trx_utils') ),
                        "class" => "",
                        "value" => "",
                        "type" => "textfield"
                    )
                )
            ) );

            class WPBakeryShortCode_Woocommerce_Cart extends Cars4Rent_Vc_ShortCodeAlone {}


            // WooCommerce - Checkout
            //-------------------------------------------------------------------------------------

            vc_map( array(
                "base" => "woocommerce_checkout",
                "name" => esc_html__("Checkout", 'trx_utils'),
                "description" => wp_kses_data( __("WooCommerce shortcode: show checkout page", 'trx_utils') ),
                "category" => esc_html__('WooCommerce', 'trx_utils'),
                'icon' => 'icon_trx_wooc_checkout',
                "class" => "trx_sc_alone trx_sc_woocommerce_checkout",
                "content_element" => true,
                "is_container" => false,
                "show_settings_on_create" => false,
                "params" => array(
                    array(
                        "param_name" => "dummy",
                        "heading" => esc_html__("Dummy data", 'trx_utils'),
                        "description" => wp_kses_data( __("Dummy data - not used in shortcodes", 'trx_utils') ),
                        "class" => "",
                        "value" => "",
                        "type" => "textfield"
                    )
                )
            ) );

            class WPBakeryShortCode_Woocommerce_Checkout extends Cars4Rent_Vc_ShortCodeAlone {}


            // WooCommerce - My Account
            //-------------------------------------------------------------------------------------

            vc_map( array(
                "base" => "woocommerce_my_account",
                "name" => esc_html__("My Account", 'trx_utils'),
                "description" => wp_kses_data( __("WooCommerce shortcode: show my account page", 'trx_utils') ),
                "category" => esc_html__('WooCommerce', 'trx_utils'),
                'icon' => 'icon_trx_wooc_my_account',
                "class" => "trx_sc_alone trx_sc_woocommerce_my_account",
                "content_element" => true,
                "is_container" => false,
                "show_settings_on_create" => false,
                "params" => array(
                    array(
                        "param_name" => "dummy",
                        "heading" => esc_html__("Dummy data", 'trx_utils'),
                        "description" => wp_kses_data( __("Dummy data - not used in shortcodes", 'trx_utils') ),
                        "class" => "",
                        "value" => "",
                        "type" => "textfield"
                    )
                )
            ) );

            class WPBakeryShortCode_Woocommerce_My_Account extends Cars4Rent_Vc_ShortCodeAlone {}


            // WooCommerce - Order Tracking
            //-------------------------------------------------------------------------------------

            vc_map( array(
                "base" => "woocommerce_order_tracking",
                "name" => esc_html__("Order Tracking", 'trx_utils'),
                "description" => wp_kses_data( __("WooCommerce shortcode: show order tracking page", 'trx_utils') ),
                "category" => esc_html__('WooCommerce', 'trx_utils'),
                'icon' => 'icon_trx_wooc_order_tracking',
                "class" => "trx_sc_alone trx_sc_woocommerce_order_tracking",
                "content_element" => true,
                "is_container" => false,
                "show_settings_on_create" => false,
                "params" => array(
                    array(
                        "param_name" => "dummy",
                        "heading" => esc_html__("Dummy data", 'trx_utils'),
                        "description" => wp_kses_data( __("Dummy data - not used in shortcodes", 'trx_utils') ),
                        "class" => "",
                        "value" => "",
                        "type" => "textfield"
                    )
                )
            ) );

            class WPBakeryShortCode_Woocommerce_Order_Tracking extends Cars4Rent_Vc_ShortCodeAlone {}


            // WooCommerce - Shop Messages
            //-------------------------------------------------------------------------------------

            vc_map( array(
                "base" => "shop_messages",
                "name" => esc_html__("Shop Messages", 'trx_utils'),
                "description" => wp_kses_data( __("WooCommerce shortcode: show shop messages", 'trx_utils') ),
                "category" => esc_html__('WooCommerce', 'trx_utils'),
                'icon' => 'icon_trx_wooc_shop_messages',
                "class" => "trx_sc_alone trx_sc_shop_messages",
                "content_element" => true,
                "is_container" => false,
                "show_settings_on_create" => false,
                "params" => array(
                    array(
                        "param_name" => "dummy",
                        "heading" => esc_html__("Dummy data", 'trx_utils'),
                        "description" => wp_kses_data( __("Dummy data - not used in shortcodes", 'trx_utils') ),
                        "class" => "",
                        "value" => "",
                        "type" => "textfield"
                    )
                )
            ) );

            class WPBakeryShortCode_Shop_Messages extends Cars4Rent_Vc_ShortCodeAlone {}


            // WooCommerce - Product Page
            //-------------------------------------------------------------------------------------

            vc_map( array(
                "base" => "product_page",
                "name" => esc_html__("Product Page", 'trx_utils'),
                "description" => wp_kses_data( __("WooCommerce shortcode: display single product page", 'trx_utils') ),
                "category" => esc_html__('WooCommerce', 'trx_utils'),
                'icon' => 'icon_trx_product_page',
                "class" => "trx_sc_single trx_sc_product_page",
                "content_element" => true,
                "is_container" => false,
                "show_settings_on_create" => true,
                "params" => array(
                    array(
                        "param_name" => "sku",
                        "heading" => esc_html__("SKU", 'trx_utils'),
                        "description" => wp_kses_data( __("SKU code of displayed product", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => "",
                        "type" => "textfield"
                    ),
                    array(
                        "param_name" => "id",
                        "heading" => esc_html__("ID", 'trx_utils'),
                        "description" => wp_kses_data( __("ID of displayed product", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => "",
                        "type" => "textfield"
                    ),
                    array(
                        "param_name" => "posts_per_page",
                        "heading" => esc_html__("Number", 'trx_utils'),
                        "description" => wp_kses_data( __("How many products showed", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => "1",
                        "type" => "textfield"
                    ),
                    array(
                        "param_name" => "post_type",
                        "heading" => esc_html__("Post type", 'trx_utils'),
                        "description" => wp_kses_data( __("Post type for the WP query (leave 'product')", 'trx_utils') ),
                        "class" => "",
                        "value" => "product",
                        "type" => "textfield"
                    ),
                    array(
                        "param_name" => "post_status",
                        "heading" => esc_html__("Post status", 'trx_utils'),
                        "description" => wp_kses_data( __("Display posts only with this status", 'trx_utils') ),
                        "class" => "",
                        "value" => array(
                            esc_html__('Publish', 'trx_utils') => 'publish',
                            esc_html__('Protected', 'trx_utils') => 'protected',
                            esc_html__('Private', 'trx_utils') => 'private',
                            esc_html__('Pending', 'trx_utils') => 'pending',
                            esc_html__('Draft', 'trx_utils') => 'draft'
                        ),
                        "type" => "dropdown"
                    )
                )
            ) );

            class WPBakeryShortCode_Product_Page extends Cars4Rent_Vc_ShortCodeSingle {}



            // WooCommerce - Product
            //-------------------------------------------------------------------------------------

            vc_map( array(
                "base" => "product",
                "name" => esc_html__("Product", 'trx_utils'),
                "description" => wp_kses_data( __("WooCommerce shortcode: display one product", 'trx_utils') ),
                "category" => esc_html__('WooCommerce', 'trx_utils'),
                'icon' => 'icon_trx_product',
                "class" => "trx_sc_single trx_sc_product",
                "content_element" => true,
                "is_container" => false,
                "show_settings_on_create" => true,
                "params" => array(
                    array(
                        "param_name" => "sku",
                        "heading" => esc_html__("SKU", 'trx_utils'),
                        "description" => wp_kses_data( __("Product's SKU code", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => "",
                        "type" => "textfield"
                    ),
                    array(
                        "param_name" => "id",
                        "heading" => esc_html__("ID", 'trx_utils'),
                        "description" => wp_kses_data( __("Product's ID", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => "",
                        "type" => "textfield"
                    )
                )
            ) );

            class WPBakeryShortCode_Product extends Cars4Rent_Vc_ShortCodeSingle {}


            // WooCommerce - Best Selling Products
            //-------------------------------------------------------------------------------------

            vc_map( array(
                "base" => "best_selling_products",
                "name" => esc_html__("Best Selling Products", 'trx_utils'),
                "description" => wp_kses_data( __("WooCommerce shortcode: show best selling products", 'trx_utils') ),
                "category" => esc_html__('WooCommerce', 'trx_utils'),
                'icon' => 'icon_trx_best_selling_products',
                "class" => "trx_sc_single trx_sc_best_selling_products",
                "content_element" => true,
                "is_container" => false,
                "show_settings_on_create" => true,
                "params" => array(
                    array(
                        "param_name" => "per_page",
                        "heading" => esc_html__("Number", 'trx_utils'),
                        "description" => wp_kses_data( __("How many products showed", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => "4",
                        "type" => "textfield"
                    ),
                    array(
                        "param_name" => "columns",
                        "heading" => esc_html__("Columns", 'trx_utils'),
                        "description" => wp_kses_data( __("How many columns per row use for products output", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => "1",
                        "type" => "textfield"
                    )
                )
            ) );

            class WPBakeryShortCode_Best_Selling_Products extends Cars4Rent_Vc_ShortCodeSingle {}



            // WooCommerce - Recent Products
            //-------------------------------------------------------------------------------------

            vc_map( array(
                "base" => "recent_products",
                "name" => esc_html__("Recent Products", 'trx_utils'),
                "description" => wp_kses_data( __("WooCommerce shortcode: show recent products", 'trx_utils') ),
                "category" => esc_html__('WooCommerce', 'trx_utils'),
                'icon' => 'icon_trx_recent_products',
                "class" => "trx_sc_single trx_sc_recent_products",
                "content_element" => true,
                "is_container" => false,
                "show_settings_on_create" => true,
                "params" => array(
                    array(
                        "param_name" => "per_page",
                        "heading" => esc_html__("Number", 'trx_utils'),
                        "description" => wp_kses_data( __("How many products showed", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => "4",
                        "type" => "textfield"

                    ),
                    array(
                        "param_name" => "columns",
                        "heading" => esc_html__("Columns", 'trx_utils'),
                        "description" => wp_kses_data( __("How many columns per row use for products output", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => "1",
                        "type" => "textfield"
                    ),
                    array(
                        "param_name" => "orderby",
                        "heading" => esc_html__("Order by", 'trx_utils'),
                        "description" => wp_kses_data( __("Sorting order for products output", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => array(
                            esc_html__('Date', 'trx_utils') => 'date',
                            esc_html__('Title', 'trx_utils') => 'title'
                        ),
                        "type" => "dropdown"
                    ),
                    array(
                        "param_name" => "order",
                        "heading" => esc_html__("Order", 'trx_utils'),
                        "description" => wp_kses_data( __("Sorting order for products output", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => array_flip(cars4rent_get_sc_param('ordering')),
                        "type" => "dropdown"
                    )
                )
            ) );

            class WPBakeryShortCode_Recent_Products extends Cars4Rent_Vc_ShortCodeSingle {}



            // WooCommerce - Related Products
            //-------------------------------------------------------------------------------------

            vc_map( array(
                "base" => "related_products",
                "name" => esc_html__("Related Products", 'trx_utils'),
                "description" => wp_kses_data( __("WooCommerce shortcode: show related products", 'trx_utils') ),
                "category" => esc_html__('WooCommerce', 'trx_utils'),
                'icon' => 'icon_trx_related_products',
                "class" => "trx_sc_single trx_sc_related_products",
                "content_element" => true,
                "is_container" => false,
                "show_settings_on_create" => true,
                "params" => array(
                    array(
                        "param_name" => "posts_per_page",
                        "heading" => esc_html__("Number", 'trx_utils'),
                        "description" => wp_kses_data( __("How many products showed", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => "4",
                        "type" => "textfield"
                    ),
                    array(
                        "param_name" => "columns",
                        "heading" => esc_html__("Columns", 'trx_utils'),
                        "description" => wp_kses_data( __("How many columns per row use for products output", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => "1",
                        "type" => "textfield"
                    ),
                    array(
                        "param_name" => "orderby",
                        "heading" => esc_html__("Order by", 'trx_utils'),
                        "description" => wp_kses_data( __("Sorting order for products output", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => array(
                            esc_html__('Date', 'trx_utils') => 'date',
                            esc_html__('Title', 'trx_utils') => 'title'
                        ),
                        "type" => "dropdown"
                    )
                )
            ) );

            class WPBakeryShortCode_Related_Products extends Cars4Rent_Vc_ShortCodeSingle {}



            // WooCommerce - Featured Products
            //-------------------------------------------------------------------------------------

            vc_map( array(
                "base" => "featured_products",
                "name" => esc_html__("Featured Products", 'trx_utils'),
                "description" => wp_kses_data( __("WooCommerce shortcode: show featured products", 'trx_utils') ),
                "category" => esc_html__('WooCommerce', 'trx_utils'),
                'icon' => 'icon_trx_featured_products',
                "class" => "trx_sc_single trx_sc_featured_products",
                "content_element" => true,
                "is_container" => false,
                "show_settings_on_create" => true,
                "params" => array(
                    array(
                        "param_name" => "per_page",
                        "heading" => esc_html__("Number", 'trx_utils'),
                        "description" => wp_kses_data( __("How many products showed", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => "4",
                        "type" => "textfield"
                    ),
                    array(
                        "param_name" => "columns",
                        "heading" => esc_html__("Columns", 'trx_utils'),
                        "description" => wp_kses_data( __("How many columns per row use for products output", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => "1",
                        "type" => "textfield"
                    ),
                    array(
                        "param_name" => "orderby",
                        "heading" => esc_html__("Order by", 'trx_utils'),
                        "description" => wp_kses_data( __("Sorting order for products output", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => array(
                            esc_html__('Date', 'trx_utils') => 'date',
                            esc_html__('Title', 'trx_utils') => 'title'
                        ),
                        "type" => "dropdown"
                    ),
                    array(
                        "param_name" => "order",
                        "heading" => esc_html__("Order", 'trx_utils'),
                        "description" => wp_kses_data( __("Sorting order for products output", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => array_flip(cars4rent_get_sc_param('ordering')),
                        "type" => "dropdown"
                    )
                )
            ) );

            class WPBakeryShortCode_Featured_Products extends Cars4Rent_Vc_ShortCodeSingle {}



            // WooCommerce - Top Rated Products
            //-------------------------------------------------------------------------------------

            vc_map( array(
                "base" => "top_rated_products",
                "name" => esc_html__("Top Rated Products", 'trx_utils'),
                "description" => wp_kses_data( __("WooCommerce shortcode: show top rated products", 'trx_utils') ),
                "category" => esc_html__('WooCommerce', 'trx_utils'),
                'icon' => 'icon_trx_top_rated_products',
                "class" => "trx_sc_single trx_sc_top_rated_products",
                "content_element" => true,
                "is_container" => false,
                "show_settings_on_create" => true,
                "params" => array(
                    array(
                        "param_name" => "per_page",
                        "heading" => esc_html__("Number", 'trx_utils'),
                        "description" => wp_kses_data( __("How many products showed", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => "4",
                        "type" => "textfield"
                    ),
                    array(
                        "param_name" => "columns",
                        "heading" => esc_html__("Columns", 'trx_utils'),
                        "description" => wp_kses_data( __("How many columns per row use for products output", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => "1",
                        "type" => "textfield"
                    ),
                    array(
                        "param_name" => "orderby",
                        "heading" => esc_html__("Order by", 'trx_utils'),
                        "description" => wp_kses_data( __("Sorting order for products output", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => array(
                            esc_html__('Date', 'trx_utils') => 'date',
                            esc_html__('Title', 'trx_utils') => 'title'
                        ),
                        "type" => "dropdown"
                    ),
                    array(
                        "param_name" => "order",
                        "heading" => esc_html__("Order", 'trx_utils'),
                        "description" => wp_kses_data( __("Sorting order for products output", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => array_flip(cars4rent_get_sc_param('ordering')),
                        "type" => "dropdown"
                    )
                )
            ) );

            class WPBakeryShortCode_Top_Rated_Products extends Cars4Rent_Vc_ShortCodeSingle {}



            // WooCommerce - Sale Products
            //-------------------------------------------------------------------------------------

            vc_map( array(
                "base" => "sale_products",
                "name" => esc_html__("Sale Products", 'trx_utils'),
                "description" => wp_kses_data( __("WooCommerce shortcode: list products on sale", 'trx_utils') ),
                "category" => esc_html__('WooCommerce', 'trx_utils'),
                'icon' => 'icon_trx_sale_products',
                "class" => "trx_sc_single trx_sc_sale_products",
                "content_element" => true,
                "is_container" => false,
                "show_settings_on_create" => true,
                "params" => array(
                    array(
                        "param_name" => "per_page",
                        "heading" => esc_html__("Number", 'trx_utils'),
                        "description" => wp_kses_data( __("How many products showed", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => "4",
                        "type" => "textfield"
                    ),
                    array(
                        "param_name" => "columns",
                        "heading" => esc_html__("Columns", 'trx_utils'),
                        "description" => wp_kses_data( __("How many columns per row use for products output", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => "1",
                        "type" => "textfield"
                    ),
                    array(
                        "param_name" => "orderby",
                        "heading" => esc_html__("Order by", 'trx_utils'),
                        "description" => wp_kses_data( __("Sorting order for products output", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => array(
                            esc_html__('Date', 'trx_utils') => 'date',
                            esc_html__('Title', 'trx_utils') => 'title'
                        ),
                        "type" => "dropdown"
                    ),
                    array(
                        "param_name" => "order",
                        "heading" => esc_html__("Order", 'trx_utils'),
                        "description" => wp_kses_data( __("Sorting order for products output", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => array_flip(cars4rent_get_sc_param('ordering')),
                        "type" => "dropdown"
                    )
                )
            ) );

            class WPBakeryShortCode_Sale_Products extends Cars4Rent_Vc_ShortCodeSingle {}



            // WooCommerce - Product Category
            //-------------------------------------------------------------------------------------

            vc_map( array(
                "base" => "product_category",
                "name" => esc_html__("Products from category", 'trx_utils'),
                "description" => wp_kses_data( __("WooCommerce shortcode: list products in specified category(-ies)", 'trx_utils') ),
                "category" => esc_html__('WooCommerce', 'trx_utils'),
                'icon' => 'icon_trx_product_category',
                "class" => "trx_sc_single trx_sc_product_category",
                "content_element" => true,
                "is_container" => false,
                "show_settings_on_create" => true,
                "params" => array(
                    array(
                        "param_name" => "per_page",
                        "heading" => esc_html__("Number", 'trx_utils'),
                        "description" => wp_kses_data( __("How many products showed", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => "4",
                        "type" => "textfield"
                    ),
                    array(
                        "param_name" => "columns",
                        "heading" => esc_html__("Columns", 'trx_utils'),
                        "description" => wp_kses_data( __("How many columns per row use for products output", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => "1",
                        "type" => "textfield"
                    ),
                    array(
                        "param_name" => "orderby",
                        "heading" => esc_html__("Order by", 'trx_utils'),
                        "description" => wp_kses_data( __("Sorting order for products output", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => array(
                            esc_html__('Date', 'trx_utils') => 'date',
                            esc_html__('Title', 'trx_utils') => 'title'
                        ),
                        "type" => "dropdown"
                    ),
                    array(
                        "param_name" => "order",
                        "heading" => esc_html__("Order", 'trx_utils'),
                        "description" => wp_kses_data( __("Sorting order for products output", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => array_flip(cars4rent_get_sc_param('ordering')),
                        "type" => "dropdown"
                    ),
                    array(
                        "param_name" => "category",
                        "heading" => esc_html__("Categories", 'trx_utils'),
                        "description" => wp_kses_data( __("Comma separated category slugs", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => "",
                        "type" => "textfield"
                    ),
                    array(
                        "param_name" => "operator",
                        "heading" => esc_html__("Operator", 'trx_utils'),
                        "description" => wp_kses_data( __("Categories operator", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => array(
                            esc_html__('IN', 'trx_utils') => 'IN',
                            esc_html__('NOT IN', 'trx_utils') => 'NOT IN',
                            esc_html__('AND', 'trx_utils') => 'AND'
                        ),
                        "type" => "dropdown"
                    )
                )
            ) );

            class WPBakeryShortCode_Product_Category extends Cars4Rent_Vc_ShortCodeSingle {}



            // WooCommerce - Products
            //-------------------------------------------------------------------------------------

            vc_map( array(
                "base" => "products",
                "name" => esc_html__("Products", 'trx_utils'),
                "description" => wp_kses_data( __("WooCommerce shortcode: list all products", 'trx_utils') ),
                "category" => esc_html__('WooCommerce', 'trx_utils'),
                'icon' => 'icon_trx_products',
                "class" => "trx_sc_single trx_sc_products",
                "content_element" => true,
                "is_container" => false,
                "show_settings_on_create" => true,
                "params" => array(
                    array(
                        "param_name" => "skus",
                        "heading" => esc_html__("SKUs", 'trx_utils'),
                        "description" => wp_kses_data( __("Comma separated SKU codes of products", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => "",
                        "type" => "textfield"
                    ),
                    array(
                        "param_name" => "ids",
                        "heading" => esc_html__("IDs", 'trx_utils'),
                        "description" => wp_kses_data( __("Comma separated ID of products", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => "",
                        "type" => "textfield"
                    ),
                    array(
                        "param_name" => "columns",
                        "heading" => esc_html__("Columns", 'trx_utils'),
                        "description" => wp_kses_data( __("How many columns per row use for products output", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => "1",
                        "type" => "textfield"
                    ),
                    array(
                        "param_name" => "orderby",
                        "heading" => esc_html__("Order by", 'trx_utils'),
                        "description" => wp_kses_data( __("Sorting order for products output", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => array(
                            esc_html__('Date', 'trx_utils') => 'date',
                            esc_html__('Title', 'trx_utils') => 'title'
                        ),
                        "type" => "dropdown"
                    ),
                    array(
                        "param_name" => "order",
                        "heading" => esc_html__("Order", 'trx_utils'),
                        "description" => wp_kses_data( __("Sorting order for products output", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => array_flip(cars4rent_get_sc_param('ordering')),
                        "type" => "dropdown"
                    )
                )
            ) );

            class WPBakeryShortCode_Products extends Cars4Rent_Vc_ShortCodeSingle {}




            // WooCommerce - Product Attribute
            //-------------------------------------------------------------------------------------

            vc_map( array(
                "base" => "product_attribute",
                "name" => esc_html__("Products by Attribute", 'trx_utils'),
                "description" => wp_kses_data( __("WooCommerce shortcode: show products with specified attribute", 'trx_utils') ),
                "category" => esc_html__('WooCommerce', 'trx_utils'),
                'icon' => 'icon_trx_product_attribute',
                "class" => "trx_sc_single trx_sc_product_attribute",
                "content_element" => true,
                "is_container" => false,
                "show_settings_on_create" => true,
                "params" => array(
                    array(
                        "param_name" => "per_page",
                        "heading" => esc_html__("Number", 'trx_utils'),
                        "description" => wp_kses_data( __("How many products showed", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => "4",
                        "type" => "textfield"
                    ),
                    array(
                        "param_name" => "columns",
                        "heading" => esc_html__("Columns", 'trx_utils'),
                        "description" => wp_kses_data( __("How many columns per row use for products output", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => "1",
                        "type" => "textfield"
                    ),
                    array(
                        "param_name" => "orderby",
                        "heading" => esc_html__("Order by", 'trx_utils'),
                        "description" => wp_kses_data( __("Sorting order for products output", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => array(
                            esc_html__('Date', 'trx_utils') => 'date',
                            esc_html__('Title', 'trx_utils') => 'title'
                        ),
                        "type" => "dropdown"
                    ),
                    array(
                        "param_name" => "order",
                        "heading" => esc_html__("Order", 'trx_utils'),
                        "description" => wp_kses_data( __("Sorting order for products output", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => array_flip(cars4rent_get_sc_param('ordering')),
                        "type" => "dropdown"
                    ),
                    array(
                        "param_name" => "attribute",
                        "heading" => esc_html__("Attribute", 'trx_utils'),
                        "description" => wp_kses_data( __("Attribute name", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => "",
                        "type" => "textfield"
                    ),
                    array(
                        "param_name" => "filter",
                        "heading" => esc_html__("Filter", 'trx_utils'),
                        "description" => wp_kses_data( __("Attribute value", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => "",
                        "type" => "textfield"
                    )
                )
            ) );

            class WPBakeryShortCode_Product_Attribute extends Cars4Rent_Vc_ShortCodeSingle {}



            // WooCommerce - Products Categories
            //-------------------------------------------------------------------------------------

            vc_map( array(
                "base" => "product_categories",
                "name" => esc_html__("Product Categories", 'trx_utils'),
                "description" => wp_kses_data( __("WooCommerce shortcode: show categories with products", 'trx_utils') ),
                "category" => esc_html__('WooCommerce', 'trx_utils'),
                'icon' => 'icon_trx_product_categories',
                "class" => "trx_sc_single trx_sc_product_categories",
                "content_element" => true,
                "is_container" => false,
                "show_settings_on_create" => true,
                "params" => array(
                    array(
                        "param_name" => "number",
                        "heading" => esc_html__("Number", 'trx_utils'),
                        "description" => wp_kses_data( __("How many categories showed", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => "4",
                        "type" => "textfield"
                    ),
                    array(
                        "param_name" => "columns",
                        "heading" => esc_html__("Columns", 'trx_utils'),
                        "description" => wp_kses_data( __("How many columns per row use for categories output", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => "1",
                        "type" => "textfield"
                    ),
                    array(
                        "param_name" => "orderby",
                        "heading" => esc_html__("Order by", 'trx_utils'),
                        "description" => wp_kses_data( __("Sorting order for products output", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => array(
                            esc_html__('Date', 'trx_utils') => 'date',
                            esc_html__('Title', 'trx_utils') => 'title'
                        ),
                        "type" => "dropdown"
                    ),
                    array(
                        "param_name" => "order",
                        "heading" => esc_html__("Order", 'trx_utils'),
                        "description" => wp_kses_data( __("Sorting order for products output", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => array_flip(cars4rent_get_sc_param('ordering')),
                        "type" => "dropdown"
                    ),
                    array(
                        "param_name" => "parent",
                        "heading" => esc_html__("Parent", 'trx_utils'),
                        "description" => wp_kses_data( __("Parent category slug", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => "date",
                        "type" => "textfield"
                    ),
                    array(
                        "param_name" => "ids",
                        "heading" => esc_html__("IDs", 'trx_utils'),
                        "description" => wp_kses_data( __("Comma separated ID of products", 'trx_utils') ),
                        "admin_label" => true,
                        "class" => "",
                        "value" => "",
                        "type" => "textfield"
                    ),
                    array(
                        "param_name" => "hide_empty",
                        "heading" => esc_html__("Hide empty", 'trx_utils'),
                        "description" => wp_kses_data( __("Hide empty categories", 'trx_utils') ),
                        "class" => "",
                        "value" => array("Hide empty" => "1" ),
                        "type" => "checkbox"
                    )
                )
            ) );

            class WPBakeryShortCode_Products_Categories extends Cars4Rent_Vc_ShortCodeSingle {}

        }
    }
}

// Cars4Rent shortcodes builder settings
require_once trx_utils_get_file_dir('shortcodes/shortcodes_settings.php');

// VC shortcodes settings
if ( class_exists('WPBakeryShortCode') ) {
	require_once trx_utils_get_file_dir('shortcodes/shortcodes_vc.php');
}

// Cars4Rent shortcodes implementation
// Using get_template_part(), because shortcodes can be replaced in the child theme
require_once trx_utils_get_file_dir('shortcodes/trx_basic/anchor.php');
require_once trx_utils_get_file_dir('shortcodes/trx_basic/audio.php');
require_once trx_utils_get_file_dir('shortcodes/trx_basic/blogger.php');
require_once trx_utils_get_file_dir('shortcodes/trx_basic/call_to_action.php');
require_once trx_utils_get_file_dir('shortcodes/trx_basic/columns.php');
require_once trx_utils_get_file_dir('shortcodes/trx_basic/content.php');
require_once trx_utils_get_file_dir('shortcodes/trx_basic/form.php');
require_once trx_utils_get_file_dir('shortcodes/trx_basic/googlemap.php');
require_once trx_utils_get_file_dir('shortcodes/trx_basic/hide.php');
require_once trx_utils_get_file_dir('shortcodes/trx_basic/image.php');
require_once trx_utils_get_file_dir('shortcodes/trx_basic/infobox.php');
require_once trx_utils_get_file_dir('shortcodes/trx_basic/intro.php');
require_once trx_utils_get_file_dir('shortcodes/trx_basic/line.php');
require_once trx_utils_get_file_dir('shortcodes/trx_basic/list.php');
require_once trx_utils_get_file_dir('shortcodes/trx_basic/price_block.php');
require_once trx_utils_get_file_dir('shortcodes/trx_basic/promo.php');
require_once trx_utils_get_file_dir('shortcodes/trx_basic/quote.php');
require_once trx_utils_get_file_dir('shortcodes/trx_basic/reviews.php');
require_once trx_utils_get_file_dir('shortcodes/trx_basic/search.php');
require_once trx_utils_get_file_dir('shortcodes/trx_basic/section.php');
require_once trx_utils_get_file_dir('shortcodes/trx_basic/skills.php');
require_once trx_utils_get_file_dir('shortcodes/trx_basic/slider.php');
require_once trx_utils_get_file_dir('shortcodes/trx_basic/socials.php');
require_once trx_utils_get_file_dir('shortcodes/trx_basic/table.php');
require_once trx_utils_get_file_dir('shortcodes/trx_basic/title.php');
require_once trx_utils_get_file_dir('shortcodes/trx_basic/twitter.php');
require_once trx_utils_get_file_dir('shortcodes/trx_basic/video.php');

require_once trx_utils_get_file_dir('shortcodes/trx_optional/button.php');
require_once trx_utils_get_file_dir('shortcodes/trx_optional/countdown.php');
require_once trx_utils_get_file_dir('shortcodes/trx_optional/dropcaps.php');
require_once trx_utils_get_file_dir('shortcodes/trx_optional/highlight.php');
require_once trx_utils_get_file_dir('shortcodes/trx_optional/icon.php');
require_once trx_utils_get_file_dir('shortcodes/trx_optional/number.php');
require_once trx_utils_get_file_dir('shortcodes/trx_optional/parallax.php');
require_once trx_utils_get_file_dir('shortcodes/trx_optional/popup.php');
require_once trx_utils_get_file_dir('shortcodes/trx_optional/price.php');
require_once trx_utils_get_file_dir('shortcodes/trx_optional/tabs.php');
require_once trx_utils_get_file_dir('shortcodes/trx_optional/toggles.php');
require_once trx_utils_get_file_dir('shortcodes/trx_optional/tooltip.php');

?>