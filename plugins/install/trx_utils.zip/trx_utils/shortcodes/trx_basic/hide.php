<?php

/* Theme setup section
-------------------------------------------------------------------- */
if (!function_exists('cars4rent_sc_hide_theme_setup')) {
	add_action( 'cars4rent_action_before_init_theme', 'cars4rent_sc_hide_theme_setup' );
	function cars4rent_sc_hide_theme_setup() {
		add_action('cars4rent_action_shortcodes_list', 		'cars4rent_sc_hide_reg_shortcodes');
	}
}



/* Shortcode implementation
-------------------------------------------------------------------- */

/*
[trx_hide selector="unique_id"]
*/

if (!function_exists('cars4rent_sc_hide')) {	
	function cars4rent_sc_hide($atts, $content=null){	
		if (cars4rent_in_shortcode_blogger()) return '';
		extract(cars4rent_html_decode(shortcode_atts(array(
			// Individual params
			"selector" => "",
			"hide" => "on",
			"delay" => 0
		), $atts)));
		$selector = trim(chop($selector));
		if (!empty($selector)) {
			cars4rent_storage_concat('js_code', '
				'.($delay>0 ? 'setTimeout(function() {' : '').'
					jQuery("'.esc_attr($selector).'").' . ($hide=='on' ? 'hide' : 'show') . '();
				'.($delay>0 ? '},'.($delay).');' : '').'
			');
		}
		return apply_filters('cars4rent_shortcode_output', $output, 'trx_hide', $atts, $content);
	}
	cars4rent_require_shortcode('trx_hide', 'cars4rent_sc_hide');
}



/* Register shortcode in the internal SC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'cars4rent_sc_hide_reg_shortcodes' ) ) {
	function cars4rent_sc_hide_reg_shortcodes() {
	
		cars4rent_sc_map("trx_hide", array(
			"title" => esc_html__("Hide/Show any block", 'trx_utils'),
			"desc" => wp_kses_data( __("Hide or Show any block with desired CSS-selector", 'trx_utils') ),
			"decorate" => false,
			"container" => false,
			"params" => array(
				"selector" => array(
					"title" => esc_html__("Selector", 'trx_utils'),
					"desc" => wp_kses_data( __("Any block's CSS-selector", 'trx_utils') ),
					"value" => "",
					"type" => "text"
				),
				"hide" => array(
					"title" => esc_html__("Hide or Show", 'trx_utils'),
					"desc" => wp_kses_data( __("New state for the block: hide or show", 'trx_utils') ),
					"value" => "yes",
					"size" => "small",
					"options" => cars4rent_get_sc_param('yes_no'),
					"type" => "switch"
				)
			)
		));
	}
}
?>