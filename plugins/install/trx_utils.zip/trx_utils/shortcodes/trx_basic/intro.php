<?php

/* Theme setup section
-------------------------------------------------------------------- */
if (!function_exists('cars4rent_sc_intro_theme_setup')) {
	add_action( 'cars4rent_action_before_init_theme', 'cars4rent_sc_intro_theme_setup' );
	function cars4rent_sc_intro_theme_setup() {
		add_action('cars4rent_action_shortcodes_list', 		'cars4rent_sc_intro_reg_shortcodes');
		if (function_exists('cars4rent_exists_visual_composer') && cars4rent_exists_visual_composer())
			add_action('cars4rent_action_shortcodes_list_vc','cars4rent_sc_intro_reg_shortcodes_vc');
	}
}



/* Shortcode implementation
-------------------------------------------------------------------- */

if (!function_exists('cars4rent_sc_intro')) {	
	function cars4rent_sc_intro($atts, $content=null){	
		if (cars4rent_in_shortcode_blogger()) return '';
		extract(cars4rent_html_decode(shortcode_atts(array(
			// Individual params
			"style" => 1,
			"align" => "none",
			"image" => "",
			"bg_color" => "",
			"icon" => "",
			"scheme" => "",
			"title" => "",
			"subtitle" => "",
			"description" => "",
			"link" => '',
			"link_caption" => esc_html__('Read more', 'trx_utils'),
            "button_icon" => "",
			"link2" => '',
			"link2_caption" => '',
			"url" => "",
			"content_position" => "",
			"content_width" => "",
			// Common params
			"id" => "",
			"class" => "",
			"animation" => "",
			"css" => "",
			"width" => "",
			"height" => "",
			"top" => "",
			"bottom" => "",
			"left" => "",
			"right" => ""
		), $atts)));
	
		if ($image > 0) {
			$attach = wp_get_attachment_image_src($image, 'full');
			if (isset($attach[0]) && $attach[0]!='')
				$image = $attach[0];
		}
		
		$width  = cars4rent_prepare_css_value($width);
		$height = cars4rent_prepare_css_value($height);
		
		$class .= ($class ? ' ' : '') . cars4rent_get_css_position_as_classes($top, $right, $bottom, $left);

		$css .= cars4rent_get_css_dimensions_from_values($width,$height);
		$css .= ($image ? 'background: url('.$image.');' : '');
		$css .= ($bg_color ? 'background-color: '.$bg_color.';' : '');
		
		$buttons = (!empty($link) || !empty($link2) 
						? '<div class="sc_intro_buttons sc_item_buttons">'
							. (!empty($link) 
								? '<div class="sc_intro_button sc_item_button">'.do_shortcode('[trx_button link="'.esc_url($link).'" size="large" target="_blank" '.($button_icon!='' ? ' icon="'. esc_attr($button_icon) .'"' : '').']'.esc_html($link_caption).'[/trx_button]').'</div>'
								: '')
							. '</div>'
						: '');
						
		$output = '<div '.(!empty($url) ? 'data-href="'.esc_url($url).'"' : '') 
					. ($id ? ' id="'.esc_attr($id).'"' : '') 
					. ' class="sc_intro' 
						. ($class ? ' ' . esc_attr($class) : '') 
						. ($content_position && $style==1 ? ' sc_intro_position_' . esc_attr($content_position) : '') 
						. ($style==5 ? ' small_padding' : '') 
						. ($scheme && !cars4rent_param_is_off($scheme) && !cars4rent_param_is_inherit($scheme) ? ' scheme_'.esc_attr($scheme) : '') 
						. ($align && $align!='none' ? ' align'.esc_attr($align) : '') 
						. '"'
					. (!cars4rent_param_is_off($animation) ? ' data-animation="'.esc_attr(cars4rent_get_animation_classes($animation)).'"' : '')
					. ($css ? ' style="'.esc_attr($css).'"' : '')
					.'>' 
					. '<div class="sc_intro_inner '.($style ? ' sc_intro_style_' . esc_attr($style) : '').'"'.(!empty($content_width) ? ' style="width:'.esc_attr($content_width).';"' : '').'>'
						. (!empty($icon) && $style==5 ? '<div class="sc_intro_icon '.esc_attr($icon).'"></div>' : '')
						. '<div class="sc_intro_content">'
							. (!empty($title) ? '<h2 class="sc_intro_title">' . trim(cars4rent_strmacros($title)) . '</h2>' : '')
                            . (!empty($subtitle) && $style!=4 && $style!=5 ? '<h6 class="sc_intro_subtitle">' . trim(cars4rent_strmacros($subtitle)) . '</h6>' : '')
                            . (!empty($description) && $style!=1 ? '<div class="sc_intro_descr">' . trim(cars4rent_strmacros($description)) . '</div>' : '')
							. ($style==2 || $style==3 ? $buttons : '')
						. '</div>'
					. '</div>'
				.'</div>';
	
	
	
		return apply_filters('cars4rent_shortcode_output', $output, 'trx_intro', $atts, $content);
	}
	cars4rent_require_shortcode('trx_intro', 'cars4rent_sc_intro');
}



/* Register shortcode in the internal SC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'cars4rent_sc_intro_reg_shortcodes' ) ) {
	function cars4rent_sc_intro_reg_shortcodes() {
	
		cars4rent_sc_map("trx_intro", array(
			"title" => esc_html__("Intro", 'trx_utils'),
			"desc" => wp_kses_data( __("Insert Intro block in your page (post)", 'trx_utils') ),
			"decorate" => true,
			"container" => false,
			"params" => array(
				"style" => array(
					"title" => esc_html__("Style", 'trx_utils'),
					"desc" => wp_kses_data( __("Select style to display block", 'trx_utils') ),
					"value" => "1",
					"type" => "checklist",
					"options" => cars4rent_get_list_styles(1, 5)
				),
				"align" => array(
					"title" => esc_html__("Alignment of the intro block", 'trx_utils'),
					"desc" => wp_kses_data( __("Align whole intro block to left or right side of the page or parent container", 'trx_utils') ),
					"value" => "",
					"type" => "checklist",
					"dir" => "horizontal",
					"options" => cars4rent_get_sc_param('float')
				), 
				"image" => array(
					"title" => esc_html__("Image URL", 'trx_utils'),
					"desc" => wp_kses_data( __("Select the intro image from the library for this section", 'trx_utils') ),
					"readonly" => false,
					"value" => "",
					"type" => "media"
				),
				"bg_color" => array(
					"title" => esc_html__("Background color", 'trx_utils'),
					"desc" => wp_kses_data( __("Select background color for the intro", 'trx_utils') ),
					"value" => "",
					"type" => "color"
				),
				"icon" => array(
					"title" => esc_html__('Icon',  'trx_utils'),
					"desc" => wp_kses_data( __("Select icon from Fontello icons set",  'trx_utils') ),
					"dependency" => array(
						'style' => array(5)
					),
					"value" => "",
					"type" => "icons",
					"options" => cars4rent_get_sc_param('icons')
				),
				"content_position" => array(
					"title" => esc_html__('Content position', 'trx_utils'),
					"desc" => wp_kses_data( __("Select content position", 'trx_utils') ),
					"dependency" => array(
						'style' => array(1)
					),
					"value" => "top_left",
					"type" => "checklist",
					"options" => array(
						'top_left' => esc_html__('Top Left', 'trx_utils'),
						'top_right' => esc_html__('Top Right', 'trx_utils'),
						'bottom_right' => esc_html__('Bottom Right', 'trx_utils'),
						'bottom_left' => esc_html__('Bottom Left', 'trx_utils')
					)
				),
				"content_width" => array(
					"title" => esc_html__('Content width', 'trx_utils'),
					"desc" => wp_kses_data( __("Select content width", 'trx_utils') ),
					"dependency" => array(
						'style' => array(1)
					),
					"value" => "100%",
					"type" => "checklist",
					"options" => array(
						'100%' => esc_html__('100%', 'trx_utils'),
						'90%' => esc_html__('90%', 'trx_utils'),
						'80%' => esc_html__('80%', 'trx_utils'),
						'70%' => esc_html__('70%', 'trx_utils'),
						'60%' => esc_html__('60%', 'trx_utils'),
						'50%' => esc_html__('50%', 'trx_utils'),
						'40%' => esc_html__('40%', 'trx_utils'),
						'30%' => esc_html__('30%', 'trx_utils')
					)
				),
				"subtitle" => array(
					"title" => esc_html__("Subtitle", 'trx_utils'),
					"desc" => wp_kses_data( __("Subtitle for the block", 'trx_utils') ),
					"divider" => true,
					"dependency" => array(
						'style' => array(1,2,3)
					),
					"value" => "",
					"type" => "text"
				),
				"title" => array(
					"title" => esc_html__("Title", 'trx_utils'),
					"desc" => wp_kses_data( __("Title for the block", 'trx_utils') ),
					"value" => "",
					"type" => "textarea"
				),
				"description" => array(
					"title" => esc_html__("Description", 'trx_utils'),
					"desc" => wp_kses_data( __("Short description for the block", 'trx_utils') ),
					"dependency" => array(
						'style' => array(2,3,4,5),
					),
					"value" => "",
					"type" => "textarea"
				),
				"link" => array(
					"title" => esc_html__("Button URL", 'trx_utils'),
					"desc" => wp_kses_data( __("Link URL for the button at the bottom of the block", 'trx_utils') ),
					"dependency" => array(
						'style' => array(2,3),
					),
					"divider" => true,
					"value" => "",
					"type" => "text"
				),
				"link_caption" => array(
					"title" => esc_html__("Button caption", 'trx_utils'),
					"desc" => wp_kses_data( __("Caption for the button at the bottom of the block", 'trx_utils') ),
					"dependency" => array(
						'style' => array(2,3),
					),
					"value" => "",
					"type" => "text"
				),
                "button_icon" => array(
                    "title" => esc_html__("Button's icon",  'trx_utils'),
                    "desc" => wp_kses_data( __('Select icon for the title from Fontello icons set',  'trx_utils') ),
                    "value" => "",
                    "type" => "icons",
                    "options" => cars4rent_get_sc_param('icons')
                ),
				"link2" => array(
					"title" => esc_html__("Button 2 URL", 'trx_utils'),
					"desc" => wp_kses_data( __("Link URL for the second button at the bottom of the block", 'trx_utils') ),
					"dependency" => array(
						'style' => array(2)
					),
					"divider" => true,
					"value" => "",
					"type" => "text"
				),
				"link2_caption" => array(
					"title" => esc_html__("Button 2 caption", 'trx_utils'),
					"desc" => wp_kses_data( __("Caption for the second button at the bottom of the block", 'trx_utils') ),
					"dependency" => array(
						'style' => array(2)
					),
					"value" => "",
					"type" => "text"
				),
				"url" => array(
					"title" => esc_html__("Link", 'trx_utils'),
					"desc" => wp_kses_data( __("Link of the intro block", 'trx_utils') ),
					"value" => "",
					"type" => "text"
				),
				"scheme" => array(
					"title" => esc_html__("Color scheme", 'trx_utils'),
					"desc" => wp_kses_data( __("Select color scheme for the section with text", 'trx_utils') ),
					"value" => "",
					"type" => "checklist",
					"options" => cars4rent_get_sc_param('schemes')
				),
				"width" => cars4rent_shortcodes_width(),
				"height" => cars4rent_shortcodes_height(),
				"top" => cars4rent_get_sc_param('top'),
				"bottom" => cars4rent_get_sc_param('bottom'),
				"left" => cars4rent_get_sc_param('left'),
				"right" => cars4rent_get_sc_param('right'),
				"id" => cars4rent_get_sc_param('id'),
				"class" => cars4rent_get_sc_param('class'),
				"animation" => cars4rent_get_sc_param('animation'),
				"css" => cars4rent_get_sc_param('css')
			)
		));
	}
}


/* Register shortcode in the VC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'cars4rent_sc_intro_reg_shortcodes_vc' ) ) {
	function cars4rent_sc_intro_reg_shortcodes_vc() {
	
		vc_map( array(
			"base" => "trx_intro",
			"name" => esc_html__("Intro", 'trx_utils'),
			"description" => wp_kses_data( __("Insert Intro block", 'trx_utils') ),
			"category" => esc_html__('Content', 'trx_utils'),
			'icon' => 'icon_trx_intro',
			"class" => "trx_sc_single trx_sc_intro",
			"content_element" => true,
			"is_container" => false,
			"show_settings_on_create" => true,
			"params" => array(
				array(
					"param_name" => "style",
					"heading" => esc_html__("Style of the block", 'trx_utils'),
					"description" => wp_kses_data( __("Select style to display this block", 'trx_utils') ),
					"class" => "",
					"admin_label" => true,
					"value" => array_flip(cars4rent_get_list_styles(1, 5)),
					"type" => "dropdown"
				),
				array(
					"param_name" => "align",
					"heading" => esc_html__("Alignment of the block", 'trx_utils'),
					"description" => wp_kses_data( __("Align whole intro block to left or right side of the page or parent container", 'trx_utils') ),
					"class" => "",
					"std" => 'none',
					"value" => array_flip(cars4rent_get_sc_param('float')),
					"type" => "dropdown"
				),
				array(
					"param_name" => "image",
					"heading" => esc_html__("Image URL", 'trx_utils'),
					"description" => wp_kses_data( __("Select the intro image from the library for this section", 'trx_utils') ),
					"class" => "",
					"value" => "",
					"type" => "attach_image"
				),
				array(
					"param_name" => "bg_color",
					"heading" => esc_html__("Background color", 'trx_utils'),
					"description" => wp_kses_data( __("Select background color for the intro", 'trx_utils') ),
					"class" => "",
					"value" => "",
					"type" => "colorpicker"
				),
				array(
					"param_name" => "icon",
					"heading" => esc_html__("Icon", 'trx_utils'),
					"description" => wp_kses_data( __("Select icon from Fontello icons set", 'trx_utils') ),
					"class" => "",
					'dependency' => array(
						'element' => 'style',
						'value' => array('5')
					),
					"value" => cars4rent_get_sc_param('icons'),
					"type" => "dropdown"
				),
				array(
					"param_name" => "content_position",
					"heading" => esc_html__("Content position", 'trx_utils'),
					"description" => wp_kses_data( __("Select content position", 'trx_utils') ),
					"class" => "",
					"admin_label" => true,
					"value" => array(
						esc_html__('Top Left', 'trx_utils') => 'top_left',
						esc_html__('Top Right', 'trx_utils') => 'top_right',
						esc_html__('Bottom Right', 'trx_utils') => 'bottom_right',
						esc_html__('Bottom Left', 'trx_utils') => 'bottom_left'
					),
					'dependency' => array(
						'element' => 'style',
						'value' => array('1')
					),
					"type" => "dropdown"
				),
				array(
					"param_name" => "content_width",
					"heading" => esc_html__("Content width", 'trx_utils'),
					"description" => wp_kses_data( __("Select content width", 'trx_utils') ),
					"class" => "",
					"admin_label" => true,
					"value" => array(
						esc_html__('100%', 'trx_utils') => '100%',
						esc_html__('90%', 'trx_utils') => '90%',
						esc_html__('80%', 'trx_utils') => '80%',
						esc_html__('70%', 'trx_utils') => '70%',
						esc_html__('60%', 'trx_utils') => '60%',
						esc_html__('50%', 'trx_utils') => '50%',
						esc_html__('40%', 'trx_utils') => '40%',
						esc_html__('30%', 'trx_utils') => '30%'
					),
					'dependency' => array(
						'element' => 'style',
						'value' => array('1')
					),
					"type" => "dropdown"
				),
				array(
					"param_name" => "subtitle",
					"heading" => esc_html__("Subtitle", 'trx_utils'),
					"description" => wp_kses_data( __("Subtitle for the block", 'trx_utils') ),
					'dependency' => array(
						'element' => 'style',
						'value' => array('1','2','3')
					),
					"group" => esc_html__('Captions', 'trx_utils'),
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "title",
					"heading" => esc_html__("Title", 'trx_utils'),
					"description" => wp_kses_data( __("Title for the block", 'trx_utils') ),
					"group" => esc_html__('Captions', 'trx_utils'),
					"admin_label" => true,
					"class" => "",
					"value" => "",
					"type" => "textarea"
				),
				array(
					"param_name" => "description",
					"heading" => esc_html__("Description", 'trx_utils'),
					"description" => wp_kses_data( __("Description for the block", 'trx_utils') ),
					"group" => esc_html__('Captions', 'trx_utils'),
					'dependency' => array(
						'element' => 'style',
						'value' => array('2','3','4','5')
					),
					"class" => "",
					"value" => "",
					"type" => "textarea"
				),
				array(
					"param_name" => "link",
					"heading" => esc_html__("Button URL", 'trx_utils'),
					"description" => wp_kses_data( __("Link URL for the button at the bottom of the block", 'trx_utils') ),
					"group" => esc_html__('Captions', 'trx_utils'),
					'dependency' => array(
						'element' => 'style',
						'value' => array('2','3')
					),
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "link_caption",
					"heading" => esc_html__("Button caption", 'trx_utils'),
					"description" => wp_kses_data( __("Caption for the button at the bottom of the block", 'trx_utils') ),
					"group" => esc_html__('Captions', 'trx_utils'),
					'dependency' => array(
						'element' => 'style',
						'value' => array('2','3')
					),
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
                array(
                    "param_name" => "button_icon",
                    "heading" => esc_html__("Button's icon", 'trx_utils'),
                    "description" => wp_kses_data( __("Select icon for the title from Fontello icons set", 'trx_utils') ),
                    "group" => esc_html__('Captions', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'style',
                        'value' => array('2','3')
                    ),
                    "class" => "",
                    "value" => cars4rent_get_sc_param('icons'),
                    "type" => "dropdown"
                ),
				array(
					"param_name" => "url",
					"heading" => esc_html__("Link", 'trx_utils'),
					"description" => wp_kses_data( __("Link of the intro block", 'trx_utils') ),
					"value" => '',
					"type" => "textfield"
				),
				array(
					"param_name" => "scheme",
					"heading" => esc_html__("Color scheme", 'trx_utils'),
					"description" => wp_kses_data( __("Select color scheme for the section with text", 'trx_utils') ),
					"class" => "",
					"value" => array_flip(cars4rent_get_sc_param('schemes')),
					"type" => "dropdown"
				),
				cars4rent_get_vc_param('id'),
				cars4rent_get_vc_param('class'),
				cars4rent_get_vc_param('animation'),
				cars4rent_get_vc_param('css'),
				cars4rent_vc_width(),
				cars4rent_vc_height(),
				cars4rent_get_vc_param('margin_top'),
				cars4rent_get_vc_param('margin_bottom'),
				cars4rent_get_vc_param('margin_left'),
				cars4rent_get_vc_param('margin_right')
			)
		) );
		
		class WPBakeryShortCode_Trx_Intro extends Cars4Rent_Vc_ShortCodeSingle {}
	}
}
?>