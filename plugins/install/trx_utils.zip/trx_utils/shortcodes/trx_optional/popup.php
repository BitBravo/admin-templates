<?php

/* Theme setup section
-------------------------------------------------------------------- */
if (!function_exists('cars4rent_sc_popup_theme_setup')) {
	add_action( 'cars4rent_action_before_init_theme', 'cars4rent_sc_popup_theme_setup' );
	function cars4rent_sc_popup_theme_setup() {
		add_action('cars4rent_action_shortcodes_list', 		'cars4rent_sc_popup_reg_shortcodes');
		if (function_exists('cars4rent_exists_visual_composer') && cars4rent_exists_visual_composer())
			add_action('cars4rent_action_shortcodes_list_vc','cars4rent_sc_popup_reg_shortcodes_vc');
	}
}



/* Shortcode implementation
-------------------------------------------------------------------- */

/*
[trx_popup id="unique_id" class="class_name" style="css_styles"]Et adipiscing integer, scelerisque pid, augue mus vel tincidunt porta[/trx_popup]
*/

if (!function_exists('cars4rent_sc_popup')) {	
	function cars4rent_sc_popup($atts, $content=null){	
		if (cars4rent_in_shortcode_blogger()) return '';
		extract(cars4rent_html_decode(shortcode_atts(array(
			// Common params
			"id" => "",
			"class" => "",
			"css" => "",
			"top" => "",
			"bottom" => "",
			"left" => "",
			"right" => ""
		), $atts)));
		$class .= ($class ? ' ' : '') . cars4rent_get_css_position_as_classes($top, $right, $bottom, $left);
		cars4rent_enqueue_popup('magnific');
		$output = '<div' . ($id ? ' id="'.esc_attr($id).'"' : '') 
				. ' class="sc_popup mfp-with-anim mfp-hide' . ($class ? ' '.esc_attr($class) : '') . '"'
				. ($css!='' ? ' style="'.esc_attr($css).'"' : '')
				. '>' 
				. do_shortcode($content) 
				. '</div>';
		return apply_filters('cars4rent_shortcode_output', $output, 'trx_popup', $atts, $content);
	}
	cars4rent_require_shortcode('trx_popup', 'cars4rent_sc_popup');
}



/* Register shortcode in the internal SC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'cars4rent_sc_popup_reg_shortcodes' ) ) {
	function cars4rent_sc_popup_reg_shortcodes() {
	
		cars4rent_sc_map("trx_popup", array(
			"title" => esc_html__("Popup window", 'trx_utils'),
			"desc" => wp_kses_data( __("Container for any html-block with desired class and style for popup window", 'trx_utils') ),
			"decorate" => true,
			"container" => true,
			"params" => array(
				"_content_" => array(
					"title" => esc_html__("Container content", 'trx_utils'),
					"desc" => wp_kses_data( __("Content for section container", 'trx_utils') ),
					"divider" => true,
					"rows" => 4,
					"value" => "",
					"type" => "textarea"
				),
				"top" => cars4rent_get_sc_param('top'),
				"bottom" => cars4rent_get_sc_param('bottom'),
				"left" => cars4rent_get_sc_param('left'),
				"right" => cars4rent_get_sc_param('right'),
				"id" => cars4rent_get_sc_param('id'),
				"class" => cars4rent_get_sc_param('class'),
				"css" => cars4rent_get_sc_param('css')
			)
		));
	}
}


/* Register shortcode in the VC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'cars4rent_sc_popup_reg_shortcodes_vc' ) ) {
	function cars4rent_sc_popup_reg_shortcodes_vc() {
	
		vc_map( array(
			"base" => "trx_popup",
			"name" => esc_html__("Popup window", 'trx_utils'),
			"description" => wp_kses_data( __("Container for any html-block with desired class and style for popup window", 'trx_utils') ),
			"category" => esc_html__('Content', 'trx_utils'),
			'icon' => 'icon_trx_popup',
			"class" => "trx_sc_collection trx_sc_popup",
			"content_element" => true,
			"is_container" => true,
			"show_settings_on_create" => true,
			"params" => array(
				cars4rent_get_vc_param('id'),
				cars4rent_get_vc_param('class'),
				cars4rent_get_vc_param('css'),
				cars4rent_get_vc_param('margin_top'),
				cars4rent_get_vc_param('margin_bottom'),
				cars4rent_get_vc_param('margin_left'),
				cars4rent_get_vc_param('margin_right')
			)
		) );
		
		class WPBakeryShortCode_Trx_Popup extends Cars4Rent_Vc_ShortCodeCollection {}
	}
}
?>