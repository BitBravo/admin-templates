
# Dashtreme Admin Dashboard
[Demo]( https://jsdev63.github.io/dashtreme-admin-dashboard/)

[![](assets/images/screen.png "Title")]( https://jsdev63.github.io/dashtreme-admin-dashboard/)
