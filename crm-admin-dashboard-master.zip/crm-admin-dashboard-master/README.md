
# CRM Admin Dashboard
[Demo](https://jsdev63.github.io/crm-admin-dashboard/)

[![](assets/screen.png "Title")](https://jsdev63.github.io/crm-admin-dashboard/)
